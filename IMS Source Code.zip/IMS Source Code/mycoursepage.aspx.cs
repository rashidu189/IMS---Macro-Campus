﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using static IMS_System___MACRO_CAMPUS.WebForm4;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class exampage : System.Web.UI.Page
    {
        string user_id = string.Empty;
        string c_Name = string.Empty;
        string c_Name2 = string.Empty;
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            string user_idN = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("std_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                    user_idN = Session["User_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }



            //Course Card

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_idN + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "loadCourses", "loadCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


            //For the Payment

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_idN + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "PaymentCourses", "PaymentCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            string full_name = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("std_user"))
                {

                    full_name = Session["full_name"].ToString();
                    user_id = Session["user_id"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            /*if (!IsPostBack)
            {
                FillGridView();
            }*/
            if (!IsPostBack)
            {
                string courseName = Request.QueryString["courseName"];
                if (!string.IsNullOrEmpty(courseName))
                {
                    c_Name = Server.UrlDecode(courseName);
                    FillGridView();

                }
                else
                {
                    c_Name = "Course name not found.";
                }
            }
        }
        
        public void FillGridView()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use a SQL query to select data from the table
            string query = "SELECT [Subject No], [Subject Name], [Semester], [Grade], [Start Date], [End Date],[Tutorial File Path],[Assignment File Path],[Exam File Path] FROM user_c_subject_tbl WHERE [User ID] = '" + user_id + "' AND [Course name] = '"+c_Name+"'";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.SelectCommand.CommandTimeout = 600;
            // No need to set the CommandType when using a SQL query
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            con.Close();

            MyCourse.DataSource = dt;
            MyCourse.DataBind();

        }
        protected void MyCourse_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "View")
            {
                // Get the index of the row that was clicked
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = MyCourse.Rows[index];

                // Get values from the row
                string subjectNo = row.Cells[0].Text;  
                string subjectName = row.Cells[1].Text;     
                string semester = row.Cells[2].Text;   
                string grade = row.Cells[3].Text;  
                string startDate = row.Cells[4].Text; 
                string endDate = row.Cells[5].Text;
                string tutorialFilePath = row.Cells[6].Text;
                string assignmentFilePath = row.Cells[7].Text;
                string examFilePath = row.Cells[8].Text;

                // Find the FileUpload control within this specific row
                FileUpload fileUploadControl = (FileUpload)row.FindControl("fileUploadControl");

                // Check if a file is uploaded
                if (fileUploadControl != null && fileUploadControl.HasFile)
                {
                    try
                    {
                        // Get the uploaded file name
                        string fileName = Path.GetFileName(fileUploadControl.FileName);

                        // Define the upload path (make sure the folder exists)
                        string uploadPath = @"D:\Final Project IMS System\IMS System - MACRO CAMPUS\Share Folder\Student\Upload Files\" + fileName;

                        // Save the uploaded file to the specified path
                        fileUploadControl.SaveAs(uploadPath);

                        // Success message with success image
                        string imageUrl = "Resources/success.png";
                        string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Your Document is Successfully Uploaded in MACRO System.";

                        // Store the success message in session
                        Session["AlertMessage"] = message;
                        Session["AlertType"] = "alert-success";
                    }
                    catch (Exception ex)
                    {
                        // Error handling with failure image
                        string imageUrl = "Resources/error.png";
                        string message = $"<img src='{imageUrl}' alt='Error Image' style='width:20px;height:20px;' /> Upload failed. Error: {ex.Message}";

                        // Store the error message in session
                        Session["AlertMessage"] = message;
                        Session["AlertType"] = "alert-danger";
                    }
                }
                else
                {
                    // No file was selected for upload
                    string imageUrl = "Resources/error.png";
                    string message = $"<img src='{imageUrl}' alt='Error Image' style='width:20px;height:20px;' /> No file selected for upload.";

                    // Store the message in session
                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-danger";
                }

            }
            if (e.CommandName == "TutorialDownload")
            {
                string TutorialfilePath = e.CommandArgument.ToString(); // Retrieve the file path
                TutorialDownloadFile(TutorialfilePath); // Call the method to download the file
            }
            if (e.CommandName == "AssignmentDownload")
            {
                string AssignmentfilePath = e.CommandArgument.ToString(); // Retrieve the file path
                AssignmentDownloadFile(AssignmentfilePath); // Call the method to download the file
            }
            if (e.CommandName == "ExamDownload")
            {
                string ExamfilePath = e.CommandArgument.ToString(); // Retrieve the file path
                ExamDownloadFile(ExamfilePath); // Call the method to download the file
            }
        }

        protected void SearchBtn_Click(object sender, EventArgs e)
        {
            /*string courseName = TextBox3.Text.ToString().Trim();
            string batchNo = TextBox2.Text.ToString().Trim();
            string studentId = TextBox1.Text.ToString().Trim();
            string subjectName = TextBox4.Text.ToString().Trim();
            string status = DropDownList1.SelectedItem.Value.ToString().Trim();

            // Ensure proper URL encoding for query string parameters
            string url = string.Format("SearchResults.aspx?courseName={0}&batchNo={1}&studentId={2}&subjectName={3}&status={4}",
                                        Server.UrlEncode(courseName),
                                        Server.UrlEncode(batchNo),
                                        Server.UrlEncode(studentId),
                                        Server.UrlEncode(subjectName),
                                        Server.UrlEncode(status));

            Response.Redirect(url);*/
        }

        protected void RefreshBtn_Click(object sender, EventArgs e)
        {
            /*string message = "Hello! This is an alert."+user_id+" "+c_Name;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + message + "');", true);*/
            Response.Redirect(Request.RawUrl);
        }

        public void TutorialDownloadFile(string TutorialfilePath)
        {
            // Ensure the file exists
            if (File.Exists(TutorialfilePath))
            {
                // Clear the response
                HttpContext.Current.Response.Clear();

                // Set the content type
                HttpContext.Current.Response.ContentType = "application/pdf";

                // Add content disposition header
                HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(TutorialfilePath));

                // Write the file to the response
                HttpContext.Current.Response.TransmitFile(TutorialfilePath);
                HttpContext.Current.Response.End();
            }
            else
            {
                // Handle the case where the file does not exist
                HttpContext.Current.Response.Write("File not found.");
            }
        }

        public void AssignmentDownloadFile(string AssignmentfilePath)
        {
            // Ensure the file exists
            if (File.Exists(AssignmentfilePath))
            {
                // Clear the response
                HttpContext.Current.Response.Clear();

                // Set the content type
                HttpContext.Current.Response.ContentType = "application/doc";

                // Add content disposition header
                HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(AssignmentfilePath));

                // Write the file to the response
                HttpContext.Current.Response.TransmitFile(AssignmentfilePath);
                HttpContext.Current.Response.End();
            }
            else
            {
                // Handle the case where the file does not exist
                HttpContext.Current.Response.Write("File not found.");
            }
        }

        public void ExamDownloadFile(string ExamfilePath)
        {
            // Ensure the file exists
            if (File.Exists(ExamfilePath))
            {
                byte[] fileBytes = File.ReadAllBytes(ExamfilePath);

                // Set the response headers for file download
                Response.Clear();
                Response.ContentType = "application/html"; // Change based on file type
                Response.AddHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(ExamfilePath));
                Response.BinaryWrite(fileBytes);
                Response.End();
            }
            else
            {
                // Handle the case where the file does not exist
                HttpContext.Current.Response.Write("File not found.");
            }
        }


        protected void Button2_Click(object sender, EventArgs e)
        {
            string courseName = Request.QueryString["courseName"]?.Replace("  ", "");

            if (!string.IsNullOrEmpty(courseName))
            {
                c_Name2 = Server.UrlDecode(courseName);
            }
            else
            {
                c_Name2 = "Course name not found.";
            }

            string semNo = "SEM 01";

            string query1 = @"SELECT [Subject No], [Subject Name], [Semester], [Grade], [Start Date], [End Date],[Tutorial File Path],[Assignment File Path],[Exam File Path] FROM user_c_subject_tbl WHERE [User ID] = '" + user_id + "' AND [Course name] = '"+c_Name2+ "' AND [Semester] = @SemNo";

            // Open the connection
            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use SqlCommand to execute the query with parameters
            using (SqlCommand cmd = new SqlCommand(query1, con))
            {
                // Add parameters to avoid SQL injection
                cmd.Parameters.AddWithValue("@SemNo",  semNo );

                // Execute the query and fill the data table
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Close the connection
                con.Close();

                // Bind the results to the GridView
                MyCourse.DataSource = dt;
                MyCourse.DataBind();
            }
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            string courseName = Request.QueryString["courseName"]?.Replace("  ", "");

            if (!string.IsNullOrEmpty(courseName))
            {
                c_Name2 = Server.UrlDecode(courseName);
            }
            else
            {
                c_Name2 = "Course name not found.";
            }

            string semNo = "SEM 02";

            string query2 = @"SELECT [Subject No], [Subject Name], [Semester], [Grade], [Start Date], [End Date],[Tutorial File Path],[Assignment File Path],[Exam File Path] FROM user_c_subject_tbl WHERE [User ID] = '" + user_id + "' AND [Course name] = '" + c_Name2 + "' AND [Semester] = @SemNo";

            // Open the connection
            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use SqlCommand to execute the query with parameters
            using (SqlCommand cmd = new SqlCommand(query2, con))
            {
                // Add parameters to avoid SQL injection
                cmd.Parameters.AddWithValue("@SemNo", semNo);

                // Execute the query and fill the data table
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Close the connection
                con.Close();

                // Bind the results to the GridView
                MyCourse.DataSource = dt;
                MyCourse.DataBind();
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            string courseName = Request.QueryString["courseName"]?.Replace("  ", "");

            if (!string.IsNullOrEmpty(courseName))
            {
                c_Name2 = Server.UrlDecode(courseName);
            }
            else
            {
                c_Name2 = "Course name not found.";
            }

            string semNo = "SEM 03";

            string query3 = @"SELECT [Subject No], [Subject Name], [Semester], [Grade], [Start Date], [End Date],[Tutorial File Path],[Assignment File Path],[Exam File Path] FROM user_c_subject_tbl WHERE [User ID] = '" + user_id + "' AND [Course name] = '" + c_Name2 + "' AND [Semester] = @SemNo";

            // Open the connection
            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use SqlCommand to execute the query with parameters
            using (SqlCommand cmd = new SqlCommand(query3, con))
            {
                // Add parameters to avoid SQL injection
                cmd.Parameters.AddWithValue("@SemNo", semNo);

                // Execute the query and fill the data table
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Close the connection
                con.Close();

                // Bind the results to the GridView
                MyCourse.DataSource = dt;
                MyCourse.DataBind();
            }
        }
        protected void Button5_Click(object sender, EventArgs e)
        {
            string courseName = Request.QueryString["courseName"]?.Replace("  ", "");

            if (!string.IsNullOrEmpty(courseName))
            {
                c_Name2 = Server.UrlDecode(courseName);
            }
            else
            {
                c_Name2 = "Course name not found.";
            }

            string semNo = "SEM 04";

            string query4 = @"SELECT [Subject No], [Subject Name], [Semester], [Grade], [Start Date], [End Date],[Tutorial File Path],[Assignment File Path],[Exam File Path] FROM user_c_subject_tbl WHERE [User ID] = '" + user_id + "' AND [Course name] = '" + c_Name2 + "' AND [Semester] = @SemNo";

            // Open the connection
            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use SqlCommand to execute the query with parameters
            using (SqlCommand cmd = new SqlCommand(query4, con))
            {
                // Add parameters to avoid SQL injection
                cmd.Parameters.AddWithValue("@SemNo", semNo);

                // Execute the query and fill the data table
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Close the connection
                con.Close();

                // Bind the results to the GridView
                MyCourse.DataSource = dt;
                MyCourse.DataBind();
            }
        }
        public class Course
        {
            public string CourseName { get; set; }
            public string BatchNo { get; set; }
            public string Status { get; set; }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("mycoursepage.aspx");
            /*// Register JavaScript to be executed on the client-side
            string script = "window.location.href = 'mycoursepage.aspx';";
            ClientScript.RegisterStartupScript(this.GetType(), "redirect", script, true);*/
        }
    }

}