﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static IMS_System___MACRO_CAMPUS.userhomepage;
using System.Xml.Linq;
using System.Reflection;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class course_information_page1 : System.Web.UI.Page
    {
        string CourseName = string.Empty;
        string Faculty = string.Empty;
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            string Emp_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("emp_user"))
                {

                    Emp_id = Session["Employee_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            if (!IsPostBack)
            {
                Faculty = Request.QueryString["faculty"];
                CourseName = Request.QueryString["courseName"];

                CourseDetails();
                ListOfSubject();

            }
            if (!IsPostBack)
            {
                ListofBatch();
            }
            if (!IsPostBack)
            {
                ListofLecturers();
            }

        }
        public void CourseDetails()
        {
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Id], [Course Name], [Faculty], [Total Amount] FROM course_amount_tbl WHERE [Course Name] = @CourseName AND [Faculty] = @Faculty";
                cmd.Parameters.AddWithValue("@CourseName", CourseName);
                cmd.Parameters.AddWithValue("@Faculty", Faculty);
                cmd.CommandTimeout = 600;
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    courseId.Text = dr[0].ToString().Trim();
                    courseNameTextBox.Text = dr[1].ToString().Trim();

                    string C_Faculty = dr[2].ToString().Trim();
                    DropDownList12.SelectedValue = C_Faculty;

                    courseAmount.Text = dr[3].ToString().Trim();

                }
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }



        }
        protected void UpdateCourseDetails_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "UPDATE course_amount_tbl SET [Faculty] = @Faculty , [Total Amount] = @CourseAmount  WHERE [Course Name] = @CourseName ";

                cmd.Parameters.AddWithValue("@CourseName", courseNameTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@CourseAmount", courseAmount.Text.Trim());
                cmd.Parameters.AddWithValue("@Faculty", DropDownList12.SelectedValue);
                cmd.CommandTimeout = 600;
                cmd.ExecuteNonQuery();
                con.Close();

                string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Course Details have been successfully updated";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-success"; // Adding the alert type
            }
            catch (Exception ex)
            { 
                Console.WriteLine(ex);
            }
        }

        private void ListofBatch()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            string CourseName = courseNameTextBox.Text.Trim();
            string ListofBatchquery = "SELECT [Batch No] FROM batch_tbl WHERE [Course Name] = '"+CourseName+"'";
            SqlCommand cmd = new SqlCommand(ListofBatchquery, con);
            cmd.CommandTimeout = 600;
            try
            {
                SqlDataReader reader = cmd.ExecuteReader();

                // Clear previous data
                DropDownList1.Items.Clear();

                // Bind DropDownList
                DropDownList1.DataSource = reader;
                DropDownList1.DataTextField = "Batch No";
                DropDownList1.DataValueField = "Batch No";
                DropDownList1.DataBind();
                reader.Close(); // Close the reader after binding

                // Optionally, select the first item if it exists
                if (DropDownList1.Items.Count > 0)
                {
                    DropDownList1.SelectedIndex = 0;
                    UpdateBatchDetails(DropDownList1.SelectedValue);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        private void UpdateBatchDetails(string selectedBatchNo)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;"))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string detailsQuery = "SELECT [Batch No],[Course Name],[Faculty],[Coordinator Id],[Coordinator],[Course Start Date],[Course End Date],[Count of Students] FROM batch_tbl WHERE [Batch No] = @BatchNo";

                using (SqlCommand detailsCmd = new SqlCommand(detailsQuery, con))
                {
                    detailsCmd.Parameters.AddWithValue("@BatchNo", selectedBatchNo);
                    detailsCmd.CommandTimeout = 600;
                    try
                    {
                        SqlDataReader detailsReader = detailsCmd.ExecuteReader();

                        if (detailsReader.Read())
                        {
                            string facultyValue = detailsReader["Faculty"].ToString().Trim();
                            DropDownList2.SelectedValue = facultyValue;
                            TextBox1.Text = detailsReader["Coordinator Id"].ToString();
                            TextBox13.Text = DateTime.Parse(detailsReader["Course Start Date"].ToString()).ToString("yyyy-MM-dd");
                            TextBox14.Text = DateTime.Parse(detailsReader["Course End Date"].ToString()).ToString("yyyy-MM-dd");
                            TextBox15.Text = detailsReader["Count of Students"].ToString();
                            TextBox12.Text = detailsReader["Coordinator"].ToString();

                            TextBox8.Text = detailsReader["Batch No"].ToString();
                            TextBox9.Text = detailsReader["Coordinator Id"].ToString();
                            TextBox10.Text = detailsReader["Coordinator"].ToString();
                            TextBox18.Text = detailsReader["Faculty"].ToString();
                            TextBox11.Text = detailsReader["Count of Students"].ToString();
                            TextBox16.Text = DateTime.Parse(detailsReader["Course Start Date"].ToString()).ToString("yyyy-MM-dd");
                            TextBox17.Text = DateTime.Parse(detailsReader["Course End Date"].ToString()).ToString("yyyy-MM-dd");
                        }
                        detailsReader.Close();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateBatchDetails(DropDownList1.SelectedValue);
        }
        protected void SearchCoordinator_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;"))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string coordinatorId = TextBox1.Text.Trim();
                string detailsQuery = "SELECT [Full_Name] FROM Employee_TBL WHERE [Employee_ID] = @CoordinatorId AND [User_Type] = 'Lecturer' AND [User_Status] = 'Active'   ";

                using (SqlCommand detailsCmd = new SqlCommand(detailsQuery, con))
                {
                    detailsCmd.Parameters.AddWithValue("@CoordinatorId", coordinatorId);
                    detailsCmd.CommandTimeout = 600;
                    try
                    {
                        SqlDataReader detailsReader = detailsCmd.ExecuteReader();

                        if (detailsReader.Read())
                        {
                            TextBox12.Text = detailsReader["Full_Name"].ToString();
                        }
                        detailsReader.Close();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }
        protected void UpdateBatchDetails_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "UPDATE batch_tbl SET [Faculty] = @Faculty , [Coordinator Id] = @CoordinatorId , [Coordinator] = @Coordinator , [Course Start Date] = @StartDate , [Course End Date] = @EndDate , [Count of Students]  = @CountofStudent  WHERE [Batch No] = @BatchNo AND [Course Name] = @CourseName ";

                cmd.Parameters.AddWithValue("@CourseName", courseNameTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@BatchNo", DropDownList1.SelectedValue);
                cmd.Parameters.AddWithValue("@Faculty", DropDownList2.SelectedValue);
                cmd.Parameters.AddWithValue("@CoordinatorId", TextBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@Coordinator", TextBox12.Text.Trim());
                cmd.Parameters.AddWithValue("@CountofStudent", TextBox15.Text.Trim());
                cmd.Parameters.AddWithValue("@StartDate", TextBox13.Text.Trim());
                cmd.Parameters.AddWithValue("@EndDate", TextBox14.Text.Trim());
                cmd.CommandTimeout = 600;
                cmd.ExecuteNonQuery();
                con.Close();

                string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Batch Details have been successfully updated";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-success"; // Adding the alert type

                Response.Redirect(Request.RawUrl);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        protected void AddNewBatch_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand checkCmd = con.CreateCommand();
                checkCmd.CommandType = System.Data.CommandType.Text;

                // Check if Batch No already exists in the table
                checkCmd.CommandText = "SELECT COUNT(*) FROM batch_tbl WHERE [Batch No] = @BatchNo";
                checkCmd.Parameters.AddWithValue("@BatchNo", TextBox7.Text.Trim());
                checkCmd.CommandTimeout = 600;
                int count = (int)checkCmd.ExecuteScalar(); 

                if (count > 0)
                {
                    string imageUrl = "Resources/error.png"; 
                    string message = $"<img src='{imageUrl}' alt='Error Image' style='width:20px;height:20px;' /> Duplicate Batch No found. Please enter a unique Batch No.";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-danger"; 

                    con.Close();

                }
                else
                {
                    // Proceed with inserting the new batch
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;

                    cmd.CommandText = "INSERT INTO batch_tbl ([Batch No],[Course Name],[Faculty],[Coordinator Id],[Coordinator],[Course Start Date],[Course End Date],[Count of Students]) VALUES (@BatchNo,@CourseName,@Faculty,@CoordinatorId,@Coordinator,@StartDate,@EndDate,@CountofStudent)";

                    cmd.Parameters.AddWithValue("@CourseName", courseNameTextBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@BatchNo", TextBox7.Text.Trim());
                    cmd.Parameters.AddWithValue("@Faculty", DropDownList3.SelectedValue);
                    cmd.Parameters.AddWithValue("@CoordinatorId", DropDownList4.SelectedValue);
                    cmd.Parameters.AddWithValue("@Coordinator", TextBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@CountofStudent", TextBox3.Text.Trim());
                    cmd.Parameters.AddWithValue("@StartDate", TextBox4.Text.Trim());
                    cmd.Parameters.AddWithValue("@EndDate", TextBox5.Text.Trim());
                    cmd.CommandTimeout = 600;
                    cmd.ExecuteNonQuery();

                    con.Close();

                    // Success message
                    string imageUrl = "Resources/success.png"; // Update this to the actual path of your success image
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> New Batch has been successfully Added";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-success"; // Success alert type

                    Response.Redirect(Request.RawUrl); // Refresh the page with the success alert
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        private void ListofLecturers()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            string CourseName = courseNameTextBox.Text.Trim();
            string ListofBatchquery = "SELECT [Employee_ID] FROM Employee_TBL WHERE [User_Type] = 'Lecturer' AND[User_Status] = 'Active'   ";
            SqlCommand cmd = new SqlCommand(ListofBatchquery, con);
            cmd.CommandTimeout = 600;
            try
            {
                SqlDataReader reader = cmd.ExecuteReader();

                // Clear previous data
                DropDownList4.Items.Clear();

                // Bind DropDownList
                DropDownList4.DataSource = reader;
                DropDownList4.DataTextField = "Employee_ID";
                DropDownList4.DataValueField = "Employee_ID";
                DropDownList4.DataBind();
                reader.Close(); // Close the reader after binding

                // Optionally, select the first item if it exists
                if (DropDownList4.Items.Count > 0)
                {
                    DropDownList4.SelectedIndex = 0;
                    UpdateBatchDetails(DropDownList4.SelectedValue);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        private void UpdateLecturerName(string selectedEMPId)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;"))
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    string detailsQuery = "SELECT [Full_Name] FROM Employee_TBL WHERE [User_Type] = 'Lecturer' AND[User_Status] = 'Active' AND [Employee_ID] = @EmpID  ";

                    using (SqlCommand detailsCmd = new SqlCommand(detailsQuery, con))
                    {
                        detailsCmd.Parameters.AddWithValue("@EmpID", selectedEMPId);
                        detailsCmd.CommandTimeout = 600;
                        try
                        {
                            SqlDataReader detailsReader = detailsCmd.ExecuteReader();

                            if (detailsReader.Read())
                            {
                                TextBox2.Text = detailsReader["Full_Name"].ToString();
                            }
                            detailsReader.Close();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateLecturerName(DropDownList4.SelectedValue);
        }
        protected void DeleteSelectedBatch_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "DELETE batch_tbl WHERE [Batch No] = @BatchNo AND [Faculty] = @Faculty AND [Course Name] = @CourseName";

                cmd.Parameters.AddWithValue("@BatchNo", TextBox8.Text.Trim());
                cmd.Parameters.AddWithValue("@Faculty", TextBox18.Text.Trim());
                cmd.Parameters.AddWithValue("@CourseName", courseNameTextBox.Text.Trim());
                cmd.CommandTimeout = 600;
                cmd.ExecuteNonQuery();
                con.Close();

                string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Batch No : " + TextBox8.Text.Trim() + " have been successfully Deleted";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-success"; // Adding the alert type

                Response.Redirect(Request.RawUrl);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        public void ListOfSubject()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                // Use a SQL query to select data from the table
                string query = "SELECT [Subject No] AS SubjectNo,[Subject Name] AS SubjectName,[Semester] AS Semester,[Tutorial File Path] AS TutorialFilePath,[Assignment File Path] AS AssignmentFilePath,[Exam File Path] AS ExamFilePath FROM c_subject_tbl WHERE [Course name] = '" + courseNameTextBox.Text.Trim() + "'";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                adapter.SelectCommand.CommandTimeout = 600;
                // No need to set the CommandType when using a SQL query
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                con.Close();

                SubjectManagement.DataSource = dt;
                SubjectManagement.DataBind();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        protected void SubjectManagement_RowCommand(object sender, GridViewCommandEventArgs e)
        {

        }
        protected void SearchSubjectNo_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;"))
            {
                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    string subjectNo = TextBox6.Text.Trim();
                    string detailsQuery = "SELECT [Subject No],[Subject Name],[Semester],[Tutorial File Path],[Assignment File Path],[Exam File Path] FROM c_subject_tbl WHERE [Subject No] = @SubjectNo ";

                    using (SqlCommand detailsCmd = new SqlCommand(detailsQuery, con))
                    {
                        detailsCmd.Parameters.AddWithValue("@SubjectNo", subjectNo);
                        detailsCmd.CommandTimeout = 600;
                        try
                        {
                            SqlDataReader detailsReader = detailsCmd.ExecuteReader();

                            if (detailsReader.Read())
                            {
                                TextBox19.Text = detailsReader["Subject Name"].ToString().Trim();
                                string semester = detailsReader["Semester"].ToString().Trim();
                                DropDownList5.SelectedValue = semester;
                                TextBox21.Text = detailsReader["Tutorial File Path"].ToString().Trim();
                                TextBox22.Text = detailsReader["Assignment File Path"].ToString().Trim();
                                TextBox23.Text = detailsReader["Exam File Path"].ToString().Trim();

                                TextBox28.Text = detailsReader["Subject No"].ToString().Trim();
                                TextBox29.Text = detailsReader["Subject Name"].ToString().Trim();
                                TextBox33.Text = detailsReader["Semester"].ToString().Trim();
                                TextBox30.Text = detailsReader["Tutorial File Path"].ToString().Trim();
                                TextBox31.Text = detailsReader["Assignment File Path"].ToString().Trim();
                                TextBox32.Text = detailsReader["Exam File Path"].ToString().Trim();
                            }
                            detailsReader.Close();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }

            }
        }
        protected void UpdateSubjectDetails_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "UPDATE c_subject_tbl SET [Subject Name] = @SubjectName, [Semester] = @Semester, [Tutorial File Path] = @TutorialFilePath, [Assignment File Path] = @AssignmentFilePath, [Exam File Path] = @ExamFilePath WHERE [Subject No] = @SubjectNo AND [Course name] = @CourseName";

                cmd.Parameters.AddWithValue("@CourseName", courseNameTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@SubjectNo", TextBox6.Text.Trim());
                cmd.Parameters.AddWithValue("@SubjectName", TextBox19.Text.Trim());
                cmd.Parameters.AddWithValue("@Semester", DropDownList5.SelectedValue);
                cmd.Parameters.AddWithValue("@TutorialFilePath", TextBox21.Text.Trim());
                cmd.Parameters.AddWithValue("@AssignmentFilePath", TextBox22.Text.Trim());
                cmd.Parameters.AddWithValue("@ExamFilePath", TextBox23.Text.Trim());
                cmd.CommandTimeout = 600;
                cmd.ExecuteNonQuery();
                con.Close();

                string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Subject Details have been successfully updated";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-success"; // Adding the alert type

                Response.Redirect(Request.RawUrl);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        protected void AddNewSubject_Click(object sender, EventArgs e)
        {
            try
            {

                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;

                    cmd.CommandText = "INSERT INTO c_subject_tbl([Subject No],[Subject Name],[Semester],[Course name],[Is Active],[Tutorial File Path],[Assignment File Path],[Exam File Path]) VALUES(@SubjectNo,@SubjectName,@Semester,@CourseName,1,@TutorialFilePath,@AssignmentFilePath,@ExamFilePath)";

                    cmd.Parameters.AddWithValue("@CourseName", courseNameTextBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@SubjectNo", TextBox20.Text.Trim());
                    cmd.Parameters.AddWithValue("@SubjectName", TextBox24.Text.Trim());
                    cmd.Parameters.AddWithValue("@Semester", DropDownList6.SelectedValue);
                    cmd.Parameters.AddWithValue("@TutorialFilePath", TextBox25.Text.Trim());
                    cmd.Parameters.AddWithValue("@AssignmentFilePath", TextBox26.Text.Trim());
                    cmd.Parameters.AddWithValue("@ExamFilePath", TextBox27.Text.Trim());
                    cmd.CommandTimeout = 600;
                    cmd.ExecuteNonQuery();
                    con.Close();

                    string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> New Subject have been successfully Added";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-success"; // Adding the alert type

                    Response.Redirect(Request.RawUrl);


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        protected void DeleteSelectedSubject_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "DELETE c_subject_tbl WHERE [Subject No] = @SubjectNo AND [Subject Name] = @SubjectName AND [Semester] = @Semester AND [Course name] = @CourseName";

                cmd.Parameters.AddWithValue("@CourseName", courseNameTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@SubjectNo", TextBox28.Text.Trim());
                cmd.Parameters.AddWithValue("@SubjectName", TextBox29.Text.Trim());
                cmd.Parameters.AddWithValue("@Semester", TextBox33.Text.Trim());
                cmd.CommandTimeout = 600;
                cmd.ExecuteNonQuery();
                con.Close();

                string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Subject No : " + TextBox28.Text.Trim() + " have been successfully Deleted";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-success"; // Adding the alert type

                Response.Redirect(Request.RawUrl);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        protected void c_pendingApproval_Click(object sender, EventArgs e)
        {
            Response.Redirect("c_pending_approval_page.aspx");
        }
        protected void leaves_Approval_Click(object sender, EventArgs e)
        {
            Response.Redirect("attendance_pending_approval.aspx");
        }
        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminSelfAttendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminStudentAttendance.aspx");
        }
    }
}