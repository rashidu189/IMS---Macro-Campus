﻿using IMS_System___MACRO_CAMPUS.Chart_Class;
using Stripe;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Net.NetworkInformation;
using System.Web;
using System.Web.Helpers;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using Telegram.Bot.Types;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class student_information_page : System.Web.UI.Page
    {
        string studentId = string.Empty;
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            string Emp_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("emp_user"))
                {

                    Emp_id = Session["Employee_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            if (!IsPostBack)
            {
                string courseName = Request.QueryString["courseName"];
                string batchNo = Request.QueryString["batchNo"];
                studentId = Request.QueryString["studentId"];

                StudentDetails();
                FillGridView();

            }
            if (!IsPostBack)
            {
                BindDropDownList();
                
            }
            if (!IsPostBack)
            {
                ListofBatch();               
            }
            if (!IsPostBack)
            {
                if (DropDownList4.Items.Count == 1)
                {
                    string selectedCourseName = DropDownList4.SelectedValue;
                    UpdateTextBoxes(selectedCourseName);
                    UpdateNewTextBoxes(selectedCourseName);
                }
            }
        }

        public void StudentDetails()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "SELECT [User_ID],[Full_Name],[First_Name],[Middle_Name],[Last_Name],[DOB],[Contact_No],[Email_ID],[Full_Address],[Gender],[Civil_Status],[Nationality],[National_Identity_Card],[Password],[User_Type],[User_Status] FROM Student_TBL ST WHERE ST.[User_ID] = '"+studentId+"'";
            cmd.CommandTimeout = 600;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                user_id.Text = dr.GetValue(0).ToString().Trim();
                fullname.Text = dr.GetValue(1).ToString().Trim();
                firstname.Text = dr.GetValue(2).ToString().Trim();
                middlename.Text = dr.GetValue(3).ToString().Trim();
                lastname.Text = dr.GetValue(4).ToString().Trim();

                DateTime dobValue = Convert.ToDateTime(dr.GetValue(5));
                dob.Text = dobValue.ToString("yyyy-MM-dd").Trim();

                int contactNoValue = Convert.ToInt32(dr.GetValue(6).ToString().Trim());
                contactno.Text = contactNoValue.ToString();

                emailid.Text = dr.GetValue(7).ToString().Trim();
                address.Text = dr.GetValue(8).ToString().Trim();

                string gender = dr.GetValue(9).ToString().Trim();
                if (gender == "Male")
                {
                    RadioButton1.Checked = true;
                }
                else if (gender == "Female")
                {
                    RadioButton2.Checked = true;
                }

                string civilStatus = dr.GetValue(10).ToString().Trim();
                DropDownList2.SelectedValue = civilStatus;

                string nationality = dr.GetValue(11).ToString().Trim();
                DropDownList3.SelectedValue = nationality;

                nic.Text = dr.GetValue(12).ToString().Trim();
                pwd.Text = dr.GetValue(13).ToString().Trim();

                string userType = dr.GetValue(14).ToString().Trim();
                DropDownList5.SelectedValue = userType;

                string userStatus = dr.GetValue(15).ToString().Trim();
                DropDownList1.SelectedValue = userStatus;
            }
            con.Close();



        }

        private void BindDropDownList()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            string query = "SELECT [User Id],[Course name],[Batch No],[Coordinator],[Course Start Date],[Course End Date],[Status],[Grade]  FROM userdetail_in_batch_tbl UBT WHERE UBT.[User Id] = '"+studentId+ "'";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandTimeout = 600;
            try
            {
                SqlDataReader reader = cmd.ExecuteReader();

                // Clear previous data
                DropDownList4.Items.Clear();

                // Bind DropDownList
                DropDownList4.DataSource = reader;
                DropDownList4.DataTextField = "Course name";
                DropDownList4.DataValueField = "Course name";
                DropDownList4.DataBind();
                reader.Close(); // Close the reader after binding

                // Optionally, select the first item if it exists
                if (DropDownList4.Items.Count > 0)
                {
                    DropDownList4.SelectedIndex = 0;
                    UpdateTextBoxes(DropDownList4.SelectedValue);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        private void UpdateTextBoxes(string selectedCourseName)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;"))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string sID = user_id.Text.ToString().Trim();
                string detailsQuery = "SELECT UBT.[User Id],UBT.[Course name],UBT.[Batch No],UBT.[Coordinator],UBT.[Course Start Date],UBT.[Course End Date],UBT.[Status],UBT.[Grade],SCP.[Total Amount],SCP.[Paid Amount],SCP.[Pending Amount]  FROM userdetail_in_batch_tbl UBT LEFT JOIN student_couse_payments SCP ON UBT.[User Id] = SCP.[Student ID] AND UBT.[Course name] = SCP.[Course Name] WHERE UBT.[Course name] = @CourseName AND UBT.[User Id] = '" + sID+ "'";

                using (SqlCommand detailsCmd = new SqlCommand(detailsQuery, con))
                {
                    detailsCmd.Parameters.AddWithValue("@CourseName", selectedCourseName);
                    detailsCmd.CommandTimeout = 600;
                    try
                    {
                        SqlDataReader detailsReader = detailsCmd.ExecuteReader();

                        if (detailsReader.Read())
                        {

                            TextBox9.Text = detailsReader["Batch No"].ToString();
                            TextBox6.Text = detailsReader["Coordinator"].ToString();
                            TextBox7.Text = DateTime.Parse(detailsReader["Course Start Date"].ToString()).ToString("yyyy-MM-dd");
                            TextBox8.Text = DateTime.Parse(detailsReader["Course End Date"].ToString()).ToString("yyyy-MM-dd");
                            TextBox10.Text = detailsReader["Grade"].ToString();
                            TextBox5.Text = detailsReader["Status"].ToString();
                            TextBox2.Text = detailsReader["Total Amount"].ToString();
                            TextBox3.Text = detailsReader["Paid Amount"].ToString();
                            TextBox4.Text = detailsReader["Pending Amount"].ToString();
                        }
                        detailsReader.Close(); // Close the reader after reading
                    }
                    catch (Exception ex)
                    {
                        // Handle the exception (e.g., log it, show a message to the user)
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTextBoxes(DropDownList4.SelectedValue);

            string selectedCourseName = DropDownList4.SelectedValue;
            UpdateTextBoxes(selectedCourseName);  
            UpdateNewTextBoxes(selectedCourseName);

        }

        public void FillGridView()
        {

            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use a SQL query to select data from the table
            string query = "SELECT [Payment Id],[Student ID],[Course Name],[Paid Amount],[Date] FROM student_payment_transactions SPT WHERE SPT.[Student ID] = '"+studentId+"'";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.SelectCommand.CommandTimeout = 600;
            // No need to set the CommandType when using a SQL query
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            con.Close();

            ViewTransactionHistory.DataSource = dt;
            ViewTransactionHistory.DataBind();

        }

        private void ListofBatch()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            string ListofBatchquery = "SELECT [Batch No] FROM batch_tbl";
            SqlCommand cmd = new SqlCommand(ListofBatchquery, con);
            cmd.CommandTimeout = 600;
            try
            {
                SqlDataReader reader = cmd.ExecuteReader();

                // Clear previous data
                DropDownList7.Items.Clear();

                // Bind DropDownList
                DropDownList7.DataSource = reader;
                DropDownList7.DataTextField = "Batch No";
                DropDownList7.DataValueField = "Batch No";
                DropDownList7.DataBind();
                reader.Close(); // Close the reader after binding

                // Optionally, select the first item if it exists
                if (DropDownList7.Items.Count > 0)
                {
                    DropDownList7.SelectedIndex = 0;
                    UpdateBatchDetails(DropDownList7.SelectedValue);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void UpdateBatchDetails(string selectedBatchNo)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;"))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string sID = user_id.Text.ToString().Trim();
                string detailsQuery = "SELECT [Batch No],[Course Name],[Faculty],[Coordinator],[Course Start Date],[Course End Date],[Count of Students] FROM batch_tbl BT WHERE BT.[Batch No] = @BatchNo";

                using (SqlCommand detailsCmd = new SqlCommand(detailsQuery, con))
                {
                    detailsCmd.Parameters.AddWithValue("@BatchNo", selectedBatchNo);
                    detailsCmd.CommandTimeout = 600;
                    try
                    {
                        SqlDataReader detailsReader = detailsCmd.ExecuteReader();

                        if (detailsReader.Read())
                        {

                            TextBox11.Text = detailsReader["Faculty"].ToString();
                            TextBox12.Text = detailsReader["Coordinator"].ToString();
                            TextBox13.Text = DateTime.Parse(detailsReader["Course Start Date"].ToString()).ToString("yyyy-MM-dd");
                            TextBox14.Text = DateTime.Parse(detailsReader["Course End Date"].ToString()).ToString("yyyy-MM-dd");
                            TextBox15.Text = detailsReader["Count of Students"].ToString();
                            TextBox16.Text = detailsReader["Course Name"].ToString();
                        }
                        detailsReader.Close(); 
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        protected void DropDownList7_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateBatchDetails(DropDownList7.SelectedValue);
        }

        protected void UpdateStudentDetails_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;

            cmd.CommandText = "UPDATE Student_TBL SET Full_Name = @FullName, First_Name = @FirstName, Middle_Name = @MiddleName, Last_Name = @LastName, DOB = @DOB, Contact_No = @ContactNo, Email_ID = @EmailID, Full_Address = @Address, Gender = @Gender, Civil_Status = @CivilStatus, Nationality = @Nationality, National_Identity_Card = @NIC, Password = @Password, User_Type = @UserType, User_Status = @UserStatus WHERE User_ID = @UserID";

            cmd.Parameters.AddWithValue("@FullName", fullname.Text.Trim());
            cmd.Parameters.AddWithValue("@FirstName", firstname.Text.Trim());
            cmd.Parameters.AddWithValue("@MiddleName", middlename.Text.Trim());
            cmd.Parameters.AddWithValue("@LastName", lastname.Text.Trim());
            cmd.Parameters.AddWithValue("@DOB", dob.Text.Trim());
            cmd.Parameters.AddWithValue("@ContactNo", contactno.Text.Trim());
            cmd.Parameters.AddWithValue("@EmailID", emailid.Text.Trim());
            cmd.Parameters.AddWithValue("@Address", address.Text.Trim());

            string gender = RadioButton1.Checked ? "Male" : "Female";
            cmd.Parameters.AddWithValue("@Gender", gender);

            cmd.Parameters.AddWithValue("@CivilStatus", DropDownList2.SelectedValue);
            cmd.Parameters.AddWithValue("@Nationality", DropDownList3.SelectedValue);
            cmd.Parameters.AddWithValue("@NIC", nic.Text.Trim());
            cmd.Parameters.AddWithValue("@Password", pwd.Text.Trim());
            cmd.Parameters.AddWithValue("@UserType", DropDownList5.SelectedValue);
            cmd.Parameters.AddWithValue("@UserStatus", DropDownList1.SelectedValue);
            cmd.Parameters.AddWithValue("@UserID", user_id.Text.Trim());
            cmd.CommandTimeout = 600;
            cmd.ExecuteNonQuery();
            con.Close();

            string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
            string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Student Information have been successfully updated";

            Session["AlertMessage"] = message;
            Session["AlertType"] = "alert-success"; // Adding the alert type
        }

        protected void UpdateStudentPayments_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;

            cmd.CommandText = "UPDATE student_couse_payments SET [Total Amount] = @TotalAmount, [Paid Amount] = @PaidAmount, [Pending Amount] = @PendingAmount WHERE [Student ID] = @StudentID AND [Course Name] = @CourseName";

            cmd.Parameters.AddWithValue("@TotalAmount", TextBox2.Text.Trim());
            cmd.Parameters.AddWithValue("@PaidAmount", TextBox3.Text.Trim());
            cmd.Parameters.AddWithValue("@PendingAmount", TextBox4.Text.Trim());
            cmd.Parameters.AddWithValue("@StudentID", user_id.Text.Trim());
            cmd.Parameters.AddWithValue("@CourseName", DropDownList4.SelectedValue);
            cmd.CommandTimeout = 600;
            cmd.ExecuteNonQuery();
            con.Close();

            string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
            string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Student Payment Details have been successfully updated";

            Session["AlertMessage"] = message;
            Session["AlertType"] = "alert-success"; // Adding the alert type
        }

        protected void UpdateStudentCourseDetails_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;

            cmd.CommandText = "UPDATE userdetail_in_batch_tbl SET [Status] = @Status , [Grade] = @Grade WHERE [Course name] = @CourseName AND [User Id] = @StudentID AND [Batch No] = @BatchNo";

            cmd.Parameters.AddWithValue("@Status", DropDownList8.SelectedValue);
            cmd.Parameters.AddWithValue("@Grade", DropDownList6.SelectedValue);
            cmd.Parameters.AddWithValue("@BatchNo", TextBox20.Text.Trim());
            cmd.Parameters.AddWithValue("@StudentID", user_id.Text.Trim());
            cmd.Parameters.AddWithValue("@CourseName", TextBox19.Text.Trim());
            cmd.CommandTimeout = 600;
            cmd.ExecuteNonQuery();
            con.Close();

            string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
            string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Student Course Details have been successfully updated";

            Session["AlertMessage"] = message;
            Session["AlertType"] = "alert-success"; // Adding the alert type

            Response.Redirect(Request.RawUrl);
        }

        private void UpdateNewTextBoxes(string selectedCourseName)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;"))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string sID = user_id.Text.ToString().Trim();
                string detailsQuery = "SELECT UBT.[Course name], UBT.[Batch No], UBT.[Coordinator], UBT.[Course Start Date], UBT.[Course End Date], UBT.[Status], UBT.[Grade] " +
                                      "FROM userdetail_in_batch_tbl UBT " +
                                      "WHERE UBT.[Course name] = @CourseName AND UBT.[User Id] = @UserId";

                using (SqlCommand detailsCmd = new SqlCommand(detailsQuery, con))
                {
                    detailsCmd.Parameters.AddWithValue("@CourseName", selectedCourseName);
                    detailsCmd.Parameters.AddWithValue("@UserId", sID);
                    detailsCmd.CommandTimeout = 600;
                    try
                    {
                        SqlDataReader detailsReader = detailsCmd.ExecuteReader();

                        if (detailsReader.Read())
                        {
                            // Assuming TextBox19 is for Course Name, TextBox20 for Batch No, etc.
                            TextBox19.Text = detailsReader["Course name"].ToString();
                            TextBox20.Text = detailsReader["Batch No"].ToString();
                            TextBox21.Text = detailsReader["Coordinator"].ToString();
                            TextBox22.Text = DateTime.Parse(detailsReader["Course Start Date"].ToString()).ToString("yyyy-MM-dd");
                            TextBox23.Text = DateTime.Parse(detailsReader["Course End Date"].ToString()).ToString("yyyy-MM-dd");
                            TextBox1.Text = detailsReader["Course name"].ToString();
                            TextBox17.Text = detailsReader["Batch No"].ToString();
                            TextBox18.Text = detailsReader["Coordinator"].ToString();
                            TextBox24.Text = DateTime.Parse(detailsReader["Course Start Date"].ToString()).ToString("yyyy-MM-dd");
                            TextBox25.Text = DateTime.Parse(detailsReader["Course End Date"].ToString()).ToString("yyyy-MM-dd");
                            TextBox26.Text = detailsReader["Grade"].ToString();
                            TextBox27.Text = detailsReader["Status"].ToString();
                        }
                        detailsReader.Close(); // Close the reader after reading
                    }
                    catch (Exception ex)
                    {
                        // Handle the exception (e.g., log it, show a message to the user)
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        protected void DeleteStudentCourse_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;

            cmd.CommandText = "DELETE userdetail_in_batch_tbl WHERE [User Id] = @StudentID AND [Course name] = @CourseName AND [Batch No] = @BatchNo";

            cmd.Parameters.AddWithValue("@BatchNo", TextBox17.Text.Trim());
            cmd.Parameters.AddWithValue("@StudentID", user_id.Text.Trim());
            cmd.Parameters.AddWithValue("@CourseName", TextBox1.Text.Trim());
            cmd.CommandTimeout = 600;
            cmd.ExecuteNonQuery();
            con.Close();

            string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
            string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Student ID : "+ user_id.Text.Trim() + "  Course Name : "+ TextBox1.Text.Trim() + " have been successfully Deleted";

            Session["AlertMessage"] = message;
            Session["AlertType"] = "alert-success"; // Adding the alert type

            Response.Redirect(Request.RawUrl);
        }

        protected void AddNewCourse_Click(object sender, EventArgs e)
        {
            // Insert Data Course Registration Table
            con.Open();

            // Check for duplicates before insert
            SqlCommand checkCmd = con.CreateCommand();
            checkCmd.CommandType = System.Data.CommandType.Text;
            checkCmd.CommandText = "SELECT COUNT(*) FROM course_reg_req_tbl WHERE [User ID] = @UserID AND [Course Name] = @CourseName AND [Is Approved] = 1";
            checkCmd.Parameters.AddWithValue("@UserID", user_id.Text.Trim());
            checkCmd.Parameters.AddWithValue("@CourseName", TextBox16.Text.Trim());
            checkCmd.CommandTimeout = 600;
            int count = (int)checkCmd.ExecuteScalar();

            if (count > 0)
            {
                string imageUrl = "Resources/error.png"; 
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> Record already exists in the database";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger"; // Adding the alert type
                Response.Redirect(Request.RawUrl);
            }
            else
            {
                // No duplicate found, proceed with insertion
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "INSERT INTO course_reg_req_tbl ([User ID], [Full Name], [Email], [Contact No], [Course Name], [Faculties], [Courses], [Course Type], [Is Approved]) " +
                                  "VALUES (@UserID, @FullName, @Email, @ContactNo, @CourseName, @Faculties, @Courses, @CourseType, 1)";
                cmd.Parameters.AddWithValue("@UserID", user_id.Text.Trim());
                cmd.Parameters.AddWithValue("@FullName", fullname.Text.Trim());
                cmd.Parameters.AddWithValue("@Email", emailid.Text.Trim());
                cmd.Parameters.AddWithValue("@ContactNo", contactno.Text.Trim());
                cmd.Parameters.AddWithValue("@CourseName", TextBox16.Text.Trim());
                cmd.Parameters.AddWithValue("@Faculties", TextBox11.Text.Trim());
                cmd.Parameters.AddWithValue("@Courses", DropDownList10.SelectedValue);
                cmd.Parameters.AddWithValue("@CourseType", DropDownList9.SelectedValue);
                cmd.CommandTimeout = 600;
                cmd.ExecuteNonQuery();

                
            }

            con.Close();

            // Assign Batch Table
            con.Open();

            
            SqlCommand checkCmdB = con.CreateCommand();
            checkCmdB.CommandType = System.Data.CommandType.Text;
            checkCmdB.CommandText = "SELECT COUNT(*) FROM userdetail_in_batch_tbl WHERE [User Id] = @UserID AND [Batch No] = @BatchNo AND [Course name] = @CourseName";
            checkCmdB.Parameters.AddWithValue("@UserID", user_id.Text.Trim());
            checkCmdB.Parameters.AddWithValue("@BatchNo", DropDownList7.SelectedValue);
            checkCmdB.Parameters.AddWithValue("@CourseName", TextBox16.Text.Trim());
            checkCmdB.CommandTimeout = 600;
            int countB = (int)checkCmdB.ExecuteScalar();

            if (countB == 0) // If no duplicate is found, proceed with the insert
            {
                SqlCommand cmd1 = con.CreateCommand();
                cmd1.CommandType = System.Data.CommandType.Text;
                cmd1.CommandText = "INSERT INTO userdetail_in_batch_tbl ([User Id],[Full Name],[Email],[Course name],[Batch No],[Coordinator],[Course Start Date],[Course End Date],[Status],[Grade]) " +
                                   "VALUES (@UserID, @FullName, @Email, @CourseName, @BatchNo, @Coordinator, @StartDate, @EndDate,'Ongoing','Pending')";

                cmd1.Parameters.AddWithValue("@UserID", user_id.Text.Trim());
                cmd1.Parameters.AddWithValue("@FullName", fullname.Text.Trim());
                cmd1.Parameters.AddWithValue("@Email", emailid.Text.Trim());
                cmd1.Parameters.AddWithValue("@CourseName", TextBox16.Text.Trim());
                cmd1.Parameters.AddWithValue("@BatchNo", DropDownList7.SelectedValue);
                cmd1.Parameters.AddWithValue("@Coordinator", TextBox12.Text.Trim());
                cmd1.Parameters.AddWithValue("@StartDate", TextBox13.Text.Trim());
                cmd1.Parameters.AddWithValue("@EndDate", TextBox14.Text.Trim());
                cmd1.CommandTimeout = 600;

                cmd1.ExecuteNonQuery();
            }
            else
            {
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> Record already exists in the database";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger"; // Adding the alert type
                Response.Redirect(Request.RawUrl);
            }

            con.Close();


            // Assign Subject Table
            string courseStartDate = string.Empty;
            string courseEndDate = string.Empty;
            con.Open();
            SqlCommand cmd5 = con.CreateCommand();
            cmd5.CommandType = System.Data.CommandType.Text;
            cmd5.CommandText = "SELECT [Course Start Date],[Course End Date] FROM batch_tbl WHERE [Batch No] = @BatchNo AND [Course Name] = @CourseName ";
            cmd5.Parameters.AddWithValue("@CourseName", TextBox16.Text.Trim());
            cmd5.Parameters.AddWithValue("@BatchNo", DropDownList7.SelectedValue);
            cmd5.CommandTimeout = 600;
            SqlDataReader dr1 = cmd5.ExecuteReader();
            if (dr1.Read())
            {
                courseStartDate = dr1.GetValue(0).ToString().Trim();
                courseEndDate = dr1.GetValue(1).ToString().Trim();
            }
            con.Close();

            con.Open();

            SqlCommand checkCmdS = con.CreateCommand();
            checkCmdS.CommandType = System.Data.CommandType.Text;
            checkCmdS.CommandText = "SELECT COUNT(*) FROM user_c_subject_tbl WHERE [User ID] = @UserId AND [Course name] = @CourseName";
            checkCmdS.Parameters.AddWithValue("@UserId", user_id.Text.Trim());
            checkCmdS.Parameters.AddWithValue("@CourseName", TextBox16.Text.Trim());
            checkCmdS.CommandTimeout = 600;
            int countS = (int)checkCmdS.ExecuteScalar();

            if (countS == 0) // If no duplicate is found
            {
                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandType = System.Data.CommandType.Text;
                cmd2.CommandText = @"
                INSERT INTO user_c_subject_tbl ([User ID], [Subject No], [Subject Name], [Semester], [Course name], [Grade], [Start Date], [End Date], [Tutorial File Path], [Assignment File Path], [Exam File Path]) 
                SELECT @UserId, [Subject No], [Subject Name], [Semester], [Course name], 'Pending', @CourseStartDate, @CourseEndDate, [Tutorial File Path], [Assignment File Path], [Exam File Path]
                FROM c_subject_tbl 
                WHERE [Course name] = @CourseName";

                cmd2.Parameters.AddWithValue("@UserId", user_id.Text.Trim());
                cmd2.Parameters.AddWithValue("@CourseName", TextBox16.Text.Trim());
                cmd2.Parameters.AddWithValue("@CourseStartDate", courseStartDate);
                cmd2.Parameters.AddWithValue("@CourseEndDate", courseEndDate);
                cmd2.CommandTimeout = 600;
                cmd2.ExecuteNonQuery();
            }
            else
            {
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> Record already exists in the database";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger"; // Adding the alert type
                Response.Redirect(Request.RawUrl);
            }

            con.Close();

            // Assign Payment Table
            string TotalAmount = string.Empty;

            con.Open();
            SqlCommand cmd3 = con.CreateCommand();
            cmd3.CommandType = System.Data.CommandType.Text;
            cmd3.CommandText = "SELECT [Total Amount] FROM [course_amount_tbl] WHERE [Course Name] = @CourseName";
            cmd3.Parameters.AddWithValue("@CourseName", TextBox16.Text.Trim());
            cmd3.CommandTimeout = 600;
            SqlDataReader dr = cmd3.ExecuteReader();
            if (dr.Read())
            {
                TotalAmount = dr.GetValue(0).ToString().Trim();
            }
            con.Close();

            con.Open();
            SqlCommand cmdCheckP = con.CreateCommand();
            cmdCheckP.CommandType = System.Data.CommandType.Text;
            cmdCheckP.CommandText = "SELECT COUNT(*) FROM [student_couse_payments] WHERE [Student ID] = @StudentID AND [Course Name] = @CourseName";
            cmdCheckP.Parameters.AddWithValue("@StudentID", user_id.Text.Trim());
            cmdCheckP.Parameters.AddWithValue("@CourseName", TextBox16.Text.Trim());
            cmdCheckP.CommandTimeout = 600;
            int countP = Convert.ToInt32(cmdCheckP.ExecuteScalar());
            con.Close();

            if (countP == 0)
            {
                con.Open();
                SqlCommand cmd4 = con.CreateCommand();
                cmd4.CommandType = System.Data.CommandType.Text;
                cmd4.CommandText = "INSERT INTO [student_couse_payments] ([Student ID],[Course Name],[Total Amount],[Paid Amount],[Pending Amount]) VALUES(@StudentID, @CourseName, @TotalAmount, @PaidAmount, @PendingAmount)";
                cmd4.Parameters.AddWithValue("@StudentID", user_id.Text.Trim());
                cmd4.Parameters.AddWithValue("@CourseName", TextBox16.Text.Trim());
                cmd4.Parameters.AddWithValue("@TotalAmount", TotalAmount);
                cmd4.Parameters.AddWithValue("@PaidAmount", 0);
                cmd4.Parameters.AddWithValue("@PendingAmount", TotalAmount);
                cmd4.CommandTimeout = 600;
                cmd4.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> Record already exists in the database";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger"; // Adding the alert type
                Response.Redirect(Request.RawUrl);
            }

            string imageUrlS = "Resources/success.png"; // Update this to the actual path of your image
            string messageS = $"<img src='{imageUrlS}' alt='Success Image' style='width:20px;height:20px;' />  " + fullname.Text.Trim() + " is successfully Assign New Course of " + TextBox16.Text.Trim() + " and Batch No " + DropDownList7.SelectedValue + "";

            Session["AlertMessage"] = messageS;
            Session["AlertType"] = "alert-success"; // Adding the alert type
            

            using (MailMessage mail = new MailMessage())
            {
                string email = emailid.Text.ToString().Trim();
                string name = firstname.Text.ToString().Trim() + " " + lastname.Text.ToString().Trim();
                string UId = user_id.Text.ToString();
                string cName = TextBox16.Text.Trim();
                string bNo = DropDownList7.SelectedValue;
                string coord = TextBox12.Text.Trim();
                string sDate = TextBox13.Text.Trim();
                string edate = TextBox14.Text.Trim();
                mail.From = new MailAddress("rashidumilan100@gmail.com");
                mail.To.Add(email);
                mail.Subject = "Course Addition - '" + UId + "'";
                mail.Body = $@"<html>
                                <head>
                                    <style>
                                        body {{{{ font-family: Arial, sans-serif; }}}}
                                        .container {{{{ margin: 20px; padding: 10px; }}}}
                                        .content {{{{ font-size: 16px; }}}}
                                        .footer {{{{ margin-top: 20px; font-size: 12px; color: gray; }}}}
                                    </style>
                                </head>
                                <body>
                                    <div class='container'>
                                        <div class='content'>
                                            <p><b>Dear {name},</b></p>
                                            <p>A new course has been added to your current program of study. The details of the course are given below.</P>
                                            <p>Your Student ID is    : <strong>{UId}</strong></p>
                                            <p>Your Course Name is   : <strong>{cName}</strong></p>
                                            <p>Your Batch No is  : <strong>{bNo}</strong></p>
                                            <p>Your Coordinator is    : <strong>{coord}</strong></p>
                                            <p>Your Course Start Date is: <strong>{sDate}</strong></p>
                                            <p>Your Course End Date is   : <strong>{edate}</strong></p>
                                            <p>Your Course Total Amount is   : <strong> LKR {TotalAmount}.00</strong></p>
                                            <p>Contact us if there is any problem.</p>
                                        </div>
                                        <div class='footer'>
                                            <p>Best regards,</p>
                                            <br>MACRO Support Team.....
            
                                        </div>
                                    </div>
                                </body>
                                <br><hr style=""font-family: arial, sans-serif; font-size: 10pt;color:#e74c3c;""><table cellpadding=""10px"">
                                                        <tr><td colspan=""3"" style=""background-color:white;color:#e74c3c text-align:center;""><b>© Note: This is an auto generated email. Please don't reply to this email.</b></td>
                                                        </tr><tr><td style=""background-color:#e74c3c;color:white;text-align:center;"">©</td>
                                                        <td style=""background-color:#e74c3c;color:white;text-align:center;"">MACRO</td>
                                                        <td style=""background-color:#e74c3c;color:white;text-align:center;"">MACRO CAMPUS SYSTEM</table>

                                </div>  
                                </html>";
                mail.IsBodyHtml = true;

                using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                {
                    smtp.Credentials = new NetworkCredential("macrocampus0@gmail.com", "xbjr lcxs yree pgjf");
                    smtp.EnableSsl = true;
                    smtp.Send(mail);
                }
                Response.Redirect(Request.RawUrl);
            }
        }
        protected void c_pendingApproval_Click(object sender, EventArgs e)
        {
            Response.Redirect("c_pending_approval_page.aspx");
        }
        protected void leaves_Approval_Click(object sender, EventArgs e)
        {
            Response.Redirect("attendance_pending_approval.aspx");
        }
        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminSelfAttendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminStudentAttendance.aspx");
        }
    }
}