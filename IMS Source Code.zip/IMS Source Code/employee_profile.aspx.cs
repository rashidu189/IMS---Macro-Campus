﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class employee_profile : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton1.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton1.Text = Session["Full_Name"].ToString();
                    LinkButton2.Text = Session["Employee_ID"].ToString();
                    TextBox1.Text = Session["Full_Name"].ToString();
                    TextBox6.Text = Session["First_Name"].ToString();
                    TextBox7.Text = Session["Middle_Name"].ToString();
                    TextBox11.Text = Session["Last_Name"].ToString();
                    if (Session["DOB"] != null)
                    {
                        DateTime dob;
                        if (DateTime.TryParse(Session["DOB"].ToString(), out dob))
                        {
                            TextBox2.Text = dob.ToString("yyyy-MM-dd");
                        }
                        else
                        {
                            TextBox2.Text = "Invalid Date";
                        }
                    }
                    else
                    {
                        TextBox2.Text = "No Date Available";
                    }
                    TextBox3.Text = Session["Contact_No"].ToString();
                    TextBox4.Text = Session["Email_ID"].ToString();
                    TextBox5.Text = Session["Full_Address"].ToString();
                    TextBox9.Text = Session["National_Identity_Card"].ToString();
                    TextBox13.Text = Session["Gender"].ToString();
                    TextBox14.Text = Session["Civil_Status"].ToString();
                    TextBox15.Text = Session["Nationality"].ToString();
                    TextBox8.Text = Session["Employee_ID"].ToString();
                    TextBox16.Text = Session["User_Type"].ToString();
                    TextBox10.Text = Session["Password"].ToString();
                    TextBox17.Text = Session["Faculty"].ToString();
                    TextBox18.Text = Session["Job_Tittle"].ToString();
                    TextBox19.Text = Session["Qualification_Level"].ToString();
                    TextBox20.Text = Session["Salary"].ToString();
                    if (Session["Joined_Date"] != null)
                    {
                        DateTime jd;
                        if (DateTime.TryParse(Session["Joined_Date"].ToString(), out jd))
                        {
                            TextBox21.Text = jd.ToString("yyyy-MM-dd");
                        }
                        else
                        {
                            TextBox21.Text = "Invalid Date";
                        }
                    }
                    else
                    {
                        TextBox21.Text = "No Date Available";
                    }
                    TextBox23.Text = Session["Qualification"].ToString();
                    TextBox22.Text = Session["Work_Experience"].ToString();


                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton3.Visible = true;
                        LinkButton4.Visible = false;
                        
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton4.Visible = true;
                        LinkButton3.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            string contact_no = contactNo.Text.ToString().Trim();
            string email_id = emailId.Text.ToString().Trim();
            string emp_id = TextBox8.Text.ToString().Trim();

            try
            {
                con.Open();
                SqlCommand cmd3 = con.CreateCommand();
                cmd3.CommandType = System.Data.CommandType.Text;
                cmd3.CommandText = @"UPDATE Employee_TBL SET [Contact_No] = @ContactNo, [Email_ID] = @EmailID WHERE [Employee_ID] = @EmpID";

                cmd3.Parameters.AddWithValue("@ContactNo", contact_no);
                cmd3.Parameters.AddWithValue("@EmailID", email_id);
                cmd3.Parameters.AddWithValue("@EmpID", emp_id);

                int rowsAffected = cmd3.ExecuteNonQuery();
                con.Close();
                if (rowsAffected > 0)
                {
                    string imageUrl = "Resources/info.png"; // Update this to the actual path of your image
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Your Information is Successfully Updated in the System";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-info"; // Adding the alert type
                    Response.Redirect(Request.RawUrl); // Redirect to refresh the page
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string old_pwd = TextBox10.Text.Trim();
            string new_pwd = TextBox12.Text.Trim();
            if (old_pwd == new_pwd)
            {
                string imageUrl = "Resources/error.png"; // Update this to the actual path of your image
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Your New Password will be the same as your Previous Password. Please Try Again Later.";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger"; // Adding the alert type
                Response.Redirect(Request.RawUrl); // Redirect to refresh the page
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd2 = con.CreateCommand();
                    cmd2.CommandType = System.Data.CommandType.Text;
                    cmd2.CommandText = "UPDATE Employee_TBL SET Password = '" + TextBox12.Text.ToString() + "' WHERE Employee_ID = '" + TextBox8.Text.ToString() + "'";
                    int rowsAffected = cmd2.ExecuteNonQuery();
                    con.Close();

                    string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Your Password Successfully Changed.";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-success"; // Adding the alert type
                    Response.Redirect(Request.RawUrl); // Redirect to refresh the page
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }
        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("self_attendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("student_attendance.aspx");
        }
    }
}