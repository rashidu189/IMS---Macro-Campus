﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class markExamandAssignment : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            string Emp_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("emp_user"))
                {

                    Emp_id = Session["Employee_ID"].ToString();
                    TextBox25.Text = Session["Employee_ID"].ToString();
                    TextBox18.Text = Session["Employee_ID"].ToString();
                    TextBox11.Text = Session["Employee_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            if (!IsPostBack)
            {
                FillGridView();
            }
        }
        protected void RefreshBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);

        }

        protected void SearchBtn_Click(object sender, EventArgs e)
        {
            string courseName = TextBox3.Text.ToString().Trim();
            string batchNo = TextBox2.Text.ToString().Trim();
            string studentId = TextBox1.Text.ToString().Trim();
            string subjectName = TextBox4.Text.ToString().Trim();
            string status = DropDownList1.SelectedItem.Value.ToString().Trim();

            string query = @"SELECT UCS.[Course name] AS [Course Name],
                        UB.[Batch No] AS [Batch No],
                        UCS.[User ID] AS [Student ID],
                        UCS.[Subject Name] AS [Subject Name],
                        UCS.[Grade] AS [Status]
                 FROM [user_c_subject_tbl] UCS
                 LEFT JOIN [userdetail_in_batch_tbl] UB 
                 ON UCS.[User ID] = UB.[User Id] 
                 AND UB.[Course name] = UCS.[Course name]
                 WHERE UCS.[Course name] LIKE @CourseName
                 AND UB.[Batch No] LIKE @BatchNo
                 AND UCS.[User ID] LIKE @StudentId
                 AND UCS.[Subject Name] LIKE @SubjectName
                 AND UCS.[Grade] LIKE @Status";

            // Open the connection
            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use SqlCommand to execute the query with parameters
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                // Add parameters to avoid SQL injection
                cmd.Parameters.AddWithValue("@CourseName", "%" + courseName + "%");
                cmd.Parameters.AddWithValue("@BatchNo", "%" + batchNo + "%");
                cmd.Parameters.AddWithValue("@StudentId", "%" + studentId + "%");
                cmd.Parameters.AddWithValue("@SubjectName", "%" + subjectName + "%");
                cmd.Parameters.AddWithValue("@Status", "%" + status + "%");

                // Execute the query and fill the data table
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Close the connection
                con.Close();

                // Bind the results to the GridView
                ExamMarks.DataSource = dt;
                ExamMarks.DataBind();
            }
        }

        public void FillGridView()
        {

            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use a SQL query to select data from the table
            string query = "SELECT UCS.[Course name] AS [Course Name],UB.[Batch No] AS [Batch No],UCS.[User ID] AS [Student ID],UCS.[Subject Name] AS [Subject Name],UCS.[Grade] AS [Status]  FROM [user_c_subject_tbl] UCS  LEFT JOIN [userdetail_in_batch_tbl] UB ON UCS.[User ID] = UB.[User Id] AND UB.[Course name] = UCS.[Course name]";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);

            // No need to set the CommandType when using a SQL query
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            con.Close();

            ExamMarks.DataSource = dt;
            ExamMarks.DataBind();

        }
        public void ExamMark_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "View")
            {
                // Get the index of the row that was clicked
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = ExamMarks.Rows[index];

                // Get values from the row
                string courseName = row.Cells[0].Text;  // Course Name
                string batchNo = row.Cells[1].Text;     // Batch No
                string studentID = row.Cells[2].Text;   // Student ID
                string subjectName = row.Cells[3].Text;  // Subject Name
                string status = row.Cells[4].Text;       // Status

                // Show the modal using JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "showModal",
                    $"showModal({index}, '{courseName}', '{batchNo}', '{studentID}', '{subjectName}', '{status}');",
                    true);


            }
        }
        protected void SaveButton_Click(object sender, EventArgs e)
        {


            string courseName = Request.Form[TextBox12.UniqueID]?.Trim();
            string subjectName = Request.Form[TextBox13.UniqueID]?.Trim();
            string batchNo = Request.Form[TextBox14.UniqueID]?.Trim();
            string studentId = Request.Form[TextBox21.UniqueID]?.Trim();
            string assignmentGrade = Request.Form[TextBox17.UniqueID]?.Trim();
            string examGrade = Request.Form[TextBox10.UniqueID]?.Trim();
            string finalGrade = Request.Form[TextBox24.UniqueID]?.Trim();
            string submissionTypeExam = submissiontype.SelectedItem.Value.ToString().Trim();
            string submissionTypeAssignment = DropDownList2.SelectedItem.Value.ToString().Trim();
            string markBy = TextBox11.Text.ToString().Trim();
            DateTime markByDate = DateTime.Now;

            // Insert Record in DataBase

            string query = @"INSERT INTO student_marks_transaction_tbl ([Course Name], 
                        [Subject Name], 
                        [Batch No], 
                        [Student Id],
                        [Assignment Grade],
                        [Exam Grade],
                        [Final Grade],
                        [Submission Type Exam],
                        [Submission Type Assignment],
                        [Mark By],
                        [Mark Date]) 
           VALUES (@CourseName,
                        @SubjectName,
                        @BatchNo,
                        @StudentId,
                        @AssignmentGrade,
                        @ExamGrade,
                        @FinalGrade,
                        @SubmissionTypeExam,
                        @SubmissionTypeAssignment,
                        @MarkBy,
                        @MarkByDate)";

            // Open the connection
            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use SqlCommand to execute the query with parameters
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@CourseName", courseName);
                cmd.Parameters.AddWithValue("@SubjectName", subjectName);
                cmd.Parameters.AddWithValue("@BatchNo", batchNo);
                cmd.Parameters.AddWithValue("@StudentId", studentId);
                cmd.Parameters.AddWithValue("@AssignmentGrade", assignmentGrade);
                cmd.Parameters.AddWithValue("@ExamGrade", examGrade);
                cmd.Parameters.AddWithValue("@FinalGrade", finalGrade);
                cmd.Parameters.AddWithValue("@SubmissionTypeExam", submissionTypeExam);
                cmd.Parameters.AddWithValue("@SubmissionTypeAssignment", submissionTypeAssignment);
                cmd.Parameters.AddWithValue("@MarkBy", markBy);
                cmd.Parameters.AddWithValue("@MarkByDate", markByDate);

                cmd.ExecuteNonQuery();
                con.Close();

                //ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record saved successfully!');", true);


                
            }
            // Update Record in DataBase


            string updateQuery = @"UPDATE user_c_subject_tbl
                                       SET [Grade] = @Grade
                                       WHERE [User ID] = @UserID 
                                       AND [Subject Name] = @SubjectName 
                                       AND [Course name] = @CourseName";

            if (con.State == ConnectionState.Closed)
                con.Open();

            using (SqlCommand cmd = new SqlCommand(updateQuery, con))
            {
                cmd.Parameters.AddWithValue("@Grade", finalGrade);
                cmd.Parameters.AddWithValue("@UserID", studentId);
                cmd.Parameters.AddWithValue("@SubjectName", subjectName);
                cmd.Parameters.AddWithValue("@CourseName", courseName);

                cmd.ExecuteNonQuery();
                con.Close();


                string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Student ID :- " + studentId + ", marks have been successfully updated";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-success"; // Adding the alert type

            }
        }


        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("self_attendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("student_attendance.aspx");
        }


    }



}
