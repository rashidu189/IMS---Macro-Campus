﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Web;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class Download : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
           /* if (IsPostBack)
            {
                DownloadFile();

            }*/

        }
        private void DownloadFile()
        {
            string downloadFilePath = string.Empty;
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "SELECT [Assignment File Path] FROM [c_subject_tbl] WHERE [Subject Id] = 1";
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                downloadFilePath = dr.GetValue(0).ToString();
            }

            // Path to the file on the server
            string filePath = downloadFilePath;

            if (File.Exists(filePath))
            {
                // Get the file bytes
                byte[] fileBytes = File.ReadAllBytes(filePath);

                // Set the response headers for file download
                Response.Clear();
                Response.ContentType = "application/html"; // Change based on file type
                Response.AddHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
                Response.BinaryWrite(fileBytes);
                Response.End();
            }
            else
            {
                Response.Write("File not found.");
            }
        }
        private void UploadFile()
        {
            if (fileUploadControl.HasFile)
            {
                try
                {
                    string fileName = Path.GetFileName(fileUploadControl.FileName);
                    string uploadPath = @"D:\Final Project IMS System\IMS System - MACRO CAMPUS\Exams\Software Engineering\" + fileName;
                    fileUploadControl.SaveAs(uploadPath);
                    Response.Write("Upload successful!");
                }
                catch (Exception ex)
                {
                    Response.Write("Error: " + ex.Message);
                }
            }
            else
            {
                Response.Write("No file selected for upload.");
            }
        }

        protected void btnDownload_Click1(object sender, EventArgs e)
        {
            DownloadFile();
        }

        protected void btnUpload_Click1(object sender, EventArgs e)
        {
            UploadFile();
        }
    }
}
