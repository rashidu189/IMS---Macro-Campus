﻿using System;
using System.IO;
using System.Web.UI;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class UploadFile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            /* Upload File
            if (IsPostBack)
            {
                if (Request.Files.Count > 0)
                {
                    var fileUploadControl = Request.Files[0]; // Assuming the file input is the first file
                    Response.Write($"File Upload Attempt: {fileUploadControl.FileName}");

                    if (fileUploadControl != null && fileUploadControl.ContentLength > 0)
                    {
                        try
                        {
                            string fileName = Path.GetFileName(fileUploadControl.FileName);
                            string uploadPath = @"D:\Final Project IMS System\IMS System - MACRO CAMPUS\Share Folder\Student\Upload Files\" + fileName;
                            fileUploadControl.SaveAs(uploadPath);
                            Response.Write("Upload successful!");
                        }
                        catch (Exception ex)
                        {
                            Response.Write("Error: " + ex.Message);
                        }
                    }
                    else
                    {
                        Response.Write("No file selected for upload.");
                    }
                }
                else
                {
                    Response.Write("No files found in the request.");
                }
            }*/

            if (IsPostBack)
            {
                UploadFile1();
            }
        }
        private void UploadFile1()
        {
            if (fileUploadControl.HasFile)
            {
                try
                {
                    string fileName = Path.GetFileName(fileUploadControl.FileName);
                    string uploadPath = @"D:\Final Project IMS System\IMS System - MACRO CAMPUS\Share Folder\Student\Upload Files\" + fileName; // Save to a relative path within your project
                    fileUploadControl.SaveAs(uploadPath);
                    Response.Write("Upload successful!");
                }
                catch (Exception ex)
                {
                    Response.Write("Error: " + ex.Message);
                }
            }
            else
            {
                Response.Write("No file selected for upload.");
            }
        }
    }
}