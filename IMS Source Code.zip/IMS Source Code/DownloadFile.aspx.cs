﻿using System;
using System.IO;
using System.Web;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class DownloadFile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            // Download File
            string filePath = Request.QueryString["file"];

            if (File.Exists(filePath))
            {
                try
                {
                    // Get the file bytes
                    byte[] fileBytes = File.ReadAllBytes(filePath);

                    // Set the response headers for file download
                    Response.Clear();
                    Response.ContentType = "application/html"; // Change based on file type
                    Response.AddHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
                    Response.BinaryWrite(fileBytes);
                    Response.End();
                    string imageUrl = "Resources/success.png";
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Downloaded.";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-success";
                }
                catch (Exception ex)
                {
                    //Response.Write("Error: " + ex.Message);
                    string imageUrl = "Resources/error.png";
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Error: " + ex.Message + "";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-danger";
                }
            }
            else
            {
                Response.Write("File not found.");
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> File not found.";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger";
            }


        }
    }
}