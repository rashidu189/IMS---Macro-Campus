﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class best_practice : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");

        protected void Page_Load(object sender, EventArgs e)
        {
            string user_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("std_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                    user_id = Session["User_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }



            //Course Card

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "loadCourses", "loadCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


            //For the Payment

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "PaymentCourses", "PaymentCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
        public class Course
        {
            public string CourseName { get; set; }
            public string BatchNo { get; set; }
            public string Status { get; set; }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("mycoursepage.aspx");
            /*// Register JavaScript to be executed on the client-side
            string script = "window.location.href = 'mycoursepage.aspx';";
            ClientScript.RegisterStartupScript(this.GetType(), "redirect", script, true);*/
        }
    }
}