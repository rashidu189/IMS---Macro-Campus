﻿using CrystalDecisions.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Html2pdf;
using System.IO;
using iText.Forms.Form.Element;
using System.Drawing.Printing;
using System.Drawing;
using CrystalDecisions.ReportAppServer.ReportDefModel;
using System.Security.Policy;
using System.Data.SqlClient;
using System.Data;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string ViewFileName = string.Empty;
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void GenerateCertificateButton_Click(object sender, EventArgs e)
        {
            string StudentName = TextBox1.Text.Trim();
            string CourseName = DropDownList4.SelectedValue;
            string Grade = TextBox5.Text.Trim();
            string CEndDate = TextBox7.Text.Trim();

            // Generate the certificate PDF
            GenerateCertificate(StudentName, CourseName, Grade, CEndDate, "~/images/M logo.png", "~/images/Signature/signatureM.png", "~/images/Signature/signatureR.png");

            string imageUrl1 = "Resources/info.png"; // Update this to the actual path of your image
            string message1 = $"<img src='{imageUrl1}' alt='Info Image' style='width:20px;height:20px;' /> Student Name : "+StudentName+" Certificate is Generated Successfully.Please Click Download Button and Download it.";

            Session["AlertMessage"] = message1;
            Session["AlertType"] = "alert-info"; // Adding the alert type
        }

        public void GenerateCertificate(string name, string course, string grade, string completionDate, string imagePath, string SignatureM, string SignatureR)
        {
            string filePath = Server.MapPath("~/Certificate.pdf");
            string base64Logo;
            using (System.Drawing.Image image = System.Drawing.Image.FromFile(Server.MapPath(imagePath)))
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    image.Save(ms, image.RawFormat);
                    byte[] imageBytes = ms.ToArray();
                    base64Logo = Convert.ToBase64String(imageBytes);
                }
            }

            string base64LogoSignatureM;
            using (System.Drawing.Image image = System.Drawing.Image.FromFile(Server.MapPath(SignatureM)))
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    image.Save(ms, image.RawFormat);
                    byte[] imageBytes = ms.ToArray();
                    base64LogoSignatureM = Convert.ToBase64String(imageBytes);
                }
            }

            string base64LogoSignatureR;
            using (System.Drawing.Image image = System.Drawing.Image.FromFile(Server.MapPath(SignatureR)))
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    image.Save(ms, image.RawFormat);
                    byte[] imageBytes = ms.ToArray();
                    base64LogoSignatureR = Convert.ToBase64String(imageBytes);
                }
            }

            string htmlContent = $@"
                                    <html>
                                        <head>
                                            <style>
                                                body {{
                                                    font-family: Arial, sans-serif;
                                                    background-color: #f4f4f4;
                                                    display: flex;
                                                    justify-content: center;
                                                    align-items: center;
                                                    height: 100vh;
                                                    margin: 0;
                                                }}
                                                .certificate {{
                                                    width: 630px;
                                                    height: 900px;
                                                    padding: 20px;
                                                    border: 10px solid #003DA5;
                                                    background-color: #fff;
                                                    box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.3);
                                                    text-align: center;
                                                    position: relative;
                                                }}
                                                .certificate .logo {{
                                                    margin-bottom: 20px;
                                                }}
                                                .certificate .header {{
                                                    font-size: 28px;
                                                    font-weight: bold;
                                                    color: #003DA5;
                                                    margin-bottom: 10px;
                                                }}
                                                .certificate .sub-header {{
                                                    font-size: 20px;
                                                    margin-bottom: 10px;
                                                    color: #555;
                                                }}
                                                .certificate .name {{
                                                    font-size: 32px;
                                                    font-weight: bold;
                                                    color: #003DA5;
                                                    margin-top: 30px;
                                                }}
                                                .certificate .degree {{
                                                    font-size: 24px;
                                                    font-style: italic;
                                                    margin-top: 10px;
                                                }}
                                                .certificate .date {{
                                                    font-size: 18px;
                                                    margin-top: 30px;
                                                }}
                                                .certificate .signature-section {{
                                                    position: absolute;
                                                    bottom: 20px;
                                                    width: 100%;
                                                    display: flex;
                                                    justify-content: space-between;
                                                    padding: 0 50px;
                                                }}
                                                .certificate .signature-section .sign {{
                                                    font-size: 16px;
                                                    font-weight: bold;
                                                    color: #003DA5;
                                                    text-align: center;
                                                }}
                                                .footer {{
                                                    margin-top: 20px;
                                                    font-size: 12px;
                                                    color: #555;
                                                }}
                                                .signature-container {{display: flex;
                                                    justify-content: space-between; /* Distributes space between sections */
                                                    align-items: flex-end; /* Aligns items to the bottom */
                                                    margin-top: 100px; /* Space above the signature section */
                                                }}

                                                .signature-sectionR, .signature-sectionD {{width: 100%; /* Set width to allow some spacing */
                                                }}

                                                .sign {{text - align: center; /* Center align the text */
                                                }}

                                                .signature-image {{width: 100px; /* Image width */
                                                    height: auto; /* Maintain aspect ratio */
                                                    margin-bottom: -10px; /* Adjust for positioning */
                                                }}
                                                .sign p {{margin - top: 0; 
                                                  line-height: 1; 
                                                }}

                                            </style>
                                        </head>
                                        <body>
                                            <div class=""certificate"">
                                                <div class=""logo"">
                                                    <img src= ""data:image/png;base64,{base64Logo}"" alt=""MACRO Campus Logo"" width=""150"">
                                                </div>
                                                <div class=""header"">MACRO Campus</div>
                                                <div class=""sub-header"">Degree Program Certificate</div>
                                                <p>This certifies that</p>
                                                <div class=""name"">{name}</div>
                                                <p>has successfully completed the</p>
                                                <div class=""degree"">{course}</div>
                                                <p>with {grade} on this</p>
                                                <div class=""date"">{completionDate:MMMM dd, yyyy}</div>
                                                <div class=""row signature-container"">
                                                  <div class=""signature-sectionR"">
                                                    <div class=""sign left"">
                                                      <img src=""data:image/png;base64,{base64LogoSignatureM}"" alt=""Registrar Signature"" class=""signature-image"" />
                                                      <p>___________________</p>
                                                      <p>Registrar</p>
                                                    </div>
                                                  </div>
                                                  <div class=""signature-sectionD"">
                                                    <div class=""sign right"">
                                                      <img src=""data:image/png;base64,{base64LogoSignatureR}"" alt=""Director Signature"" class=""signature-image"" />
                                                      <p>___________________</p>
                                                      <p>Director</p>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class=""footer"">
                                                    MACRO Campus, 100 Kumaratunga Munidasa Mawatha, Colombo , Sri lanka
                                                </div>
                                            </div>
                                        </body>
                                    </html>";

            // Use FileStream to create the PDF
            using (FileStream stream = new FileStream(filePath, FileMode.Create))
            {
                HtmlConverter.ConvertToPdf(htmlContent, stream);
            }
        }

        protected void DownloadCertificateButton_Click(object sender, EventArgs e)
        {
            // Download the certificate
            DownloadCertificate("Certificate.pdf");

        }

        public void DownloadCertificate(string fileName)
        {
            string filePath = Server.MapPath(fileName);
            string StudentName = TextBox1.Text.Trim();
            string StudentId = TextBox6.Text.Trim();

            if (File.Exists(filePath))
            {
                // Set response headers for download
                Response.ContentType = "application/pdf";
                Response.AppendHeader("Content-Disposition", $"attachment; filename= \"{StudentId}_{StudentName}_{fileName}\"");
                Response.TransmitFile(filePath);
                Response.End();

            }
            else
            {
                // Handle the error if the file is missing
                Response.Write("<script>alert('Certificate not found.');</script>");
            }
        }
        protected void SearchStudent_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            string query = "SELECT [Course name] FROM userdetail_in_batch_tbl UBT WHERE UBT.[User Id] = '" + TextBox6.Text.Trim() + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandTimeout = 600;
            try
            {
                SqlDataReader reader = cmd.ExecuteReader();

                // Clear previous data
                DropDownList4.Items.Clear();

                // Bind DropDownList
                DropDownList4.DataSource = reader;
                DropDownList4.DataTextField = "Course name";
                DropDownList4.DataValueField = "Course name";
                DropDownList4.DataBind();
                reader.Close(); // Close the reader after binding

                // Optionally, select the first item if it exists
                if (DropDownList4.Items.Count > 0)
                {
                    DropDownList4.SelectedIndex = 0;
                    UpdateTextBoxes(DropDownList4.SelectedValue);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void UpdateTextBoxes(string selectedCourseName)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;"))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string sID = TextBox6.Text.ToString().Trim();
                string detailsQuery = "SELECT [User Id],[Full Name],[Email],[Course name],[Batch No],[Course End Date],[Status],[Grade] FROM userdetail_in_batch_tbl WHERE [User Id] = @StudentID AND [Course name] = @CourseName";

                using (SqlCommand detailsCmd = new SqlCommand(detailsQuery, con))
                {
                    detailsCmd.Parameters.AddWithValue("@CourseName", selectedCourseName);
                    detailsCmd.Parameters.AddWithValue("@StudentID", sID);
                    detailsCmd.CommandTimeout = 600;
                    try
                    {
                        SqlDataReader detailsReader = detailsCmd.ExecuteReader();

                        if (detailsReader.Read())
                        {

                            TextBox6.Text = detailsReader["User Id"].ToString();
                            TextBox1.Text = detailsReader["Full Name"].ToString();
                            TextBox7.Text = DateTime.Parse(detailsReader["Course End Date"].ToString()).ToString("MMMM dd, yyyy");
                            TextBox2.Text = detailsReader["Email"].ToString();
                            TextBox3.Text = detailsReader["Batch No"].ToString();
                            TextBox4.Text = detailsReader["Status"].ToString();
                            TextBox5.Text = detailsReader["Grade"].ToString();
                        }
                        detailsReader.Close(); // Close the reader after reading
                    }
                    catch (Exception ex)
                    {
                        // Handle the exception (e.g., log it, show a message to the user)
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTextBoxes(DropDownList4.SelectedValue);

            string selectedCourseName = DropDownList4.SelectedValue;
            UpdateTextBoxes(selectedCourseName);


        }
        protected void c_pendingApproval_Click(object sender, EventArgs e)
        {
            Response.Redirect("c_pending_approval_page.aspx");
        }
        protected void leaves_Approval_Click(object sender, EventArgs e)
        {
            Response.Redirect("attendance_pending_approval.aspx");
        }
        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminSelfAttendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminStudentAttendance.aspx");
        }
    }
}