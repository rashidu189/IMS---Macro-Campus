﻿using System;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Net;
using System.Web.Services;
using Org.BouncyCastle.Crypto.Generators;
using System.Security.Cryptography;
using System.Text;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class forgot_pwd : System.Web.UI.Page
    {
        private static string hashedPassword;

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //[System.Web.Services.WebMethod]
        /* public static string ResetPassword(string studentId, string email)
         {
             const string connectionString = @"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;";
             try
             {
                 if (string.IsNullOrEmpty(studentId) || string.IsNullOrEmpty(email))
                 {
                     return "Invalid input data.";
                 }

                 using (SqlConnection conn = new SqlConnection(connectionString))
                 {
                     conn.Open();
                     string query = "SELECT Email_ID FROM Student_TBL WHERE User_ID = @StudentId AND User_Status = 'Active'";
                     SqlCommand cmd = new SqlCommand(query, conn);
                     cmd.Parameters.AddWithValue("@StudentId", studentId);

                     var emailFromDb = cmd.ExecuteScalar();
                     if (emailFromDb == null || emailFromDb.ToString() != email)
                     {
                         return "Invalid Student ID or Email.";
                     }

                     // Generate new password
                     string newPassword = Guid.NewGuid().ToString().Substring(0, 8);

                     // Update password in database
                     string updateQuery = "UPDATE Student_TBL SET Password = @Password WHERE User_ID = @StudentId";
                     SqlCommand updateCmd = new SqlCommand(updateQuery, conn);
                     updateCmd.Parameters.AddWithValue("@Password", newPassword); // Consider hashing the password.
                     updateCmd.Parameters.AddWithValue("@StudentId", studentId);
                     updateCmd.ExecuteNonQuery();

                     // Send email
                     SendPasswordEmail(email, newPassword);

                     return "Password reset successfully. Check your email for the new password.";
                 }
             }
             catch (Exception ex)
             {
                 return "An error occurred: " + ex.Message;
             }
         }

         private static void SendPasswordEmail(string email, string newPassword)
         {
             using (MailMessage mail = new MailMessage())
             {
                 mail.From = new MailAddress("rashidumilan100@gmail.com");
                 mail.To.Add(email);
                 mail.Subject = "Password Reset";
                 mail.Body = $"Your new password is: {newPassword}";
                 mail.IsBodyHtml = false;

                 using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                 {
                     smtp.Credentials = new NetworkCredential("macrocampus0@gmail.com", "aiviexpbcbgzpwst");
                     smtp.EnableSsl = true;
                     smtp.Send(mail);
                 }
             }
         }*/


        [WebMethod]
        public static string ResetPassword(string studentId, string email)
        {
            const string connectionString = @"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;";

            if (string.IsNullOrWhiteSpace(studentId) || string.IsNullOrWhiteSpace(email))
            {
                return "Invalid input data.";
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT Email_ID FROM Student_TBL WHERE User_ID = @StudentId AND User_Status = 'Active'";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@StudentId", studentId);

                        var emailFromDb = cmd.ExecuteScalar()?.ToString().Trim();
                        if (emailFromDb == null || emailFromDb.ToString() != email)
                        {
                            return "Invalid Student ID or Email.";
                        }
                    }

                    // Generate and hash new password
                    string newPassword = Guid.NewGuid().ToString().Substring(0, 8);  // Reduced the length of the password
                    using (SHA256 sha256Hash = SHA256.Create())
                    {
                        byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(newPassword));
                        StringBuilder builder = new StringBuilder();
                        foreach (byte b in bytes)
                        {
                            builder.Append(b.ToString("x2"));
                        }
                        hashedPassword = builder.ToString();
                        hashedPassword = hashedPassword.Substring(0, 8);
                        //string newPassword = Guid.NewGuid().ToString().Substring(0, 2);
                        //string hashedPassword = BCrypt.Net.BCrypt.HashPassword(newPassword);

                        string updateQuery = "UPDATE Student_TBL SET Password = @Password WHERE User_ID = @StudentId";
                        using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                        {
                            updateCmd.Parameters.AddWithValue("@Password", hashedPassword);
                            updateCmd.Parameters.AddWithValue("@StudentId", studentId);
                            // updateCmd.Parameters.Add("@Password", System.Data.SqlDbType.NVarChar).Value = hashedPassword;
                            // updateCmd.Parameters.Add("@StudentId", System.Data.SqlDbType.NVarChar).Value = studentId;
                            updateCmd.ExecuteNonQuery();
                        }
                    }
                    // Send email
                    SendPasswordEmail(email, hashedPassword);
                    return "Password reset successfully. Check your email for the new password.";
                }
            }
            catch (Exception ex)
            {
                return "An error occurred: " + ex.Message;
            }
        }

        private static void SendPasswordEmail(string email, string hashedPassword)
        {
            using (MailMessage mail = new MailMessage())
            {
                mail.From = new MailAddress("rashidumilan100@gmail.com");
                mail.To.Add(email);
                mail.Subject = "Password Reset";
                mail.Body = $"Your new password is: {hashedPassword}";
                mail.IsBodyHtml = false;

                using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                {
                    smtp.Credentials = new NetworkCredential("macrocampus0@gmail.com", "xbjr lcxs yree pgjf");
                    smtp.EnableSsl = true;
                    smtp.Send(mail);
                }
            }
        }
    }
}