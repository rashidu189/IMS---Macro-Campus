﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        /*SqlConnection con;*/
        protected void Page_Load(object sender, EventArgs e)
        {
            string user_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("std_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                    user_id = Session["User_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }



            //Course Card

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "loadCourses", "loadCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


            //For the Payment

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "PaymentCourses", "PaymentCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("std_user"))
                {
                    TextBox1.Text = Session["Full_Name"].ToString();
                    TextBox2.Text = Session["User_ID"].ToString();
                    TextBox3.Text = Session["Email_ID"].ToString();
                    TextBox4.Text = Session["Contact_No"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            /*
            if (!IsPostBack)
            {
                if (Request.QueryString["courseName"] != null)
                {
                    string courseName = Server.UrlDecode(Request.QueryString["courseName"]);
                    TextBox6.Text = courseName;
                }
            }*/

            if (!IsPostBack)
            {
                if (Request.QueryString["courseName"] != null)
                {
                    string courseName = Server.UrlDecode(Request.QueryString["courseName"]);
                    TextBox6.Text = courseName;
                }

                if (Request.QueryString["facultyName"] != null)
                {
                    string facultyName = Server.UrlDecode(Request.QueryString["facultyName"]);
                    TextBox5.Text = facultyName;
                }

                if (Request.QueryString["courses"] != null)
                {
                    string courses = Server.UrlDecode(Request.QueryString["courses"]);
                    TextBox7.Text = courses;
                }

                if (Request.QueryString["coursetype"] != null)
                {
                    string coursetype = Server.UrlDecode(Request.QueryString["coursetype"]);
                    TextBox8.Text = coursetype;
                }
            }




        }
        protected void UploadButton_Click(object sender, EventArgs e)
        {
            string student_id = TextBox2.Text.Trim();
            string student_name = TextBox1.Text.Trim();
            string student_email_id = TextBox3.Text.Trim();
            string student_contactNo = TextBox4.Text.Trim();
            string courseName = TextBox6.Text.Trim();
            string facultiesName = TextBox5.Text.Trim();
            string coursesName = TextBox7.Text.Trim();
            string courseType = TextBox8.Text.Trim();
            DateTime RegDate = DateTime.Now;
            string status = "Ongoing";

                if (FileUpload1.HasFile)
                {
                    try
                    {
                        // Sanitize student name and student ID to avoid special characters
                        student_name = SanitizeFileName(student_name);
                        student_id = SanitizeFileName(student_id);

                        string dateTime = DateTime.Now.ToString("yyyyMMddHHmmss");
                        string fileExtension = Path.GetExtension(FileUpload1.FileName);
                        string filename = $"{student_name}_{student_id}_{dateTime}{fileExtension}";

                        string uploadPath = @"D:\Final Project IMS System\IMS System - MACRO CAMPUS\Share Folder\QualificationDoc\" + filename;
                        FileUpload1.SaveAs(uploadPath);

                    // Optionally, show a success message
                    //Response.Write("File uploaded successfully with name: " + filename);
                      string imageUrl2 = "Resources/success.png";
                        string message2 = $"<img src='{imageUrl2}' alt='Success Image' style='width:20px;height:20px;' /> File uploaded successfully with name: " + filename;

                        Session["AlertMessage"] = message2;
                        Session["AlertType"] = "alert-success"; // Adding the alert type

                    using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;"))
                    {
                        if (courseType.Trim() == "Internal Courses")
                        {

                            con.Open();
                            SqlCommand checkCmd = con.CreateCommand();
                            checkCmd.CommandType = System.Data.CommandType.Text;

                            checkCmd.CommandText = "SELECT COUNT(*) FROM course_reg_req_tbl WHERE [Course Name] = @CourseName AND [User ID] = @UserId";
                            checkCmd.Parameters.AddWithValue("@CourseName", courseName);
                            checkCmd.Parameters.AddWithValue("@UserId", student_id);

                            int courseCount = (int)checkCmd.ExecuteScalar();
                            con.Close();
                            if (courseCount > 0)
                            {
                                // Course already exists, set duplicate message
                                string imageUrl = "Resources/error.png"; // Update this to the actual path of your error image
                                string message = $"<img src='{imageUrl}' alt='Error Image' style='width:20px;height:20px;' /> You have already requested this course before, so it cannot be done again!";
                                Session["AlertMessage"] = message;
                                Session["AlertType"] = "alert-danger"; // Alert type for error

                            }
                            else
                            {
                                // Insert Data
                                con.Open();
                                SqlCommand cmd = con.CreateCommand();
                                cmd.CommandType = System.Data.CommandType.Text;
                                cmd.CommandText = "INSERT INTO course_reg_req_tbl ([User ID], [Full Name], [Email], [Contact No], [Course Name], [Faculties], [Courses], [Course Type], [Is Approved]) " +
                                                  "VALUES (@UserID, @FullName, @Email, @ContactNo, @CourseName, @Faculties, @Courses, @CourseType, 0)";
                                cmd.Parameters.AddWithValue("@UserID", student_id);
                                cmd.Parameters.AddWithValue("@FullName", student_name);
                                cmd.Parameters.AddWithValue("@Email", student_email_id);
                                cmd.Parameters.AddWithValue("@ContactNo", student_contactNo);
                                cmd.Parameters.AddWithValue("@CourseName", courseName);
                                cmd.Parameters.AddWithValue("@Faculties", facultiesName);
                                cmd.Parameters.AddWithValue("@Courses", coursesName);
                                cmd.Parameters.AddWithValue("@CourseType", courseType);
                                cmd.ExecuteNonQuery();
                                con.Close();

                                string imageUrl3 = "Resources/success.png";
                                string message3 = $"<img src='{imageUrl3}' alt='Success Image' style='width:20px;height:20px;' /> Your Course Request is Succesfully Updated";

                                Session["AlertMessage"] = message3;
                                Session["AlertType"] = "alert-success"; // Adding the alert type
                            }

                        }
                        else if (courseType.Trim() == "External Courses")
                        {
                            con.Open();
                            SqlCommand checkCmd = con.CreateCommand();
                            checkCmd.CommandType = System.Data.CommandType.Text;

                            checkCmd.CommandText = "SELECT COUNT(*) FROM external_course_reg_tbl WHERE [Course Name] = @CourseName AND [User Id] = @UserId";
                            checkCmd.Parameters.AddWithValue("@CourseName", courseName);
                            checkCmd.Parameters.AddWithValue("@UserId", student_id);

                            int courseCount = (int)checkCmd.ExecuteScalar();
                            con.Close();
                            if (courseCount > 0)
                            {
                                // Course already exists, set duplicate message
                                string imageUrl = "Resources/error.png"; // Update this to the actual path of your error image
                                string message = $"<img src='{imageUrl}' alt='Error Image' style='width:20px;height:20px;' /> You have already registered for this course, so you cannot register again!";
                                Session["AlertMessage"] = message;
                                Session["AlertType"] = "alert-danger"; // Alert type for error

                            }
                            else
                            {
                                // Insert Data
                                con.Open();
                                SqlCommand cmd = con.CreateCommand();
                                cmd.CommandType = System.Data.CommandType.Text;
                                cmd.CommandText = "INSERT INTO external_course_reg_tbl ([User ID], [Full Name], [Email], [Course Name], [Registered Date], [Status]) " +
                                                  "VALUES (@UserID, @FullName, @Email, @CourseName, @RegisteredDate, @Status)";
                                cmd.Parameters.AddWithValue("@UserID", student_id);
                                cmd.Parameters.AddWithValue("@FullName", student_name);
                                cmd.Parameters.AddWithValue("@Email", student_email_id);
                                cmd.Parameters.AddWithValue("@CourseName", courseName);
                                cmd.Parameters.AddWithValue("@RegisteredDate", RegDate);
                                cmd.Parameters.AddWithValue("@Status", status);
                                cmd.ExecuteNonQuery();
                                con.Close();

                                string imageUrl4 = "Resources/success.png";
                                string message4 = $"<img src='{imageUrl4}' alt='Success Image' style='width:20px;height:20px;' /> Your Course Request is Succesfully Updated";

                                Session["AlertMessage"] = message4;
                                Session["AlertType"] = "alert-success"; // Adding the alert type
                            }
                        }
                    }

                }
                    catch (Exception ex)
                    {
                        // Handle the exception
                        //Response.Write("File upload failed: " + ex.Message);
                        string imageUrl3 = "Resources/error.png";
                        string message3 = $"<img src='{imageUrl3}' alt='Success Image' style='width:20px;height:20px;' /> File upload failed: " + ex.Message;

                        Session["AlertMessage"] = message3;
                        Session["AlertType"] = "alert-danger"; // Adding the alert type
                    }
                }
                else
                {
                    // No file was uploaded
                    //Response.Write("Please select a file to upload.");
                    string imageUrl4 = "Resources/error.png";
                    string message4 = $"<img src='{imageUrl4}' alt='Success Image' style='width:20px;height:20px;' /> Please select a file to upload.";

                    Session["AlertMessage"] = message4;
                    Session["AlertType"] = "alert-danger"; // Adding the alert type
                }
            




        }

        // Method to sanitize file names
        private string SanitizeFileName(string fileName)
        {
            foreach (char c in Path.GetInvalidFileNameChars())
            {
                fileName = fileName.Replace(c, '_');
            }
            return fileName;
        }

        public class Course
        {
            public string CourseName { get; set; }
            public string BatchNo { get; set; }
            public string Status { get; set; }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("mycoursepage.aspx");
            /*// Register JavaScript to be executed on the client-side
            string script = "window.location.href = 'mycoursepage.aspx';";
            ClientScript.RegisterStartupScript(this.GetType(), "redirect", script, true);*/
        }
    }
}