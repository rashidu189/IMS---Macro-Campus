﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Runtime.InteropServices;
using System.Xml.Linq;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web.Services;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class loginpage : System.Web.UI.Page
    {
        private static string hashedPassword;
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd2 = con.CreateCommand();
            cmd2.CommandType = System.Data.CommandType.Text;
            cmd2.CommandText = "SELECT * FROM Student_TBL WHERE User_ID = '" + member_id.Text.ToString() + "' and Password = '" + Password.Text.ToString() + "'";
            SqlDataReader dr2 = cmd2.ExecuteReader();
            if (dr2.Read())
            {
                Session["User_ID"] = dr2.GetValue(1).ToString().Trim();
                Session["Full_Name"] = dr2.GetValue(2).ToString().Trim();
                Session["First_Name"] = dr2.GetValue(3).ToString().Trim();
                Session["Middle_Name"] = dr2.GetValue(4).ToString().Trim();
                Session["Last_Name"] = dr2.GetValue(5).ToString().Trim();
                Session["DOB"] = dr2.GetValue(6).ToString().Trim();
                Session["Contact_No"] = dr2.GetValue(7).ToString().Trim();
                Session["Email_ID"] = dr2.GetValue(8).ToString().Trim();
                Session["Full_Address"] = dr2.GetValue(9).ToString().Trim();
                Session["Gender"] = dr2.GetValue(10).ToString().Trim();
                Session["Civil_Status"] = dr2.GetValue(11).ToString().Trim();
                Session["Nationality"] = dr2.GetValue(12).ToString().Trim();
                Session["National_Identity_Card"] = dr2.GetValue(13).ToString().Trim();
                Session["Password"] = dr2.GetValue(14).ToString().Trim();
                Session["User_Type"] = dr2.GetValue(15).ToString().Trim();
                Session["User_Status"] = dr2.GetValue(16).ToString().Trim();
                Session["role"] = "std_user";

                con.Close();

                string STDuserStatus = "Active";
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT COUNT(*) FROM Student_TBL WHERE User_ID = '" + member_id.Text.ToString() + "' and Password = '" + Password.Text.ToString() + "' and User_Status = '"+STDuserStatus+"' ";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                string memId = member_id.Text.ToString();
                string mempwd = Password.Text.ToString();
                cmd.ExecuteNonQuery();

                if (dt.Rows[0][0].ToString() == "1")
                {
                    try
                    {

                        using (SqlCommand cmd1 = new SqlCommand("SELECT User_Type,First_Name FROM Student_TBL WHERE User_ID = @user_id AND Password = @password", con))
                        {
                            cmd1.CommandType = System.Data.CommandType.Text;
                            cmd1.Parameters.AddWithValue("@user_id", member_id.Text.ToString());
                            cmd1.Parameters.AddWithValue("@password", Password.Text.ToString());

                            using (SqlDataReader dr = cmd1.ExecuteReader())
                            {
                                if (dr.Read())
                                {
                                    string F_Name = dr["First_Name"].ToString();
                                    string U_Type = dr["User_Type"].ToString().Trim();
                                    if (U_Type == "Student")
                                    {
                                        string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                                        string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Hi " + F_Name + ", you've successfully logged in. Welcome to the MACRO Campus";

                                        Session["AlertMessage"] = message;
                                        Session["AlertType"] = "alert-success"; // Adding the alert type
                                        Response.Redirect("studenthomepage.aspx");  // Redirect to refresh the page

                                    }
                                    else if (U_Type == "Lecturer")
                                    {
                                        string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                                        string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Hi " + F_Name + ", you've successfully logged in. Welcome to the MACRO Campus";

                                        Session["AlertMessage"] = message;
                                        Session["AlertType"] = "alert-success"; // Adding the alert type
                                        Response.Redirect("lecturer_homepage.aspx");  // Redirect to refresh the page

                                    }
                                    else if (U_Type == "Administrator")
                                    {
                                        string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                                        string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Hi " + F_Name + ", you've successfully logged in. Welcome to the MACRO Campus";

                                        Session["AlertMessage"] = message;
                                        Session["AlertType"] = "alert-success"; // Adding the alert type
                                        Response.Redirect("admin_home_page.aspx");  // Redirect to refresh the page

                                    }
                                }
                                else
                                {
                                    Response.Write("<script>alert('Unknown user')</script>");
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle exception (log it and/or display a message)
                        Response.Write("<script>alert('Error: " + ex.Message + "')</script>");
                    }
                }
                else
                {
                    string imageUrl = "Resources/error.png"; // Update this to the actual path of your image
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Login failed. Please check your username and password and try again.";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-danger"; // Adding the alert type
                                                           //ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Please Try Again later');", true);
                }
                con.Close();
            }
            else
            {
                con.Close();

                con.Open();
                SqlCommand cmd3 = con.CreateCommand();
                cmd3.CommandType = System.Data.CommandType.Text;
                cmd3.CommandText = "SELECT * FROM Employee_TBL WHERE Employee_ID = '" + member_id.Text.ToString() + "' and Password = '" + Password.Text.ToString() + "'";
                SqlDataReader dr3 = cmd3.ExecuteReader();
                if (dr3.Read())
                {
                    Session["Employee_ID"] = dr3.GetValue(1).ToString().Trim();
                    Session["Full_Name"] = dr3.GetValue(2).ToString().Trim();
                    Session["First_Name"] = dr3.GetValue(3).ToString().Trim();
                    Session["Middle_Name"] = dr3.GetValue(4).ToString().Trim();
                    Session["Last_Name"] = dr3.GetValue(5).ToString().Trim();
                    Session["DOB"] = dr3.GetValue(6).ToString().Trim();
                    Session["Contact_No"] = dr3.GetValue(7).ToString().Trim();
                    Session["Email_ID"] = dr3.GetValue(8).ToString().Trim();
                    Session["Full_Address"] = dr3.GetValue(9).ToString().Trim();
                    Session["Gender"] = dr3.GetValue(10).ToString().Trim();
                    Session["Civil_Status"] = dr3.GetValue(11).ToString().Trim();
                    Session["Nationality"] = dr3.GetValue(12).ToString().Trim();
                    Session["National_Identity_Card"] = dr3.GetValue(13).ToString().Trim();
                    Session["Password"] = dr3.GetValue(14).ToString().Trim();
                    Session["User_Type"] = dr3.GetValue(15).ToString().Trim();
                    Session["User_Status"] = dr3.GetValue(16).ToString().Trim();
                    Session["Faculty"] = dr3.GetValue(17).ToString().Trim();
                    Session["Job_Tittle"] = dr3.GetValue(18).ToString().Trim();
                    Session["Qualification_Level"] = dr3.GetValue(19).ToString().Trim();
                    Session["Salary"] = dr3.GetValue(20).ToString().Trim();
                    Session["Joined_Date"] = dr3.GetValue(21).ToString().Trim();
                    Session["Qualification"] = dr3.GetValue(22).ToString().Trim();
                    Session["Work_Experience"] = dr3.GetValue(23).ToString().Trim();
                    Session["role"] = "emp_user";
                }
                con.Close();

                string EMPuserStatus = "Active";
                con.Open();
                SqlCommand cmd4 = con.CreateCommand();
                cmd4.CommandType = System.Data.CommandType.Text;
                cmd4.CommandText = "SELECT COUNT(*) FROM Employee_TBL WHERE Employee_ID = '" + member_id.Text.ToString() + "' and Password = '" + Password.Text.ToString() + "' and User_Status = '"+EMPuserStatus+"' ";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd4);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                string memId = member_id.Text.ToString();
                string mempwd = Password.Text.ToString();
                cmd4.ExecuteNonQuery();

                if (dt.Rows[0][0].ToString() == "1")
                {
                    try
                    {

                        using (SqlCommand cmd1 = new SqlCommand("SELECT User_Type,First_Name FROM Employee_TBL WHERE Employee_ID = @user_id AND Password = @password", con))
                        {
                            cmd1.CommandType = System.Data.CommandType.Text;
                            cmd1.Parameters.AddWithValue("@user_id", member_id.Text.ToString());
                            cmd1.Parameters.AddWithValue("@password", Password.Text.ToString());

                            using (SqlDataReader dr = cmd1.ExecuteReader())
                            {
                                if (dr.Read())
                                {
                                    string F_Name = dr["First_Name"].ToString();
                                    string U_Type = dr["User_Type"].ToString().Trim();
                                    if (U_Type == "Student")
                                    {
                                        string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                                        string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Hi " + F_Name + ", you've successfully logged in. Welcome to the MACRO Campus";

                                        Session["AlertMessage"] = message;
                                        Session["AlertType"] = "alert-success"; // Adding the alert type
                                        Response.Redirect("studenthomepage.aspx");  // Redirect to refresh the page

                                    }
                                    else if (U_Type == "Lecturer")
                                    {
                                        string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                                        string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Hi " + F_Name + ", you've successfully logged in. Welcome to the MACRO Campus";

                                        Session["AlertMessage"] = message;
                                        Session["AlertType"] = "alert-success"; // Adding the alert type
                                        Response.Redirect("lecturer_homepage.aspx");  // Redirect to refresh the page

                                    }
                                    else if (U_Type == "Administrator")
                                    {
                                        string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                                        string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Hi " + F_Name + ", you've successfully logged in. Welcome to the MACRO Campus";

                                        Session["AlertMessage"] = message;
                                        Session["AlertType"] = "alert-success"; // Adding the alert type
                                        Response.Redirect("dashboard_page.aspx");  // Redirect to refresh the page

                                    }
                                }
                                else
                                {
                                    Response.Write("<script>alert('Unknown user')</script>");
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle exception (log it and/or display a message)
                        Response.Write("<script>alert('Error: " + ex.Message + "')</script>");
                    }
                }
                else
                {
                    string imageUrl = "Resources/error.png"; // Update this to the actual path of your image
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Login failed. Please check your username and password and try again.";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-danger"; // Adding the alert type
                                                           //ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Please Try Again later');", true);
                }
                con.Close();

            }
            



           
            
        }

        protected void Password_TextChanged(object sender, EventArgs e)
        {

        }
        
        [WebMethod]
        public static string ResetPassword(string userFId, string email)
        {
            const string connectionString = @"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;";

            if (string.IsNullOrWhiteSpace(userFId) || string.IsNullOrWhiteSpace(email))
            {
                return "Invalid input data.";
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT Email_ID FROM Student_TBL WHERE User_ID = @StudentId AND User_Status = 'Active'";
                    using (SqlCommand cmd6 = new SqlCommand(query, conn))
                    {
                        cmd6.Parameters.AddWithValue("@StudentId", userFId);

                        var emailFromDb = cmd6.ExecuteScalar()?.ToString().Trim();
                        if (emailFromDb == null || emailFromDb.ToString() != email)
                        {
                            //return "Invalid User ID or Email.";

                            string queryE = "SELECT Email_ID FROM Employee_TBL WHERE Employee_ID = @EmployeeId AND User_Status = 'Active'";
                            using (SqlCommand cmd7 = new SqlCommand(queryE, conn))
                            {
                                cmd7.Parameters.AddWithValue("@EmployeeId", userFId);

                                var emailFromDb1 = cmd7.ExecuteScalar()?.ToString().Trim();
                                if (emailFromDb1 == null || emailFromDb1.ToString() != email)
                                {
                                    return "Invalid User ID or Email.";
                                }
                                else
                                {
                                    // Generate and hash new password
                                    string newPassword = Guid.NewGuid().ToString().Substring(0, 8);  // Reduced the length of the password
                                    using (SHA256 sha256Hash = SHA256.Create())
                                    {
                                        byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(newPassword));
                                        StringBuilder builder = new StringBuilder();
                                        foreach (byte b in bytes)
                                        {
                                            builder.Append(b.ToString("x2"));
                                        }
                                        hashedPassword = builder.ToString();
                                        hashedPassword = hashedPassword.Substring(0, 8);
                                        //string newPassword = Guid.NewGuid().ToString().Substring(0, 2);
                                        //string hashedPassword = BCrypt.Net.BCrypt.HashPassword(newPassword);

                                        string updateQuery = "UPDATE Employee_TBL SET Password = @Password WHERE Employee_ID = @EmployeeId";
                                        using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                                        {
                                            updateCmd.Parameters.AddWithValue("@Password", hashedPassword);
                                            updateCmd.Parameters.AddWithValue("@EmployeeId", userFId);
                                            // updateCmd.Parameters.Add("@Password", System.Data.SqlDbType.NVarChar).Value = hashedPassword;
                                            // updateCmd.Parameters.Add("@EmployeeId", System.Data.SqlDbType.NVarChar).Value = userId;
                                            updateCmd.ExecuteNonQuery();
                                        }
                                    }
                                }
                            }


                        }
                        else
                        {
                            // Generate and hash new password
                            string newPassword = Guid.NewGuid().ToString().Substring(0, 8);  // Reduced the length of the password
                            using (SHA256 sha256Hash = SHA256.Create())
                            {
                                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(newPassword));
                                StringBuilder builder = new StringBuilder();
                                foreach (byte b in bytes)
                                {
                                    builder.Append(b.ToString("x2"));
                                }
                                hashedPassword = builder.ToString();
                                hashedPassword = hashedPassword.Substring(0, 8);
                                //string newPassword = Guid.NewGuid().ToString().Substring(0, 2);
                                //string hashedPassword = BCrypt.Net.BCrypt.HashPassword(newPassword);

                                string updateQuery = "UPDATE Student_TBL SET Password = @Password WHERE User_ID = @StudentId";
                                using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                                {
                                    updateCmd.Parameters.AddWithValue("@Password", hashedPassword);
                                    updateCmd.Parameters.AddWithValue("@StudentId", userFId);
                                    // updateCmd.Parameters.Add("@Password", System.Data.SqlDbType.NVarChar).Value = hashedPassword;
                                    // updateCmd.Parameters.Add("@StudentId", System.Data.SqlDbType.NVarChar).Value = userId;
                                    updateCmd.ExecuteNonQuery();
                                }
                            }
                        }

                    }


                    // Send email
                    SendPasswordEmail(userFId, email, hashedPassword);
                    return "Password reset successfully. Check your email for the new password.";
                }
            }
            catch (Exception ex)
            {
                return "An error occurred: " + ex.Message;
            }
        }

        private static void SendPasswordEmail(string userFId, string email, string hashedPassword)
        {
            string fullNameFromDb = string.Empty;
            const string connectionString = @"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT Full_Name FROM Student_TBL WHERE User_ID = @StudentId AND User_Status = 'Active'";
                using (SqlCommand cmd8 = new SqlCommand(query, conn))
                {
                    cmd8.Parameters.AddWithValue("@StudentId", userFId);
                    fullNameFromDb = cmd8.ExecuteScalar()?.ToString().Trim();
                    if (fullNameFromDb == null)
                    {
                        string queryE = "SELECT Full_Name FROM Employee_TBL WHERE Employee_ID = @EmployeeId AND User_Status = 'Active'";
                        using (SqlCommand cmd9 = new SqlCommand(queryE, conn))
                        {
                            cmd9.Parameters.AddWithValue("@EmployeeId", userFId);
                            fullNameFromDb = cmd9.ExecuteScalar()?.ToString().Trim();
                        }
                    }
                }
            }


            using (MailMessage mail = new MailMessage())
            {
                mail.From = new MailAddress("rashidumilan100@gmail.com");
                mail.To.Add(email);
                mail.Subject = "Password Reset";
                mail.Body = $@"<html>
                                <head>
                                    <style>
                                        body {{{{ font-family: Arial, sans-serif; }}}}
                                        .container {{{{ margin: 20px; padding: 10px; }}}}
                                        .content {{{{ font-size: 16px; }}}}
                                        .footer {{{{ margin-top: 20px; font-size: 12px; color: gray; }}}}
                                    </style>
                                </head>
                                <body>
                                    <div class='container'>
                                        <div class='content'>
                                            <p>Dear {fullNameFromDb},</p>
                                            <p>Your new password is: <strong>{hashedPassword}</strong></p>
                                            <p>If you did not request this change, please contact support immediately.</p>
                                        </div>
                                        <div class='footer'>
                                            <p>Best regards,</p>
                                            <br>MACRO Support Team.....
            
                                        </div>
                                    </div>
                                </body>
                                <br><hr style=""font-family: arial, sans-serif; font-size: 10pt;color:#e74c3c;""><table cellpadding=""10px"">
                                                        <tr><td colspan=""3"" style=""background-color:white;color:#e74c3c text-align:center;""><b>© Note: This is an auto generated email. Please don't reply to this email.</b></td>
                                                        </tr><tr><td style=""background-color:#e74c3c;color:white;text-align:center;"">©</td>
                                                        <td style=""background-color:#e74c3c;color:white;text-align:center;"">MACRO</td>
                                                        <td style=""background-color:#e74c3c;color:white;text-align:center;"">MACRO CAMPUS SYSTEM</table>

                                </div>  
                                </html>";
                mail.IsBodyHtml = true;

                using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                {
                    smtp.Credentials = new NetworkCredential("macrocampus0@gmail.com", "xbjr lcxs yree pgjf");
                    smtp.EnableSsl = true;
                    smtp.Send(mail);
                }
            }
        }
    }
}