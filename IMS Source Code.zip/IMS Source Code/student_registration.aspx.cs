﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Web;
using System.Web.Helpers;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IMS_System___MACRO_CAMPUS
{

    public partial class member_registration : System.Web.UI.Page
    { 
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        /*SqlConnection con;*/
        
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


        }
        
        
        protected void Button1_Click(object sender, EventArgs e)
        {
            /*string gender = string.Empty;
            if (RadioButton1.Checked)
            {
                gender = "Male";
            }
            else if (RadioButton2.Checked)
            {
                gender = "Female";
            }
            else
            {
                Response.Write("Please select a gender.");
                return;
            }

            string civilstatus = string.Empty;
            if (!string.IsNullOrEmpty(DropDownList1.SelectedValue))
            {
                civilstatus = DropDownList1.SelectedValue;
            }

            string nationality = string.Empty;
            if (!string.IsNullOrEmpty(DropDownList2.SelectedValue))
            {
                nationality = DropDownList2.SelectedValue;
            }

            string usertype = string.Empty;
            if (!string.IsNullOrEmpty(DropDownList5.SelectedValue))
            {
                usertype = DropDownList5.SelectedValue;
            }

            string userstatus = "Active";

             con.Open();
             SqlCommand cmd = con.CreateCommand();
             cmd.CommandType = System.Data.CommandType.Text;
             cmd.CommandText = "INSERT INTO Student_TBL(Full_Name,First_Name,Middle_Name,Last_Name,DOB,Contact_No,Email_ID,Full_Address,Gender,Civil_Status,Nationality,National_Identity_Card,Password,User_Type,User_Status) VALUES('" + fullname.Text.ToString() + "','" + firstname.Text.ToString() + "','" + middlename.Text.ToString() + "','" + lastname.Text.ToString() + "','" + dob.Text.ToString() + "','" + contactno.Text.ToString() + "','" + emailid.Text.ToString() + "','" + address.Text.ToString() + "','" + gender + "','" + civilstatus + "','" + nationality + "','" + nic.Text.ToString() + "','" + pwd.Text.ToString() + "','" + usertype + "','"+userstatus+"')";
             cmd.ExecuteNonQuery();
             con.Close();

             con.Open();
             SqlCommand cmd1 = con.CreateCommand();
             cmd1.CommandType = System.Data.CommandType.Text;
             cmd1.CommandText = "SELECT User_ID FROM Student_TBL WHERE National_Identity_Card = '" + nic.Text.ToString() + "'";
             SqlDataReader dr = cmd1.ExecuteReader();
             while (dr.Read())
            {
                user_id.Text = dr.GetValue(0).ToString();
                string imageUrl = "Resources/success.png";
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Student ID - " + user_id.Text.ToString().Trim() + " Successfully Added to the Macro System.";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-success";
                //Response.Redirect(Request.RawUrl); // Redirect to refresh the page
            }
            con.Close();*/


            /*SqlConnection con = new SqlConnection(con);
            con.Open();
            if (con.State == System.Data.ConnectionState.Open)
            {
                string q = "insert into user_tbl(full_name,first_name,middle_name,last_name,dob,contact_no,email_id,full_address,gender,civil_status,nationality,national_identity_card,user_type,password) values('" + fullname.Text.ToString() + "','" + firstname.Text.ToString() + "','" + middlename.Text.ToString() + "','" + lastname.Text.ToString() + "','" + dob.Text.ToString() + "','" + contactno.Text.ToString() + "','" + emailid.Text.ToString() + "','" + address.Text.ToString() + "','" + gender + "','" + civilstatus + "','" + nationality + "','" + nic.Text.ToString() + "','" + usertype + "','" + pwd.Text.ToString() + "')";
                SqlCommand cmd = con.CreateCommand();
                cmd.ExecuteNonQuery();
                
            }*/

            // Server-side validation
            if (string.IsNullOrEmpty(fullname.Text.Trim()))
            {
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> Full name is required.";
                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger";
                return;
            }
            if (string.IsNullOrEmpty(firstname.Text.Trim()))
            {
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> First name is required.";
                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger";
                return;
            }

            if (string.IsNullOrEmpty(lastname.Text.Trim()))
            {
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> Last name is required.";
                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger";
                return;
            }

            if (string.IsNullOrEmpty(emailid.Text.Trim()))
            {
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> Email is required.";
                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger";
                return;
            }

            if (string.IsNullOrEmpty(contactno.Text.Trim()) || contactno.Text.Length != 10)
            {
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> Please enter a valid 10-digit contact number.";
                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger";
                return;
            }

            if (string.IsNullOrEmpty(nic.Text.Trim()))
            {
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> National Identity Card is required.";
                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger";
                return;
            }
            if (string.IsNullOrEmpty(pwd.Text.Trim()))
            {
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> Student Password is required.";
                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger";
                return;
            }
            if (string.IsNullOrEmpty(dob.Text.Trim()))
            {
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> Date of Birth is required.";
                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger";
                return;
            }

            string gender = string.Empty;
            if (RadioButton1.Checked)
            {
                gender = "Male";
            }
            else if (RadioButton2.Checked)
            {
                gender = "Female";
            }
            else
            {
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Danger Image' style='width:20px;height:20px;' /> Please select a gender.";
                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger";
                return;
            }


            string civilstatus = string.Empty;
            if (!string.IsNullOrEmpty(DropDownList1.SelectedValue))
            {
                civilstatus = DropDownList1.SelectedValue;
            }

            string nationality = string.Empty;
            if (!string.IsNullOrEmpty(DropDownList2.SelectedValue))
            {
                nationality = DropDownList2.SelectedValue;
            }

            string usertype = string.Empty;
            if (!string.IsNullOrEmpty(DropDownList5.SelectedValue))
            {
                usertype = DropDownList5.SelectedValue;
            }

            string userstatus = "Active";

            // Check for duplicate National Identity Card or Email ID
            con.Open();
            SqlCommand cmdCheck = con.CreateCommand();
            cmdCheck.CommandType = System.Data.CommandType.Text;
            cmdCheck.CommandText = "SELECT COUNT(*) FROM Student_TBL WHERE National_Identity_Card = @NIC";
            cmdCheck.Parameters.AddWithValue("@NIC", nic.Text.ToString());

            int count = (int)cmdCheck.ExecuteScalar();
            con.Close();

            if (count > 0)
            {
                // If record exists, show a message and exit the function
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Error Image' style='width:20px;height:20px;' /> This Student National Identity Card is already Joined System!";
                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger";
                return;
            }

            // Proceed with the insert if no duplicates found
            con.Open();
            SqlCommand cmdInsert = con.CreateCommand();
            cmdInsert.CommandType = System.Data.CommandType.Text;
            cmdInsert.CommandText = "INSERT INTO Student_TBL(Full_Name,First_Name,Middle_Name,Last_Name,DOB,Contact_No,Email_ID,Full_Address,Gender,Civil_Status,Nationality,National_Identity_Card,Password,User_Type,User_Status) VALUES(@FullName, @FirstName, @MiddleName, @LastName, @DOB, @ContactNo, @Email, @Address, @Gender, @CivilStatus, @Nationality, @NIC, @Password, @UserType, @UserStatus)";

            cmdInsert.Parameters.AddWithValue("@FullName", fullname.Text.ToString());
            cmdInsert.Parameters.AddWithValue("@FirstName", firstname.Text.ToString());
            cmdInsert.Parameters.AddWithValue("@MiddleName", middlename.Text.ToString());
            cmdInsert.Parameters.AddWithValue("@LastName", lastname.Text.ToString());
            cmdInsert.Parameters.AddWithValue("@DOB", dob.Text.ToString());
            cmdInsert.Parameters.AddWithValue("@ContactNo", contactno.Text.ToString());
            cmdInsert.Parameters.AddWithValue("@Email", emailid.Text.ToString());
            cmdInsert.Parameters.AddWithValue("@Address", address.Text.ToString());
            cmdInsert.Parameters.AddWithValue("@Gender", gender);
            cmdInsert.Parameters.AddWithValue("@CivilStatus", civilstatus);
            cmdInsert.Parameters.AddWithValue("@Nationality", nationality);
            cmdInsert.Parameters.AddWithValue("@NIC", nic.Text.ToString());
            cmdInsert.Parameters.AddWithValue("@Password", pwd.Text.ToString());
            cmdInsert.Parameters.AddWithValue("@UserType", usertype);
            cmdInsert.Parameters.AddWithValue("@UserStatus", userstatus);

            cmdInsert.ExecuteNonQuery();
            con.Close();

            // Retrieve the newly inserted User_ID
            con.Open();
            SqlCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = System.Data.CommandType.Text;
            cmd1.CommandText = "SELECT User_ID FROM Student_TBL WHERE National_Identity_Card = @NIC";
            cmd1.Parameters.AddWithValue("@NIC", nic.Text.ToString());

            SqlDataReader dr = cmd1.ExecuteReader();
            while (dr.Read())
            {
                user_id.Text = dr.GetValue(0).ToString();
                string imageUrl = "Resources/success.png";
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Student ID - " + user_id.Text.ToString().Trim() + " Successfully Added to the Macro System.";
                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-success";

                using (MailMessage mail = new MailMessage())
                {
                    string email = emailid.Text.ToString().Trim();
                    string name = firstname.Text.ToString().Trim()+" "+lastname.Text.ToString().Trim();
                    string fName = fullname.Text.ToString();
                    string flName =  firstname.Text.ToString();
                    string mName =  middlename.Text.ToString();
                    string lName =  lastname.Text.ToString();
                    string ddob =  dob.Text.ToString();
                    string cNo = contactno.Text.ToString();
                    string add =  address.Text.ToString();
                    string g = gender;
                    string cS = civilstatus;
                    string n = nationality;
                    string nI = nic.Text.ToString();
                    string UId = user_id.Text.ToString();
                    string p = pwd.Text.ToString();
                    string url = "https://localhost:44343/loginpage.aspx";
                    mail.From = new MailAddress("rashidumilan100@gmail.com");
                    mail.To.Add(email);
                    mail.Subject = "Student Registration - '"+UId+"'";
                    mail.Body = $@"<html>
                                <head>
                                    <style>
                                        body {{{{ font-family: Arial, sans-serif; }}}}
                                        .container {{{{ margin: 20px; padding: 10px; }}}}
                                        .content {{{{ font-size: 16px; }}}}
                                        .footer {{{{ margin-top: 20px; font-size: 12px; color: gray; }}}}
                                    </style>
                                </head>
                                <body>
                                    <div class='container'>
                                        <div class='content'>
                                            <p><b>Dear {name},</b></p>
                                            <p>Welcome to the MACRO Campus, Congratulations on your admission to MACRO Campus!</P>
                                            <p>Completed your Registration Process, Please check your details and give us a confirmation Email.</p>
                                            <p>Your Full Name is    : <strong>{fName}</strong></p>
                                            <p>Your First Name is   : <strong>{flName}</strong></p>
                                            <p>Your Middle Name is  : <strong>{mName}</strong></p>
                                            <p>Your Last Name is    : <strong>{lName}</strong></p>
                                            <p>Your Date of Birth is: <strong>{ddob}</strong></p>
                                            <p>Your Contact No is   : <strong>{cNo}</strong></p>
                                            <p>Your Address is      : <strong>{add}</strong></p>
                                            <p>Your Gender is       : <strong>{g}</strong></p>
                                            <p>Your Civil Status is : <strong>{civilstatus}</strong></p>
                                            <p>Your NIC No is       : <strong>{nI}</strong></p>
                                            <p>Completed your Registration Process, Please check your details and give us a confirmation Email.</p>
                                        </div>
                                        <div Class='cred'>
                                         <p>Use the following Credentials to login to the MACRO System, After logging in, please change your password for security purposes.</p>
                                            <p>Your User ID is    : <strong>{UId}</strong></p>
                                            <p>Your Password is   : <strong>{p}</strong></p>
                                            <p>MACRO System URL   : <strong>{url}</strong></p>

                                        </div>
                                        <div class='footer'>
                                            <p>Best regards,</p>
                                            <br>MACRO Support Team.....
            
                                        </div>
                                    </div>
                                </body>
                                <br><hr style=""font-family: arial, sans-serif; font-size: 10pt;color:#e74c3c;""><table cellpadding=""10px"">
                                                        <tr><td colspan=""3"" style=""background-color:white;color:#e74c3c text-align:center;""><b>© Note: This is an auto generated email. Please don't reply to this email.</b></td>
                                                        </tr><tr><td style=""background-color:#e74c3c;color:white;text-align:center;"">©</td>
                                                        <td style=""background-color:#e74c3c;color:white;text-align:center;"">MACRO</td>
                                                        <td style=""background-color:#e74c3c;color:white;text-align:center;"">MACRO CAMPUS SYSTEM</table>

                                </div>  
                                </html>";
                    mail.IsBodyHtml = true;

                    using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                    {
                        smtp.Credentials = new NetworkCredential("macrocampus0@gmail.com", "xbjr lcxs yree pgjf");
                        smtp.EnableSsl = true;
                        smtp.Send(mail);
                    }
                }
            }
            con.Close();


        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        protected void c_pendingApproval_Click(object sender, EventArgs e)
        {
            Response.Redirect("c_pending_approval_page.aspx");
        }
        protected void leaves_Approval_Click(object sender, EventArgs e)
        {
            Response.Redirect("attendance_pending_approval.aspx");
        }
        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminSelfAttendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminStudentAttendance.aspx");
        }
    }
}