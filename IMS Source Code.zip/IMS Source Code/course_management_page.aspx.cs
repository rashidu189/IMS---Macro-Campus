﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static IMS_System___MACRO_CAMPUS.userhomepage;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class course_management_page : System.Web.UI.Page
    {
        string deleteCoursename = string.Empty;
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            string Emp_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("emp_user"))
                {

                    Emp_id = Session["Employee_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            if (!IsPostBack)
            {
                FillGridView();

            }
            /*if (!IsPostBack)
            {
                BatchGridView();
                SubjectGridView();

            }*/

        }
        protected void RefreshBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);

        }

        protected void SearchBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string courseName = TextBox3.Text.ToString().Trim();
                string faculty = TextBox2.Text.ToString().Trim();

                string query = @"SELECT [Id] AS [Course ID],[Course Name] AS [Course Name],[Faculty] AS [Faculty],[Total Amount] AS [Course Amount] FROM course_amount_tbl
                              WHERE [Course Name] LIKE @CourseName AND [Faculty] LIKE @Faculty ";

                // Open the connection
                if (con.State == ConnectionState.Closed)
                    con.Open();

                // Use SqlCommand to execute the query with parameters
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    // Add parameters to avoid SQL injection
                    cmd.Parameters.AddWithValue("@CourseName", "%" + courseName + "%");
                    cmd.Parameters.AddWithValue("@Faculty", "%" + faculty + "%");
                    cmd.CommandTimeout = 600;
                    // Execute the query and fill the data table
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // Close the connection
                    con.Close();

                    // Bind the results to the GridView
                    CourseManagement.DataSource = dt;
                    CourseManagement.DataBind();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void FillGridView()
        {

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                // Use a SQL query to select data from the table
                string query = "SELECT [Id] AS [Course ID],[Course Name] AS [Course Name],[Faculty] AS [Faculty],[Total Amount] AS [Course Amount] FROM course_amount_tbl";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                adapter.SelectCommand.CommandTimeout = 600;
                // No need to set the CommandType when using a SQL query
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                con.Close();

                CourseManagement.DataSource = dt;
                CourseManagement.DataBind();
            }
            catch (Exception ex)
            {
                Console.WriteLine (ex.Message);
            }

        }
        public void CourseManagement_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "Edit")
                {
                    int rowIndex = Convert.ToInt32(e.CommandArgument);

                    GridViewRow row = CourseManagement.Rows[rowIndex];

                    string courseName = row.Cells[1].Text.Trim();
                    string faculty = row.Cells[2].Text.Trim();

                    Response.Redirect("course_information_page.aspx?courseName=" + courseName + "&faculty=" + faculty);


                }
                else if (e.CommandName == "Delete")
                {
                    int rowIndex = Convert.ToInt32(e.CommandArgument);

                    GridViewRow row = CourseManagement.Rows[rowIndex];

                    string courseId = row.Cells[0].Text;
                    deleteCoursename = row.Cells[1].Text.Trim();
                    string faculty = row.Cells[2].Text.Trim();
                    string courseAmount = row.Cells[3].Text.Trim();



                    // Show the modal using JavaScript
                    ClientScript.RegisterStartupScript(this.GetType(), "showModal",
                        $"showModal({rowIndex}, '{courseId}', '{deleteCoursename}', '{faculty}', '{courseAmount}');",
                        true);


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        /*private void BatchGridView()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string courseName = Request.Form[TextBox1.UniqueID]?.Trim();
                // Correctly form the SQL query
                string query = "SELECT [Batch No] ,[Faculty] ,[Coordinator Id] ,[Coordinator] ,[Course Start Date] ,[Course End Date] ,[Count of Students] FROM batch_tbl WHERE [Course Name] = @courseName";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    // Use parameterized queries to avoid SQL injection
                    cmd.Parameters.AddWithValue("@courseName", deleteCoursename);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.SelectCommand.CommandTimeout = 600;

                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ViewBatchGrid.DataSource = dt;
                    ViewBatchGrid.DataBind();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            
        }
        private void SubjectGridView()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string courseName = Request.Form[TextBox1.UniqueID]?.Trim();
                // Correctly form the SQL query
                string query = "SELECT [Subject Id],[Subject No],[Subject Name],[Semester] FROM c_subject_tbl WHERE [Course name] = @courseName";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    // Use parameterized queries to avoid SQL injection
                    cmd.Parameters.AddWithValue("@courseName", deleteCoursename);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.SelectCommand.CommandTimeout = 600;

                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ViewSubjectGrid.DataSource = dt;
                    ViewSubjectGrid.DataBind();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }


        }*/

        protected void DeleteCourse_Click(object sender, EventArgs e)
        {
            // Delete Course Amount Table
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "DELETE course_amount_tbl WHERE [Course Name] = @CourseName";


                cmd.Parameters.AddWithValue("@CourseName", Request.Form[TextBox1.UniqueID]?.Trim());
                cmd.CommandTimeout = 600;
                cmd.ExecuteNonQuery();
                con.Close();

                string imageUrl = "Resources/success.png"; 
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Course Name : " + Request.Form[TextBox1.UniqueID]?.Trim() + " have been successfully Deleted Subject Lists";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-success"; // Adding the alert type

                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            // Delete Batch List of Selected Course

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "DELETE batch_tbl WHERE [Course Name] = @CourseName";


                cmd.Parameters.AddWithValue("@CourseName", Request.Form[TextBox1.UniqueID]?.Trim());
                cmd.CommandTimeout = 600;
                cmd.ExecuteNonQuery();
                con.Close();

                string imageUrl = "Resources/success.png"; 
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Course Name : " + Request.Form[TextBox1.UniqueID]?.Trim() + " have been successfully Deleted Batch Lists";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-success"; // Adding the alert type

                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            // Delete Subject List of Selected Course

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "DELETE c_subject_tbl WHERE [Course name] = @CourseName";


                cmd.Parameters.AddWithValue("@CourseName", Request.Form[TextBox1.UniqueID]?.Trim());
                cmd.CommandTimeout = 600;
                cmd.ExecuteNonQuery();
                con.Close();

                string imageUrl = "Resources/success.png"; 
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Course Name : " + Request.Form[TextBox1.UniqueID]?.Trim() + " have been successfully Deleted Subject Lists";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-success"; // Adding the alert type

                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            Response.Redirect(Request.RawUrl);

        }
        protected void AddCourse_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand checkCmd = con.CreateCommand();
                checkCmd.CommandType = System.Data.CommandType.Text;

                checkCmd.CommandText = "SELECT COUNT(*) FROM course_amount_tbl WHERE [Course Name] = @CourseName AND [Faculty] = @Faculty";
                checkCmd.Parameters.AddWithValue("@CourseName", TextBox6.Text.Trim());
                checkCmd.Parameters.AddWithValue("@Faculty", DropDownList3.SelectedValue);

                int courseCount = (int)checkCmd.ExecuteScalar();

                if (courseCount > 0)
                {
                    // Course already exists, set duplicate message
                    string imageUrl = "Resources/error.png"; 
                    string message = $"<img src='{imageUrl}' alt='Error Image' style='width:20px;height:20px;' /> Course already exists!";
                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-danger"; // Alert type for error

                    con.Close();
                    Response.Redirect(Request.RawUrl);
                }
                else
                {
                    // No duplicate found, proceed with insert
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;

                    cmd.CommandText = "INSERT INTO course_amount_tbl([Course Name],[Total Amount],[Faculty]) VALUES(@CourseName,@CourseAmount,@Faculty)";
                    cmd.Parameters.AddWithValue("@CourseName", TextBox6.Text.Trim());
                    cmd.Parameters.AddWithValue("@CourseAmount", TextBox10.Text.Trim());
                    cmd.Parameters.AddWithValue("@Faculty", DropDownList3.SelectedValue);
                    cmd.CommandTimeout = 600;
                    cmd.ExecuteNonQuery();

                    con.Close();

                    string imageUrl = "Resources/success.png"; 
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> New Course has been successfully Added";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-success"; // Alert type for success

                    Response.Redirect(Request.RawUrl);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

        }
        protected void c_pendingApproval_Click(object sender, EventArgs e)
        {
            Response.Redirect("c_pending_approval_page.aspx");
        }
        protected void leaves_Approval_Click(object sender, EventArgs e)
        {
            Response.Redirect("attendance_pending_approval.aspx");
        }
        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminSelfAttendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminStudentAttendance.aspx");
        }
    }
}