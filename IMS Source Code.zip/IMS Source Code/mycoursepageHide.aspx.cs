﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using static IMS_System___MACRO_CAMPUS.userhomepage;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            string user_id = string.Empty;
            string full_name = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("std_user"))
                {

                    full_name = Session["full_name"].ToString();
                    user_id = Session["user_id"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Subject No], [Subject Name], [Semester], [Grade], [Start Date], [End Date],[Tutorial File Path],[Assignment File Path],[Exam File Path] FROM user_c_subject_tbl WHERE [User ID] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Subject> subjects = new List<Subject>();

                while (reader.Read())
                {
                    var subject = new Subject
                    {
                        SubjectName = reader["Subject Name"].ToString(),
                        SubjectNo = reader["Subject No"].ToString(),
                        Semester = reader["Semester"].ToString(),
                        Grade = reader["Grade"].ToString(),
                        Start_Date = reader["Start Date"].ToString(),
                        End_Date = reader["End Date"].ToString(),
                        Tutorials = reader["Tutorial File Path"].ToString(),
                        Assignment = reader["Assignment File Path"].ToString(),
                        Exam = reader["Exam File Path"].ToString()
                    };

                    // Generate URLs for file downloads
                    subject.DownloadTutorialUrl = "DownloadFile.aspx?file=" + Server.UrlEncode(subject.Tutorials);
                    subject.DownloadAssignmentUrl = "DownloadFile.aspx?file=" + Server.UrlEncode(subject.Assignment);
                    subject.DownloadExamUrl = "DownloadFile.aspx?file=" + Server.UrlEncode(subject.Exam);

                    subjects.Add(subject);
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonSubject = Newtonsoft.Json.JsonConvert.SerializeObject(subjects);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "loadSubjects", "loadSubjects(" + jsonSubject + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            if (IsPostBack)
            {
                UploadFile1();
            }

            /*try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Subject No], [Subject Name], [Semester], [Grade], [Start Date], [End Date],[Tutorial File Path],[Assignment File Path],[Exam File Path] FROM user_c_subject_tbl WHERE [User ID] = '" + user_id+"'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Subject> subjects = new List<Subject>();

                while (reader.Read())
                {
                    subjects.Add(new Subject
                    {
                        SubjectName = reader["Subject Name"].ToString(),
                        SubjectNo = reader["Subject No"].ToString(),
                        Semester = reader["Semester"].ToString(),
                        Grade = reader["Grade"].ToString(),
                        Start_Date = reader["Start Date"].ToString(),
                        End_Date = reader["End Date"].ToString(),
                        Tutorials = reader["Tutorial File Path"].ToString(),
                        Assignment = reader["Assignment File Path"].ToString(),
                        Exam = reader["Exam File Path"].ToString()

                        

                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonSubject = Newtonsoft.Json.JsonConvert.SerializeObject(subjects);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "loadSubjects", "loadSubjects(" + jsonSubject + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }*/
        }
        public class Subject
        {
            public string SubjectName { get; set; }
            public string SubjectNo { get; set; }
            public string Semester { get; set; }
            public string Grade { get; set; }
            public string Start_Date { get; set; }
            public string End_Date { get; set; }
            public string Tutorials { get; set;}
            public string Assignment { get; set; }  
            public string Exam { get; set; }


            // URLs for downloading files
            public string DownloadTutorialUrl { get; set; }
            public string DownloadAssignmentUrl { get; set; }
            public string DownloadExamUrl { get; set; }
        }

        private void UploadFile1()
        {
            if (fileUploadControl.HasFile)
            {
                try
                {
                    string fileName = Path.GetFileName(fileUploadControl.FileName);                   
                    string uploadPath = @"D:\Final Project IMS System\IMS System - MACRO CAMPUS\Share Folder\Student\Upload Files\" + fileName; 
                    fileUploadControl.SaveAs(uploadPath);
                    string imageUrl = "Resources/success.png"; 
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Your Document is Successfully Uploaded in MACRO System.";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-success"; 
                }
                catch (Exception ex)
                {
                    //Response.Write("Error: " + ex.Message);
                    string imageUrl = "Resources/error.png"; 
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Your Document is Uploaded fail in MACRO System. Error: " + ex.Message + "";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-danger";
                }
            }
            else
            {
                //Response.Write("No file selected for upload.");
                string imageUrl = "Resources/error.png";
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> No file selected for upload.";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger";
            }
        }
    }

    
}

