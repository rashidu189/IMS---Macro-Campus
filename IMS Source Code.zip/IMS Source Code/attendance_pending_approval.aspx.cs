﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using System.Web.Helpers;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class attendance_pending_approval : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            string Emp_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("emp_user"))
                {
                    Emp_id = Session["Employee_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            if (!IsPostBack)
            {
                EmpAttendance();
            }

        }
        private void EmpAttendance()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use a SQL query to select data from the table
            string query1 = "SELECT [Employee Id],[Date of Attendance],[Start Time],[End Time],[Working Hours],[Attendance or Leave],[Created Date] FROM [employee_attendance_tbl] WHERE [Is Approved] = 0";
            SqlDataAdapter adapter1 = new SqlDataAdapter(query1, con);

            // No need to set the CommandType when using a SQL query
            DataTable dt1 = new DataTable();
            adapter1.Fill(dt1);
            con.Close();

            MarkAttendance.DataSource = dt1;
            MarkAttendance.DataBind();
        }

        protected void SearchBtn_Click(object sender, EventArgs e)
        {
            string employeeId = TextBox3.Text.ToString().Trim();
            string createdDate = TextBox2.Text.ToString().Trim();
            string fromDate = TextBox1.Text.ToString().Trim();
            string toDate = TextBox4.Text.ToString().Trim();


            if (string.IsNullOrEmpty(employeeId) && string.IsNullOrEmpty(createdDate) && string.IsNullOrEmpty(fromDate) && string.IsNullOrEmpty(toDate)){
               
                if (con.State == ConnectionState.Closed)
                    con.Open();

                // Use a SQL query to select data from the table
                string query1 = "SELECT [Employee Id],[Date of Attendance],[Start Time],[End Time],[Working Hours],[Attendance or Leave],[Created Date] FROM [employee_attendance_tbl] WHERE [Is Approved] = 0";
                SqlDataAdapter adapter1 = new SqlDataAdapter(query1, con);

                // No need to set the CommandType when using a SQL query
                DataTable dt1 = new DataTable();
                adapter1.Fill(dt1);
                con.Close();

                MarkAttendance.DataSource = dt1;
                MarkAttendance.DataBind();
            }else
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                // Use a SQL query to select data from the table
                string query = "SELECT [Employee Id],[Date of Attendance],[Start Time],[End Time],[Working Hours],[Attendance or Leave],[Created Date] FROM [employee_attendance_tbl] WHERE [Employee Id] LIKE '%" + employeeId + "%' AND [Created Date] LIKE '%" + createdDate + "%' AND [Date of Attendance] BETWEEN '" + fromDate + "' AND '" + toDate + "' AND [Is Approved] = 0";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);

                // No need to set the CommandType when using a SQL query
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                con.Close();

                MarkAttendance.DataSource = dt;
                MarkAttendance.DataBind();
            }

        }

        protected void RefreshBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }

        protected void MarkAttendance_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string Emp_id = string.Empty;
            try
            {
                if (Session["role"] != null && Session["role"].Equals("emp_user"))
                {
                    Emp_id = Session["Employee_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                return;
            }

            if (e.CommandName == "Approve")
            {
                try
                {
                    int index = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = MarkAttendance.Rows[index];

                    string employeeId = row.Cells[0].Text;
                    string dateOfAttendance = row.Cells[1].Text;
                    string startTime = row.Cells[2].Text;
                    string endTime = row.Cells[3].Text;
                    string workingHours = row.Cells[4].Text;
                    string attendanceOrLeave = row.Cells[5].Text; // Correct index for Attendance or Leave
                    DateTime approvedDate = DateTime.Now;
                    string approved = "1"; // Set approved as 1

                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;

                    cmd.CommandText = @"UPDATE employee_attendance_tbl 
                                SET [Approved Date] = @ApprovedDate, [Approved By] = @EmpID, [Is Approved] = @Approved 
                                WHERE [Employee Id] = @EmployeeID AND [Date of Attendance] = @DateOfAttendance 
                                AND [Start Time] = @StartTime AND [End Time] = @EndTime 
                                AND [Attendance or Leave] = @AttendanceOrLeave AND [Is Approved] = 0";

                    cmd.Parameters.AddWithValue("@EmployeeID", employeeId);
                    cmd.Parameters.AddWithValue("@DateOfAttendance", dateOfAttendance);
                    cmd.Parameters.AddWithValue("@StartTime", startTime);
                    cmd.Parameters.AddWithValue("@EndTime", endTime);
                    cmd.Parameters.AddWithValue("@WorkingHours", workingHours);
                    cmd.Parameters.AddWithValue("@AttendanceOrLeave", attendanceOrLeave);
                    cmd.Parameters.AddWithValue("@ApprovedDate", approvedDate);
                    cmd.Parameters.AddWithValue("@EmpID", Emp_id);
                    cmd.Parameters.AddWithValue("@Approved", approved);

                    cmd.ExecuteNonQuery();
                    con.Close();

                    string imageUrl2 = "Resources/success.png";
                    string message2 = $"<img src='{imageUrl2}' alt='Success Image' style='width:20px;height:20px;' /> "
                                    + employeeId + " is Attendance Successfully Approved.";

                    Session["AlertMessage"] = message2;
                    Session["AlertType"] = "alert-success";

                    //Refresh DataBase & Grid

                    string employeeId2 = TextBox3.Text.ToString().Trim();
                    string createdDate = TextBox2.Text.ToString().Trim();
                    string fromDate = TextBox1.Text.ToString().Trim();
                    string toDate = TextBox4.Text.ToString().Trim();


                    if (string.IsNullOrEmpty(employeeId2) && string.IsNullOrEmpty(createdDate) && string.IsNullOrEmpty(fromDate) && string.IsNullOrEmpty(toDate))
                    {

                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        // Use a SQL query to select data from the table
                        string query1 = "SELECT [Employee Id],[Date of Attendance],[Start Time],[End Time],[Working Hours],[Attendance or Leave],[Created Date] FROM [employee_attendance_tbl] WHERE [Is Approved] = 0";
                        SqlDataAdapter adapter1 = new SqlDataAdapter(query1, con);

                        // No need to set the CommandType when using a SQL query
                        DataTable dt1 = new DataTable();
                        adapter1.Fill(dt1);
                        con.Close();

                        MarkAttendance.DataSource = dt1;
                        MarkAttendance.DataBind();
                    }
                    else
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        // Use a SQL query to select data from the table
                        string query = "SELECT [Employee Id],[Date of Attendance],[Start Time],[End Time],[Working Hours],[Attendance or Leave],[Created Date] FROM [employee_attendance_tbl] WHERE [Employee Id] LIKE '%" + employeeId2 + "%' AND [Created Date] LIKE '%" + createdDate + "%' AND [Date of Attendance] BETWEEN '" + fromDate + "' AND '" + toDate + "' AND [Is Approved] = 0";
                        SqlDataAdapter adapter = new SqlDataAdapter(query, con);

                        // No need to set the CommandType when using a SQL query
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        con.Close();

                        MarkAttendance.DataSource = dt;
                        MarkAttendance.DataBind();
                    }

                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
        protected void c_pendingApproval_Click(object sender, EventArgs e)
        {
            Response.Redirect("c_pending_approval_page.aspx");
        }
        protected void leaves_Approval_Click(object sender, EventArgs e)
        {
            Response.Redirect("attendance_pending_approval.aspx");
        }
        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminSelfAttendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminStudentAttendance.aspx");
        }
    }
}