﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace IMS_System___MACRO_CAMPUS
{
    public class Connection_Manager
    {
        public static SqlConnection newCon;
        public static string Constr = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;

        public static SqlConnection GetConnection()
        {
            newCon = new SqlConnection(Constr);
            return newCon;
        }
    }
}