﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class lecturer_chat : System.Web.UI.Page
    {
        public string Name { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                    if (Session["First_Name"] != null && Session["Last_Name"] != null)
                    {
                        Name = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                    }
                }
                else
                {
                    Name = "Guest"; // Default value if session data is unavailable
                }
            }
            catch (Exception ex)
            {
                Response.Write("Error: " + ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        [System.Web.Services.WebMethod]
        public static void SaveMessage(string userName, string message)
        {
            string connectionString = @"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO chat_messages_tbl (UserName, Message, Timestamp) VALUES (@UserName, @Message, GETDATE())";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UserName", userName);
                cmd.Parameters.AddWithValue("@Message", message);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        [System.Web.Services.WebMethod]
        public static string GetMessages()
        {
            string connectionString = @"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT UserName, Message, Timestamp FROM chat_messages_tbl ORDER BY Timestamp ASC";
                SqlCommand cmd = new SqlCommand(query, conn);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                StringBuilder messages = new StringBuilder();

                while (reader.Read())
                {
                    string userName = reader["UserName"].ToString();
                    string message = reader["Message"].ToString();
                    string timestamp = Convert.ToDateTime(reader["Timestamp"]).ToString("hh:mm tt");

                    messages.Append($"<div class='chat-message'><strong>{userName}:</strong> {message} <small>({timestamp})</small></div>");
                }

                return messages.ToString();
            }
        }

        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("self_attendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("student_attendance.aspx");
        }
    }
}