﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class adminSelfAttendance : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("emp_user"))
                {
                    TextBox3.Text = Session["Employee_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
        protected void GenerateBtn_Click(object sender, EventArgs e)
        {
            string fromDateText = TextBox2.Text;
            string toDateText = TextBox1.Text;

            // Parse dates
            DateTime fromDate;
            DateTime toDate;

            if (DateTime.TryParse(fromDateText, out fromDate) && DateTime.TryParse(toDateText, out toDate))
            {
                if (fromDate <= toDate)
                {
                    List<DateModel> dateList = new List<DateModel>();

                    // Generate date list
                    for (DateTime date = fromDate; date <= toDate; date = date.AddDays(1))
                    {
                        dateList.Add(new DateModel
                        {
                            Date = date.ToShortDateString(),
                            StartTime = "08:00 AM",
                            EndTime = "17:00 PM",
                            WorkingHours = "9 Hours",
                            AttendanceOrLeave = "Present"
                        });
                    }

                    // Bind the list to the GridView
                    GridView1.DataSource = dateList;
                    GridView1.DataBind();
                }
                else
                {
                    string imageUrl = "Resources/error.png";
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> From Date cannot be later than To Date.";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-danger";
                }
            }
            else
            {

                string imageUrl1 = "Resources/error.png";
                string message1 = $"<img src='{imageUrl1}' alt='Success Image' style='width:20px;height:20px;' /> Please enter valid dates.";

                Session["AlertMessage"] = message1;
                Session["AlertType"] = "alert-danger";
            }
        }


        public class DateModel
        {
            public string Date { get; set; }
            public string StartTime { get; set; }
            public string EndTime { get; set; }
            public string WorkingHours { get; set; }
            public string AttendanceOrLeave { get; set; }
        }

        protected void RefreshBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }

        protected void SaveBtn_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow row in GridView1.Rows)
            {
                string date = (row.Cells[0].Text);
                string startTime = (row.Cells[1].Text);
                string endTime = (row.Cells[2].Text);
                string workingHours = (row.Cells[3].Text);
                string employeeId = TextBox3.Text.ToString().Trim();
                string isApproved = "0";
                DateTime createdDate = DateTime.Now;

                DropDownList ddlAttendance = (DropDownList)row.FindControl("ddlAttendance");
                string attendanceOrLeave = ddlAttendance.SelectedItem.Value;

                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "INSERT INTO employee_attendance_tbl ([Employee Id],[Date of Attendance],[Start Time],[End Time],[Working Hours],[Attendance or Leave],[Is Approved],[Created Date]) VALUES (@EmployeeId,@Date,@StartTime,@EndTime,@WorkingHours,@AttendanceOrLeave,@IsApproved,@CreatedDate)";
                cmd.Parameters.AddWithValue("@Date", date);
                cmd.Parameters.AddWithValue("@StartTime", startTime);
                cmd.Parameters.AddWithValue("@EndTime", endTime);
                cmd.Parameters.AddWithValue("@WorkingHours", workingHours);
                cmd.Parameters.AddWithValue("@AttendanceOrLeave", attendanceOrLeave);
                cmd.Parameters.AddWithValue("@EmployeeId", employeeId);
                cmd.Parameters.AddWithValue("@IsApproved", isApproved);
                cmd.Parameters.AddWithValue("@CreatedDate", createdDate);
                cmd.ExecuteNonQuery();
                con.Close();

                string imageUrl2 = "Resources/success.png";
                string message2 = $"<img src='{imageUrl2}' alt='Success Image' style='width:20px;height:20px;' /> Your Attendance is Successfully Saved.";

                Session["AlertMessage"] = message2;
                Session["AlertType"] = "alert-success";
            }

        }
        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminSelfAttendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminStudentAttendance.aspx");
        }
        protected void c_pendingApproval_Click(object sender, EventArgs e)
        {
            Response.Redirect("c_pending_approval_page.aspx");
        }
        protected void leaves_Approval_Click(object sender, EventArgs e)
        {
            Response.Redirect("attendance_pending_approval.aspx");
        }
    }
}