﻿using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Ocsp;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using System.Web.Services;


namespace IMS_System___MACRO_CAMPUS
{
    public partial class payment_page : System.Web.UI.Page
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            string user_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("std_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                    user_id = Session["User_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }



            //Course Card

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "loadCourses", "loadCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


            //For the Payment

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "PaymentCourses", "PaymentCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("std_user"))
                {
                    TextBox1.Text = Session["Full_Name"].ToString();
                    TextBox2.Text = Session["User_ID"].ToString();
                    TextBox3.Text = Session["Email_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


            if (!IsPostBack)
            {
                string courseName = Request.QueryString["courseName"];
                if (!string.IsNullOrEmpty(courseName))
                {
                    TextBox6.Text = Server.UrlDecode(courseName);
                }
                else
                {
                    TextBox6.Text = "Course name not found.";
                }
            }

            /*if (!IsPostBack)
            {
                decimal PaymentAmount = 0.00m; // Replace this with your actual value
                TextBox7.Text = PaymentAmount.ToString("C", System.Globalization.CultureInfo.GetCultureInfo("en-LK"));
            }*/

            string CourseName = TextBox6.Text.ToString().Trim();
            string StudentName = TextBox2.Text.ToString().Trim();

            con.Open();
            SqlCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = System.Data.CommandType.Text;
            cmd1.CommandText = "SELECT [Pending Amount] FROM [student_couse_payments] WHERE [Student ID] = '" + StudentName + "' AND [Course Name] = '" + CourseName + "'";
            SqlDataReader dr = cmd1.ExecuteReader();
            while (dr.Read())
            {
                TextBox5.Text = "LKR " + dr.GetValue(0).ToString() + ".00";
            }
            con.Close();



        }


        protected void PayButton_Click(object sender, EventArgs e)
        {


        }

        protected void paypal_Click(object sender, EventArgs e)
        {

            // Retrieve values
            string payAmount = TextBox7.Text.Trim();
            string courseName = TextBox6.Text.Trim();
            string userId = Session["User_ID"]?.ToString();

            // Construct the query string
            string redirectUrl = $"PayPal.aspx?CourseName={HttpUtility.UrlEncode(courseName)}&UserId={HttpUtility.UrlEncode(userId)}&PayAmount={HttpUtility.UrlEncode(payAmount)}";

            // Redirect to the PayPal page with the query string
            Response.Redirect(redirectUrl);
        }


        protected void ConfirmButton_Click(object sender, EventArgs e)
        {

            string SName = TextBox1.Text.ToString().Trim();
            string CName = TextBox6.Text.ToString().Trim();
            string SId = TextBox2.Text.ToString().Trim();
            string SEmail = TextBox3.Text.ToString().Trim();
            DateTime PDate = DateTime.Now;
            decimal PAmount;
            string inputText = TextBox7.Text.ToString().Trim();


            // Use NumberStyles to allow decimal values without currency
            if (decimal.TryParse(inputText, NumberStyles.Number, CultureInfo.InvariantCulture, out PAmount))
            {
                // Insert Record in DataBase

                con.Open();
                SqlCommand cmd1 = con.CreateCommand();
                cmd1.CommandType = System.Data.CommandType.Text;
                cmd1.CommandText = @"INSERT INTO student_payment_transactions ([Student ID], [Course Name], [Paid Amount], [Date]) 
                    VALUES (@SId, @CName, @PAmount, @PDate)";

                cmd1.Parameters.AddWithValue("@SId", SId);
                cmd1.Parameters.AddWithValue("@CName", CName);
                cmd1.Parameters.AddWithValue("@PAmount", PAmount);
                cmd1.Parameters.AddWithValue("@PDate", PDate);

                cmd1.ExecuteNonQuery();
                con.Close();

                // Update Record in DataBase

                con.Open();
                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandType = System.Data.CommandType.Text;
                cmd2.CommandText = @"UPDATE student_couse_payments 
                     SET [Paid Amount] = [Paid Amount] + @PAmount, 
                         [Pending Amount] = [Pending Amount] - @PAmount 
                     WHERE [Student ID] = @SId AND [Course Name] = @CName";
                cmd2.Parameters.AddWithValue("@SId", SId);
                cmd2.Parameters.AddWithValue("@CName", CName);
                cmd2.Parameters.AddWithValue("@PAmount", PAmount);

                cmd2.ExecuteNonQuery();
                con.Close();

            }
            else
            {
                
            }

            string htmlContent = @"<button id=""openModal"" class=""trigger-button"">Show Confirmation</button>
                                                                  < !-- Modal Structure -->
                            <div id=""confirmationModal"" class=""modal"">
                                <div class=""modal-content"">
                                    <span class=""close"">&times;</span>
                                    <h1>Payment Successful!</h1>
                                    <p>Thank you for your payment. Your transaction has been completed successfully.</p>
                                    <div class=""order-summary"">
                                        <div><strong>Student Id:</strong> "" + SId + @""</div>
                                        <div><strong>Student Name:</strong> "" + SName + @""</div>
                                        <div><strong>Student Email:</strong> "" + SEmail + @""</div>
                                        <div><strong>Course Name:</strong> "" + CName + @""</div>
                                        <div><strong>Paid Amount:</strong> LKR"" + PAmount + @""</div>
                                        <div><strong>Paid Date:</strong> "" + PDate + @""</div>
                                    </div>
                                    <a href=""studenthomepage.aspx"" class=""back-button"">Exit</a>
                                </div>
                            </div>  
                                                            < style>
                             /* Modal Styles */
                                .modal {
                                    display: none; /* Hidden by default */
                                    position: fixed;
                                    z-index: 1; /* Sit on top */
                                    left: 0;
                                    top: 0;
                                    width: 100%;
                                    height: 100%;
                                    overflow: auto; /* Enable scroll if needed */
                                    background-color: rgb(0,0,0); /* Fallback color */
                                    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
                                }

                                .modal-content {
                                    background-color: #fff;
                                    margin: 15% auto; /* 15% from the top and centered */
                                    padding: 20px;
                                    border: 1px solid #888;
                                    width: 80%; /* Could be more or less, depending on screen size */
                                    border-radius: 8px;
                                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                                    text-align: center;
                                }

                                .close {
                                    color: #aaa;
                                    float: right;
                                    font-size: 28px;
                                    font-weight: bold;
                                }

                                .close:hover,
                                .close:focus {
                                    color: black;
                                    text-decoration: none;
                                    cursor: pointer;
                                }

                                .trigger-button {
                                    background-color: #4CAF50;
                                    color: white;
                                    padding: 10px 20px;
                                    border: none;
                                    border-radius: 4px;
                                    cursor: pointer;
                                    text-decoration: none;
                                    font-size: 16px;
                                }

                                .trigger-button:hover {
                                    background-color: #45a049;
                                }

                                .back-button {
                                    background-color: #4CAF50;
                                    color: white;
                                    padding: 10px 20px;
                                    border: none;
                                    border-radius: 4px;
                                    cursor: pointer;
                                    text-decoration: none;
                                    font-size: 16px;

                                }

                                .back-button:hover {
                                    background-color: #45a049;
                        
                                }

                            </style> ";

            placeholderContent.Controls.Add(new LiteralControl(htmlContent));





            // Send Email


            using (MailMessage mail = new MailMessage())
                     {
                         mail.From = new MailAddress("rashidumilan100@gmail.com");
                         mail.To.Add(SEmail);
                         mail.Subject = "Course Payments - '" + SId + "'";
                         mail.Body = $@"<html>
                                     <head>
                                         <style>
                                             body {{{{ font-family: Arial, sans-serif; }}}}
                                             .container {{{{ margin: 20px; padding: 10px; }}}}
                                             .content {{{{ font-size: 16px; }}}}
                                             .footer {{{{ margin-top: 20px; font-size: 12px; color: gray; }}}}
                                         </style>
                                     </head>
                                     <body>
                                         <div class='container'>
                                             <div class='content'>
                                                 <p><b>Dear {SName},</b></p>
                                                 <p>Your payment for the <strong>{CName}</strong> course is successful....</P>
                                                 <p>Your Student ID is    : <strong>{SId}</strong></p>
                                                 <p>Your Course Name is   : <strong>{CName}</strong></p>
                                                 <p>Your Paid Amount is  : <strong>{PAmount}</strong></p>
                                                 <p>Your Paid Date is    : <strong>{PDate}</strong></p>
                                                 <p>Contact us if there is any problem.</p>
                                             </div>
                                             <div class='footer'>
                                                 <p>Best regards,</p>
                                                 <br>MACRO Support Team.....

                                             </div>
                                         </div>
                                     </body>
                                     <br><hr style=""font-family: arial, sans-serif; font-size: 10pt;color:#e74c3c;""><table cellpadding=""10px"">
                                                             <tr><td colspan=""3"" style=""background-color:white;color:#e74c3c text-align:center;""><b>© Note: This is an auto generated email. Please don't reply to this email.</b></td>
                                                             </tr><tr><td style=""background-color:#e74c3c;color:white;text-align:center;"">©</td>
                                                             <td style=""background-color:#e74c3c;color:white;text-align:center;"">MACRO</td>
                                                             <td style=""background-color:#e74c3c;color:white;text-align:center;"">MACRO CAMPUS SYSTEM</table>

                                     </div>  
                                     </html>";
                         mail.IsBodyHtml = true;

                         using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                         {
                             smtp.Credentials = new NetworkCredential("macrocampus0@gmail.com", "xbjr lcxs yree pgjf");
                             smtp.EnableSsl = true;
                             smtp.Send(mail);
                         }
                         Response.Redirect(Request.RawUrl);
                     }
        }


        protected void cancelButton_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }

        public class Course
        {
            public string CourseName { get; set; }
            public string BatchNo { get; set; }
            public string Status { get; set; }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("mycoursepage.aspx");
            /*// Register JavaScript to be executed on the client-side
            string script = "window.location.href = 'mycoursepage.aspx';";
            ClientScript.RegisterStartupScript(this.GetType(), "redirect", script, true);*/
        }

    }
}