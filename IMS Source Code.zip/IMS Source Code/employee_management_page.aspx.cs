﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class employee_management_page1 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            string Emp_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("emp_user"))
                {

                    Emp_id = Session["Employee_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            if (!IsPostBack)
            {
                FillGridView();

            }
        }

        protected void RefreshBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);

        }

        protected void SearchBtn_Click(object sender, EventArgs e)
        {
            string employeeName = TextBox2.Text.ToString().Trim();
            string employeeId = TextBox3.Text.ToString().Trim();
            string userType = DropDownList2.SelectedItem.Value.ToString().Trim();
            string faculty = DropDownList3.SelectedItem.Value.ToString().Trim();
            string jobTittle = DropDownList4.SelectedItem.Value.ToString().Trim();
            string status = DropDownList1.SelectedItem.Value.ToString().Trim();

            string query = @"SELECT [Employee_ID] AS [Employee ID],[Full_Name] AS [Full Name],[User_Type] AS [User Type],[User_Status] AS [Status],[Faculty] AS [Faculty],[Job_Tittle] AS [Job Tittle] FROM Employee_TBL
                              WHERE [Employee_ID] LIKE @EmployeeId AND [Full_Name] LIKE @EmployeeName AND [User_Type] LIKE @UserType AND [User_Status] LIKE @Status AND [Faculty] LIKE @Faculty AND [Job_Tittle] LIKE @JobTittle";

            // Open the connection
            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use SqlCommand to execute the query with parameters
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                // Add parameters to avoid SQL injection
                cmd.Parameters.AddWithValue("@EmployeeName", "%" + employeeName + "%");
                cmd.Parameters.AddWithValue("@UserType", "%" + userType + "%");
                cmd.Parameters.AddWithValue("@EmployeeId", "%" + employeeId + "%");
                cmd.Parameters.AddWithValue("@Faculty", "%" + faculty + "%");
                cmd.Parameters.AddWithValue("@JobTittle", "%" + jobTittle + "%");
                cmd.Parameters.AddWithValue("@Status", "%" + status + "%");
                cmd.CommandTimeout = 600;
                // Execute the query and fill the data table
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Close the connection
                con.Close();

                // Bind the results to the GridView
                EmployeeManagement.DataSource = dt;
                EmployeeManagement.DataBind();
            }
        }

        public void FillGridView()
        {

            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use a SQL query to select data from the table
            string query = "SELECT [Employee_ID] AS [Employee ID],[Full_Name] AS [Full Name],[User_Type] AS [User Type],[User_Status] AS [Status],[Faculty] AS [Faculty],[Job_Tittle] AS [Job Tittle] FROM Employee_TBL";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);
            adapter.SelectCommand.CommandTimeout = 600;
            // No need to set the CommandType when using a SQL query
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            con.Close();

            EmployeeManagement.DataSource = dt;
            EmployeeManagement.DataBind();

        }
        public void EmployeeManagement_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);

                GridViewRow row = EmployeeManagement.Rows[rowIndex];

                string employeeId = row.Cells[0].Text;
                string employeeName = row.Cells[1].Text;

                Response.Redirect("employee_information_page.aspx?employeeId=" + employeeId + "&employeeName=" + employeeName );


            }
        }
        protected void c_pendingApproval_Click(object sender, EventArgs e)
        {
            Response.Redirect("c_pending_approval_page.aspx");
        }
        protected void leaves_Approval_Click(object sender, EventArgs e)
        {
            Response.Redirect("attendance_pending_approval.aspx");
        }
        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminSelfAttendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminStudentAttendance.aspx");
        }
    }
}