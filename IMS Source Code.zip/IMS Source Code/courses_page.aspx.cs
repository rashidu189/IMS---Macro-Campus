﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class courses_page : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            string user_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("std_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                    user_id = Session["User_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }



            //Course Card

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "loadCourses", "loadCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


            //For the Payment

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "PaymentCourses", "PaymentCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("user"))
                {

                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void Button19_Click(object sender, EventArgs e)
        {

            string courseName = "Bsc (Hons) in Software Engineering";
            string facultyName = "Faculty of Computing";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
            

        }
        protected void Button18_Click(object sender, EventArgs e)
        {
            string courseName = "AR and VR technology";
            string facultyName = "Faculty of Computing";
            string courses = "Foundation Programme";
            string coursetype = "External Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button17_Click(object sender, EventArgs e)
        {
            string courseName = "Robotic Process Automation (RPA) technology";
            string facultyName = "Faculty of Computing";
            string courses = "Foundation Programme";
            string coursetype = "External Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button16_Click(object sender, EventArgs e)
        {
            string courseName = "Artificial intelligence (AI) technology";
            string facultyName = "Faculty of Computing";
            string courses = "Foundation Programme";
            string coursetype = "External Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button15_Click(object sender, EventArgs e)
        {
            string courseName = "BSc (Hons) Nutrition and Health";
            string facultyName = "Faculty of Science";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button14_Click(object sender, EventArgs e)
        {
            string courseName = "BSc (Hons) in Pharmaceutical Science";
            string facultyName = "Faculty of Science";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button13_Click(object sender, EventArgs e)
        {
            string courseName = "BSc (Hons) in Biomedical Science";
            string facultyName = "Faculty of Science";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button12_Click(object sender, EventArgs e)
        {
            string courseName = "BSc (Hons) in Computer System Engineering";
            string facultyName = "Faculty of Engineering";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button11_Click(object sender, EventArgs e)
        {
            string courseName = "BSc (Hons) in Electrical and Electronic Engineering";
            string facultyName = "Faculty of Engineering";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button10_Click(object sender, EventArgs e)
        {
            string courseName = "BSc (Hons) in Mechatronic Engineering";
            string facultyName = "Faculty of Engineering";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button9_Click(object sender, EventArgs e)
        {
            string courseName = "BM (Hons) in Marketing Management";
            string facultyName = "Faculty of Business";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button8_Click(object sender, EventArgs e)
        {
            string courseName = "BSc in Business Management (HR)";
            string facultyName = "Faculty of Business";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button7_Click(object sender, EventArgs e)
        {
            string courseName = "BM (Hons) in Accounting and Finance";
            string facultyName = "Faculty of Business";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button6_Click(object sender, EventArgs e)
        {
            string courseName = "BBM (Hons) Tourism, Hospitality & Events";
            string facultyName = "Faculty of Business";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button5_Click(object sender, EventArgs e)
        {
            string courseName = "BM (Hons) in Business Analytics";
            string facultyName = "Faculty of Business";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button4_Click(object sender, EventArgs e)
        {
            string courseName = "BSc (Hons) in Computer Science";
            string facultyName = "Faculty of Computing";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            string courseName = "BSc (Hons) in Computer Networks";
            string facultyName = "Faculty of Computing";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));

        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            string courseName = "BSc (Hons) in Data Science";
            string facultyName = "Faculty of Computing";
            string courses = "Undergraduate";
            string coursetype = "Internal Courses";
            Response.Redirect("course_registration_page.aspx?courseName=" + Server.UrlEncode(courseName) +
                   "&facultyName=" + Server.UrlEncode(facultyName) +
                   "&courses=" + Server.UrlEncode(courses) +
                   "&coursetype=" + Server.UrlEncode(coursetype));
        }
        public class Course
        {
            public string CourseName { get; set; }
            public string BatchNo { get; set; }
            public string Status { get; set; }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("mycoursepage.aspx");
            /*// Register JavaScript to be executed on the client-side
            string script = "window.location.href = 'mycoursepage.aspx';";
            ClientScript.RegisterStartupScript(this.GetType(), "redirect", script, true);*/
        }
    }

}