﻿const express = require('express');
const multer = require('multer');
const path = require('path');

const app = express();
const PORT = 3000;

// Specify the directory where files will be uploaded
const uploadDirectory = 'D:/Final Project IMS System/IMS System - MACRO CAMPUS/upload';

// Set up multer for file storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDirectory);
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });

// Serve the static HTML file
app.use(express.static(path.join(__dirname, 'public')));

// Handle file upload
app.post('/upload', upload.single('file'), (req, res) => {
    res.send('File uploaded successfully!');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
