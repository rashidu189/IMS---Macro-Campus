﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace IMS_System___MACRO_CAMPUS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PaymentController : ControllerBase
    {
        [HttpGet("payment")]
        public IActionResult GetPaymentDetails()
        {
            // Define payment details
            var merchantId = "1228082"; // Your PayHere Merchant ID
            var orderId = "12345SE";
            var amount = 20000m; // Example amount
            var currency = "LKR";
            var merchantSecret = "MzMxNTExNTIyMDIzODYxMzQ5OTM5MjQyNDk0NjEyODY2OTU5MDMx"; // Your Merchant Secret

            // Generate the hash
            var hash = GenerateHash(merchantId, orderId, amount, currency, merchantSecret);

            // Prepare response data
            var paymentData = new
            {
                merchant_id = merchantId,
                order_id = orderId,
                currency = currency,
                amount = amount,
                hash = hash
            };

            return Ok(paymentData); // Return the payment details as JSON
        }

        private string GenerateHash(string merchantId, string orderId, decimal amount, string currency, string merchantSecret)
        {
            // Format amount to 2 decimal places
            string formattedAmount = amount.ToString("F2", CultureInfo.InvariantCulture);

            // Generate the hash
            string hashInput = $"{merchantId}{orderId}{formattedAmount}{currency}{MD5Hash(merchantSecret)}";
            string hash = MD5Hash(hashInput).ToUpper();

            return hash;
        }

        private string MD5Hash(string input)
        {
            using (MD5 md5 = MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    sb.Append(b.ToString("x2"));
                }
                return sb.ToString();
            }
        }
    }

}
