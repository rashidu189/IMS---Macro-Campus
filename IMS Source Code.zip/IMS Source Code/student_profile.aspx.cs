﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tulpep.NotificationWindow;
using System.Data;
using System.IO;
using static IMS_System___MACRO_CAMPUS.userhomepage;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            string user_idN = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("std_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                    user_idN = Session["User_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string statusN = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(statusN))
                {
                    if (statusN.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (statusN.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton1.Visible = true;
                }
                else if (Session["role"].Equals("std_user"))
                {
                    LinkButton1.Text = Session["Full_Name"].ToString();
                    LinkButton2.Text = Session["User_ID"].ToString();
                    TextBox1.Text = Session["Full_Name"].ToString();
                    TextBox6.Text = Session["First_Name"].ToString();
                    TextBox7.Text = Session["Middle_Name"].ToString();
                    TextBox11.Text = Session["Last_Name"].ToString();
                    if (Session["DOB"] != null)
                    {
                        DateTime dob;
                        if (DateTime.TryParse(Session["DOB"].ToString(), out dob))
                        {
                            TextBox2.Text = dob.ToString("yyyy-MM-dd"); 
                        }
                        else
                        {
                            TextBox2.Text = "Invalid Date";
                        }
                    }
                    else
                    {
                        TextBox2.Text = "No Date Available";
                    }
                    TextBox3.Text = Session["Contact_No"].ToString();
                    TextBox4.Text = Session["Email_ID"].ToString();
                    TextBox5.Text = Session["Full_Address"].ToString();
                    TextBox9.Text = Session["National_Identity_Card"].ToString();
                    TextBox13.Text = Session["Gender"].ToString();
                    TextBox14.Text = Session["Civil_Status"].ToString();
                    TextBox15.Text = Session["Nationality"].ToString();
                    TextBox8.Text = Session["User_ID"].ToString();
                    TextBox16.Text = Session["User_Type"].ToString();
                    TextBox10.Text = Session["Password"].ToString();


                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton3.Visible = true;
                        LinkButton4.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton4.Visible = true;
                        LinkButton3.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            //Course Card

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_idN + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "loadCourses", "loadCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


            //For the Payment

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_idN + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "PaymentCourses", "PaymentCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            string contact_no = contactNo.Text.ToString().Trim();
            string email_id = emailId.Text.ToString().Trim();
            string user_id = TextBox8.Text.ToString().Trim();

            try
            {
                con.Open();
                SqlCommand cmd3 = con.CreateCommand();
                cmd3.CommandType = System.Data.CommandType.Text;
                cmd3.CommandText = @"UPDATE Student_TBL SET [Contact_No] = @ContactNo, [Email_ID] = @EmailID WHERE [User_ID] = @UserID";

                cmd3.Parameters.AddWithValue("@ContactNo", contact_no);
                cmd3.Parameters.AddWithValue("@EmailID", email_id);
                cmd3.Parameters.AddWithValue("@UserID", user_id); 
                
                int rowsAffected = cmd3.ExecuteNonQuery();
                con.Close();
                if (rowsAffected > 0)
                {
                    string imageUrl = "Resources/info.png"; // Update this to the actual path of your image
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Your Information is Successfully Updated in the System";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-info"; // Adding the alert type
                    Response.Redirect(Request.RawUrl); // Redirect to refresh the page
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string old_pwd = TextBox10.Text.Trim();
            string new_pwd = TextBox12.Text.Trim();
            if (old_pwd == new_pwd)
            {
                string imageUrl = "Resources/error.png"; // Update this to the actual path of your image
                string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Your New Password will be the same as your Previous Password. Please Try Again Later.";

                Session["AlertMessage"] = message;
                Session["AlertType"] = "alert-danger"; // Adding the alert type
                Response.Redirect(Request.RawUrl); // Redirect to refresh the page
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd2 = con.CreateCommand();
                    cmd2.CommandType = System.Data.CommandType.Text;
                    cmd2.CommandText = "UPDATE Student_TBL SET Password = '" + TextBox12.Text.ToString() + "' WHERE User_ID = '" + TextBox8.Text.ToString() + "'";
                    int rowsAffected = cmd2.ExecuteNonQuery();
                    con.Close();

                    string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Your Password Successfully Changed.";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-success"; // Adding the alert type
                    Response.Redirect(Request.RawUrl); // Redirect to refresh the page
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }

        }
        public class Course
        {
            public string CourseName { get; set; }
            public string BatchNo { get; set; }
            public string Status { get; set; }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("mycoursepage.aspx");
            /*// Register JavaScript to be executed on the client-side
            string script = "window.location.href = 'mycoursepage.aspx';";
            ClientScript.RegisterStartupScript(this.GetType(), "redirect", script, true);*/
        }
    }
}