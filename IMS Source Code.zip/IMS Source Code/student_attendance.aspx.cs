﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.NetworkInformation;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class student_attendance : System.Web.UI.Page
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            string Emp_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("emp_user"))
                {
                    Emp_id = Session["Employee_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            if (!IsPostBack)
            {
                FillGridView();
            }
        }
        protected void MarkSAttendance_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string Emp_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("emp_user"))
                {
                    Emp_id = Session["Employee_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            if (e.CommandName == "Present")
            {
                string userID = e.CommandArgument.ToString();

                // Find the row that contains the button clicked
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = MarkSAttendance.Rows.Cast<GridViewRow>().FirstOrDefault(r => ((Button)r.FindControl("PresentButton")).CommandArgument == userID);

                // Extract values from the row
                string studentId = row.Cells[0].Text; 
                    string fullName = row.Cells[1].Text;  
                    string email = row.Cells[2].Text;     
                    string courseName = row.Cells[3].Text; 
                    string batchNo = row.Cells[4].Text;
                    string presentV = "1";

                TextBox txtSelectDate = (TextBox)row.FindControl("txtSelectDate");
                string selectedDate = txtSelectDate.Text;

                if (string.IsNullOrWhiteSpace(selectedDate))
                {
                    string imageUrl = "Resources/error.png";
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Please Select Date.";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-danger";
                    return; // Exit the method or handle accordingly
                }
                else
                {
                    // Proceed with inserting data into the database
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "INSERT INTO student_attendance_tbl ([Student ID],[Full Name],[Email ID],[Course Name],[Batch No],[Attendance Date],[Attendance],[Mark By]) VALUES (@StudentID, @FullName, @Email, @CourseName, @BatchNo, @SelectedDate, @PresentV, @EmpID)";
                    cmd.Parameters.AddWithValue("@StudentID", studentId);
                    cmd.Parameters.AddWithValue("@FullName", fullName);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@CourseName", courseName);
                    cmd.Parameters.AddWithValue("@BatchNo", batchNo);
                    cmd.Parameters.AddWithValue("@SelectedDate", selectedDate);
                    cmd.Parameters.AddWithValue("@PresentV", presentV);
                    cmd.Parameters.AddWithValue("@EmpID", Emp_id);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    string imageUrl2 = "Resources/success.png";
                    string message2 = $"<img src='{imageUrl2}' alt='Success Image' style='width:20px;height:20px;' /> " + studentId + " is Present in " + selectedDate + ".";

                    Session["AlertMessage"] = message2;
                    Session["AlertType"] = "alert-success";
                }



            }
            else if (e.CommandName == "Absent")
            {
                string userID = e.CommandArgument.ToString();

                // Find the row that contains the button clicked
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = MarkSAttendance.Rows.Cast<GridViewRow>().FirstOrDefault(r => ((Button)r.FindControl("AbsentButton")).CommandArgument == userID);

                // Extract values from the row
                string studentId = row.Cells[0].Text; 
                string fullName = row.Cells[1].Text;  
                string email = row.Cells[2].Text;     
                string courseName = row.Cells[3].Text; 
                string batchNo = row.Cells[4].Text;
                string absentV = "0";


                TextBox txtSelectDate = (TextBox)row.FindControl("txtSelectDate");
                string selectedDate = txtSelectDate.Text;

                if (string.IsNullOrWhiteSpace(selectedDate))
                {
                    string imageUrl = "Resources/error.png";
                    string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Please Select Date.";

                    Session["AlertMessage"] = message;
                    Session["AlertType"] = "alert-danger";
                    return; // Exit the method or handle accordingly
                }
                else
                {
                    // Proceed with inserting data into the database
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "INSERT INTO student_attendance_tbl ([Student ID],[Full Name],[Email ID],[Course Name],[Batch No],[Attendance Date],[Attendance],[Mark By]) VALUES (@StudentID, @FullName, @Email, @CourseName, @BatchNo, @SelectedDate, @AbsentV, @EmpID)";
                    cmd.Parameters.AddWithValue("@StudentID", studentId);
                    cmd.Parameters.AddWithValue("@FullName", fullName);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@CourseName", courseName);
                    cmd.Parameters.AddWithValue("@BatchNo", batchNo);
                    cmd.Parameters.AddWithValue("@SelectedDate", selectedDate);
                    cmd.Parameters.AddWithValue("@AbsentV", absentV);
                    cmd.Parameters.AddWithValue("@EmpID", Emp_id);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    string imageUrl2 = "Resources/info.png";
                    string message2 = $"<img src='{imageUrl2}' alt='Success Image' style='width:20px;height:20px;' /> " + studentId + " is Absent in " + selectedDate + ".";

                    Session["AlertMessage"] = message2;
                    Session["AlertType"] = "alert-info";
                }

            }
        }
        public void FillGridView()
        {

            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use a SQL query to select data from the table
            string query = "SELECT [User_ID] AS [Student ID],[Full_Name] AS [Full Name],[Email_ID] AS [Email],[Course name] AS [Course Name],[Batch No] AS [Batch No] FROM [Student_TBL] LEFT JOIN [userdetail_in_batch_tbl] ON [Student_TBL].[User_ID] = [userdetail_in_batch_tbl].[User Id] WHERE [Student_TBL].[User_Status] = 'Active'";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);

            // No need to set the CommandType when using a SQL query
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            con.Close();

            MarkSAttendance.DataSource = dt;
            MarkSAttendance.DataBind();

        }

        protected void SearchBtn_Click(object sender, EventArgs e)
        {
            string CName = TextBox3.Text.ToString().Trim();
            string BNo = TextBox2.Text.ToString().Trim();
            string SID = TextBox1.Text.ToString().Trim();

            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use a SQL query to select data from the table
            string query = "SELECT [User_ID] AS [Student ID],[Full_Name] AS [Full Name],[Email_ID] AS [Email],[Course name] AS [Course Name],[Batch No] AS [Batch No] FROM [Student_TBL] LEFT JOIN [userdetail_in_batch_tbl] ON [Student_TBL].[User_ID] = [userdetail_in_batch_tbl].[User Id] WHERE [userdetail_in_batch_tbl].[Course name] LIKE '%"+CName+"%' AND [userdetail_in_batch_tbl].[Batch No] LIKE '%"+BNo+"%' AND [Student_TBL].[User_ID] LIKE '%"+SID+ "%' AND [Student_TBL].[User_Status] = 'Active'";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);

            // No need to set the CommandType when using a SQL query
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            con.Close();

            MarkSAttendance.DataSource = dt;
            MarkSAttendance.DataBind();
        }

        protected void RefreshBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }
        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("self_attendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("student_attendance.aspx");
        }
    }
}