﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class employee_management_page : System.Web.UI.Page
    {
        string employeeId = string.Empty;
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            string Emp_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("emp_user"))
                {

                    Emp_id = Session["Employee_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            if (!IsPostBack)
            {
                string employeeName = Request.QueryString["employeeName"];
                employeeId = Request.QueryString["employeeId"];

                EmployeeDetails();

            }

        }

        public void EmployeeDetails()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "SELECT [Employee_ID],[Full_Name],[First_Name],[Middle_Name],[Last_Name],[DOB]," +
                "[Contact_No],[Email_ID],[Full_Address],[Gender],[Civil_Status],[Nationality],[National_Identity_Card]," +
                "[Password],[User_Type],[User_Status],[Faculty],[Job_Tittle],[Qualification_Level],[Salary]," +
                "[Joined_Date],[Qualification],[Work_Experience] FROM Employee_TBL WHERE [Employee_ID] = '" + employeeId + "'";
            cmd.CommandTimeout = 600;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                user_id.Text = dr.GetValue(0).ToString().Trim();
                fullname.Text = dr.GetValue(1).ToString().Trim();
                firstname.Text = dr.GetValue(2).ToString().Trim();
                middlename.Text = dr.GetValue(3).ToString().Trim();
                lastname.Text = dr.GetValue(4).ToString().Trim();

                DateTime dobValue = Convert.ToDateTime(dr.GetValue(5));
                dob.Text = dobValue.ToString("yyyy-MM-dd").Trim();

                int contactNoValue = Convert.ToInt32(dr.GetValue(6).ToString().Trim());
                contactno.Text = contactNoValue.ToString();

                emailid.Text = dr.GetValue(7).ToString().Trim();
                address.Text = dr.GetValue(8).ToString().Trim();

                string gender = dr.GetValue(9).ToString().Trim();
                if (gender == "Male")
                {
                    RadioButton1.Checked = true;
                }
                else if (gender == "Female")
                {
                    RadioButton2.Checked = true;
                }

                string civilStatus = dr.GetValue(10).ToString().Trim();
                DropDownList2.SelectedValue = civilStatus;

                string nationality = dr.GetValue(11).ToString().Trim();
                DropDownList3.SelectedValue = nationality;

                nic.Text = dr.GetValue(12).ToString().Trim();
                pwd.Text = dr.GetValue(13).ToString().Trim();

                string userType = dr.GetValue(14).ToString().Trim();
                DropDownList5.SelectedValue = userType;

                string userStatus = dr.GetValue(15).ToString().Trim();
                DropDownList1.SelectedValue = userStatus;

                string faculty = dr.GetValue(16).ToString().Trim();
                DropDownList12.SelectedValue = faculty;

                string jobTittle = dr.GetValue(17).ToString().Trim();
                DropDownList4.SelectedValue = jobTittle;

                string qLevel = dr.GetValue(18).ToString().Trim();
                DropDownList11.SelectedValue = qLevel;

                TextBox28.Text = dr.GetValue(19).ToString().Trim();

                DateTime joinedDate = Convert.ToDateTime(dr.GetValue(20));
                TextBox9.Text = joinedDate.ToString("yyyy-MM-dd").Trim();

                TextBox6.Text = dr.GetValue(21).ToString().Trim();

                TextBox7.Text = dr.GetValue(22).ToString().Trim();


            }
            con.Close();



        }

        protected void UpdateEmployeeDetails_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;

            cmd.CommandText = "UPDATE Employee_TBL SET [Full_Name] = @FullName, [First_Name] = @FirstName, [Middle_Name] = @MiddleName, [Last_Name] = @LastName, [DOB] = @DOB, [Contact_No] = @ContactNo, [Email_ID] = @EmailID, [Full_Address] = @Address, [Gender] = @Gender, [Civil_Status] = @CivilStatus, [Nationality] = @Nationality, [National_Identity_Card] = @NIC, [Password] = @Password, [User_Type] = @UserType, [User_Status] = @UserStatus, [Faculty] = @Faculty, [Job_Tittle] = @JobTittle, [Qualification_Level] = @QLevel, [Salary] = @Salary, [Joined_Date] = @JoinedDate, [Qualification] = @Qualification, [Work_Experience] = @WorkExperience WHERE [Employee_ID] = @UserID";

            cmd.Parameters.AddWithValue("@FullName", fullname.Text.Trim());
            cmd.Parameters.AddWithValue("@FirstName", firstname.Text.Trim());
            cmd.Parameters.AddWithValue("@MiddleName", middlename.Text.Trim());
            cmd.Parameters.AddWithValue("@LastName", lastname.Text.Trim());
            cmd.Parameters.AddWithValue("@DOB", dob.Text.Trim());
            cmd.Parameters.AddWithValue("@ContactNo", contactno.Text.Trim());
            cmd.Parameters.AddWithValue("@EmailID", emailid.Text.Trim());
            cmd.Parameters.AddWithValue("@Address", address.Text.Trim());

            string gender = RadioButton1.Checked ? "Male" : "Female";
            cmd.Parameters.AddWithValue("@Gender", gender);

            cmd.Parameters.AddWithValue("@CivilStatus", DropDownList2.SelectedValue);
            cmd.Parameters.AddWithValue("@Nationality", DropDownList3.SelectedValue);
            cmd.Parameters.AddWithValue("@NIC", nic.Text.Trim());
            cmd.Parameters.AddWithValue("@Password", pwd.Text.Trim());
            cmd.Parameters.AddWithValue("@UserType", DropDownList5.SelectedValue);
            cmd.Parameters.AddWithValue("@UserStatus", DropDownList1.SelectedValue);
            cmd.Parameters.AddWithValue("@UserID", user_id.Text.Trim());

            cmd.Parameters.AddWithValue("@Faculty", DropDownList12.SelectedValue);
            cmd.Parameters.AddWithValue("@JobTittle", DropDownList4.SelectedValue);
            cmd.Parameters.AddWithValue("@QLevel", DropDownList11.SelectedValue);
            cmd.Parameters.AddWithValue("@Salary", TextBox28.Text.Trim());
            cmd.Parameters.AddWithValue("@JoinedDate", TextBox9.Text.Trim());
            cmd.Parameters.AddWithValue("@Qualification", TextBox6.Text.Trim());
            cmd.Parameters.AddWithValue("@WorkExperience", TextBox7.Text.Trim());
            cmd.CommandTimeout = 600;
            cmd.ExecuteNonQuery();
            con.Close();

            string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
            string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' /> Employee Information have been successfully updated";

            Session["AlertMessage"] = message;
            Session["AlertType"] = "alert-success"; // Adding the alert type

            Response.Redirect(Request.RawUrl);
        }
        protected void c_pendingApproval_Click(object sender, EventArgs e)
        {
            Response.Redirect("c_pending_approval_page.aspx");
        }
        protected void leaves_Approval_Click(object sender, EventArgs e)
        {
            Response.Redirect("attendance_pending_approval.aspx");
        }
        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminSelfAttendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminStudentAttendance.aspx");
        }
    }
}