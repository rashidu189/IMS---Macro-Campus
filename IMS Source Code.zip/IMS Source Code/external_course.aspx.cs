﻿using iText.Kernel.Pdf;
using iText.StyledXmlParser.Jsoup.Nodes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using iText.Html2pdf;


namespace IMS_System___MACRO_CAMPUS
{
    public partial class external_course : System.Web.UI.Page
    {
        string user_id = string.Empty;
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ListofECourse();
            }

            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("std_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                    user_id = Session["User_ID"].ToString();
                    TextBox1.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


            //Course Card

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "loadCourses", "loadCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


            //For the Payment

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "PaymentCourses", "PaymentCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }
        private void ListofECourse()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            string studentId = Session["User_ID"].ToString();
            string ListofCoursequery = "SELECT [Course Name] FROM external_course_reg_tbl WHERE [User Id] = '"+studentId+"'";
            SqlCommand cmd = new SqlCommand(ListofCoursequery, con);
            cmd.CommandTimeout = 600;
            try
            {
                SqlDataReader reader = cmd.ExecuteReader();

                // Clear previous data
                DropDownList1.Items.Clear();

                // Bind DropDownList
                DropDownList1.DataSource = reader;
                DropDownList1.DataTextField = "Course Name";
                DropDownList1.DataValueField = "Course Name";
                DropDownList1.DataBind();
                reader.Close(); // Close the reader after binding

                // Optionally, select the first item if it exists
                if (DropDownList1.Items.Count > 0)
                {
                    DropDownList1.SelectedIndex = 0;
                }

                // View External Courses
                    string sValue = DropDownList1.SelectedValue.Trim();
                    if (sValue == "Artificial intelligence (AI) technology")
                    {
                        AItechnology.Visible = true;
                        RPAtechnology.Visible = false;
                        ARVRtechnology.Visible = false;
                    }
                    else if (sValue == "Robotic Process Automation (RPA) technology")
                    {
                        AItechnology.Visible = false;
                        RPAtechnology.Visible = true;
                        ARVRtechnology.Visible = false;
                    }
                    else if (sValue == "AR and VR technology")
                    {
                        AItechnology.Visible = false;
                        RPAtechnology.Visible = false;
                        ARVRtechnology.Visible = true;
                    }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCourse = DropDownList1.SelectedValue.Trim();

            if(selectedCourse == "Artificial intelligence (AI) technology")
            {
                AItechnology.Visible = true;
                RPAtechnology.Visible = false;
                ARVRtechnology.Visible = false;
            }else if (selectedCourse == "Robotic Process Automation (RPA) technology")
            {
                AItechnology.Visible = false;
                RPAtechnology.Visible = true;
                ARVRtechnology.Visible = false;
            }else if (selectedCourse == "AR and VR technology")
            {
                AItechnology.Visible = false;
                RPAtechnology.Visible = false;
                ARVRtechnology.Visible = true;
            }

        }
        public class Course
        {
            public string CourseName { get; set; }
            public string BatchNo { get; set; }
            public string Status { get; set; }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("mycoursepage.aspx");
            /*// Register JavaScript to be executed on the client-side
            string script = "window.location.href = 'mycoursepage.aspx';";
            ClientScript.RegisterStartupScript(this.GetType(), "redirect", script, true);*/
        }
        protected void GenerateCertificateButton_Click(object sender, EventArgs e)
        {
            string StudentName = TextBox1.Text.Trim();
            string CourseName = DropDownList1.SelectedValue.Trim();
            string year = "2 Years course";
            string CEndDate = DateTime.Now.ToString("d");

            // Generate the certificate PDF
            GenerateCertificate(StudentName, CourseName, year, CEndDate, "~/images/M logo.png", "~/images/Signature/signatureM.png", "~/images/Signature/signatureR.png");

            string imageUrl1 = "Resources/info.png"; // Update this to the actual path of your image
            string message1 = $"<img src='{imageUrl1}' alt='Info Image' style='width:20px;height:20px;' /> Student Name : " + StudentName + " Certificate is Generated Successfully.Please Click Download Button and Download it.";

            Session["AlertMessage"] = message1;
            Session["AlertType"] = "alert-info"; // Adding the alert type
        }
        public void GenerateCertificate(string name, string course, string year, string completionDate, string imagePath, string SignatureM, string SignatureR)
        {
            string filePath = Server.MapPath("~/Certificate.pdf");
            string base64Logo;
            using (System.Drawing.Image image = System.Drawing.Image.FromFile(Server.MapPath(imagePath)))
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    image.Save(ms, image.RawFormat);
                    byte[] imageBytes = ms.ToArray();
                    base64Logo = Convert.ToBase64String(imageBytes);
                }
            }

            string base64LogoSignatureM;
            using (System.Drawing.Image image = System.Drawing.Image.FromFile(Server.MapPath(SignatureM)))
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    image.Save(ms, image.RawFormat);
                    byte[] imageBytes = ms.ToArray();
                    base64LogoSignatureM = Convert.ToBase64String(imageBytes);
                }
            }

            string base64LogoSignatureR;
            using (System.Drawing.Image image = System.Drawing.Image.FromFile(Server.MapPath(SignatureR)))
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    image.Save(ms, image.RawFormat);
                    byte[] imageBytes = ms.ToArray();
                    base64LogoSignatureR = Convert.ToBase64String(imageBytes);
                }
            }

            string htmlContent = $@"
                                    <html>
                                        <head>
                                            <style>
                                                body {{
                                                    font-family: Arial, sans-serif;
                                                    background-color: #f4f4f4;
                                                    display: flex;
                                                    justify-content: center;
                                                    align-items: center;
                                                    height: 100vh;
                                                    margin: 0;
                                                }}
                                                .certificate {{
                                                    width: 630px;
                                                    height: 900px;
                                                    padding: 20px;
                                                    border: 10px solid #003DA5;
                                                    background-color: #fff;
                                                    box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.3);
                                                    text-align: center;
                                                    position: relative;
                                                }}
                                                .certificate .logo {{
                                                    margin-bottom: 20px;
                                                }}
                                                .certificate .header {{
                                                    font-size: 28px;
                                                    font-weight: bold;
                                                    color: #003DA5;
                                                    margin-bottom: 10px;
                                                }}
                                                .certificate .sub-header {{
                                                    font-size: 20px;
                                                    margin-bottom: 10px;
                                                    color: #555;
                                                }}
                                                .certificate .name {{
                                                    font-size: 32px;
                                                    font-weight: bold;
                                                    color: #003DA5;
                                                    margin-top: 30px;
                                                }}
                                                .certificate .degree {{
                                                    font-size: 24px;
                                                    font-style: italic;
                                                    margin-top: 10px;
                                                }}
                                                .certificate .date {{
                                                    font-size: 18px;
                                                    margin-top: 30px;
                                                }}
                                                .certificate .signature-section {{
                                                    position: absolute;
                                                    bottom: 20px;
                                                    width: 100%;
                                                    display: flex;
                                                    justify-content: space-between;
                                                    padding: 0 50px;
                                                }}
                                                .certificate .signature-section .sign {{
                                                    font-size: 16px;
                                                    font-weight: bold;
                                                    color: #003DA5;
                                                    text-align: center;
                                                }}
                                                .footer {{
                                                    margin-top: 20px;
                                                    font-size: 12px;
                                                    color: #555;
                                                }}
                                                .signature-container {{display: flex;
                                                    justify-content: space-between; /* Distributes space between sections */
                                                    align-items: flex-end; /* Aligns items to the bottom */
                                                    margin-top: 100px; /* Space above the signature section */
                                                }}

                                                .signature-sectionR, .signature-sectionD {{width: 100%; /* Set width to allow some spacing */
                                                }}

                                                .sign {{text - align: center; /* Center align the text */
                                                }}

                                                .signature-image {{width: 100px; /* Image width */
                                                    height: auto; /* Maintain aspect ratio */
                                                    margin-bottom: -10px; /* Adjust for positioning */
                                                }}
                                                .sign p {{margin - top: 0; 
                                                  line-height: 1; 
                                                }}

                                            </style>
                                        </head>
                                        <body>
                                            <div class=""certificate"">
                                                <div class=""logo"">
                                                    <img src= ""data:image/png;base64,{base64Logo}"" alt=""MACRO Campus Logo"" width=""150"">
                                                </div>
                                                <div class=""header"">MACRO Campus</div>
                                                <div class=""sub-header"">Course Program Certificate</div>
                                                <p>This certifies that</p>
                                                <div class=""name"">{name}</div>
                                                <p>has successfully completed the</p>
                                                <div class=""degree"">{course}</div>
                                                <p>with {year} on this</p>
                                                <div class=""date"">{completionDate:MMMM dd, yyyy}</div>
                                                <div class=""row signature-container"">
                                                  <div class=""signature-sectionR"">
                                                    <div class=""sign left"">
                                                      <img src=""data:image/png;base64,{base64LogoSignatureM}"" alt=""Registrar Signature"" class=""signature-image"" />
                                                      <p>___________________</p>
                                                      <p>Registrar</p>
                                                    </div>
                                                  </div>
                                                  <div class=""signature-sectionD"">
                                                    <div class=""sign right"">
                                                      <img src=""data:image/png;base64,{base64LogoSignatureR}"" alt=""Director Signature"" class=""signature-image"" />
                                                      <p>___________________</p>
                                                      <p>Director</p>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class=""footer"">
                                                    MACRO Campus, 100 Kumaratunga Munidasa Mawatha, Colombo , Sri lanka
                                                </div>
                                            </div>
                                        </body>
                                    </html>";

            // Use FileStream to create the PDF
            using (FileStream stream = new FileStream(filePath, FileMode.Create))
            {
                HtmlConverter.ConvertToPdf(htmlContent, stream);
            }
        }
        public void DownloadCertificate(string fileName)
        {
            string filePath = Server.MapPath(fileName);
            string StudentName = TextBox1.Text.Trim();
            string courseName = DropDownList1.SelectedValue.Trim();

            if (File.Exists(filePath))
            {
                // Set response headers for download
                Response.ContentType = "application/pdf";
                Response.AppendHeader("Content-Disposition", $"attachment; filename= \"{StudentName}_{courseName}_{fileName}\"");
                Response.TransmitFile(filePath);
                Response.End();

            }
            else
            {
                // Handle the error if the file is missing
                Response.Write("<script>alert('Certificate not found.');</script>");
            }
        }
        protected void DownloadCertificateButton_Click(object sender, EventArgs e)
        {
            // Download the certificate
            DownloadCertificate("Certificate.pdf");

        }
    }
}