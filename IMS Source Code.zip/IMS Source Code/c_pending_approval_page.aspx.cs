﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Net;
using System.Xml.Linq;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class c_pending_approval_page : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("emp_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                if (Session["role"].Equals(""))
                {

                }
                else if (Session["role"].Equals("emp_user"))
                {

                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            if(!IsPostBack)
            {
                FillGridView();
            }

            if (!IsPostBack)
            {
                BindDropDownList();
            }


        }

        public void FillGridView()
        {

            if (con.State == ConnectionState.Closed)
                con.Open();

            // Use a SQL query to select data from the table
            string query = "SELECT [id],[User ID],[Full Name],[Email],[Course Name],[Faculties],[Courses],[Course Type] FROM course_reg_req_tbl WHERE [Is Approved] = 0";
            SqlDataAdapter adapter = new SqlDataAdapter(query, con);

            // No need to set the CommandType when using a SQL query
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            con.Close();

            PendingApproval.DataSource = dt;
            PendingApproval.DataBind();

        }

        protected void PendingApproval_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Approve")
            {
                // Get the UserID from the CommandArgument
                string userID = e.CommandArgument.ToString();

                // Find the row that contains the button clicked
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = PendingApproval.Rows.Cast<GridViewRow>().FirstOrDefault(r => ((Button)r.FindControl("Textbox8")).CommandArgument == userID);

                // Get the data from the selected row
                string userId = row.Cells[0].Text;
                string fullName = row.Cells[1].Text;
                string email = row.Cells[2].Text;
                string courseName = row.Cells[3].Text;
                string faculties = row.Cells[4].Text;
                string courses = row.Cells[5].Text;
                string courseType = row.Cells[6].Text;

                // Set the TextBoxes with the retrieved data
                TextBox1.Text = userId;
                TextBox2.Text = fullName;
                TextBox3.Text = email;
                TextBox10.Text = courseName;
                TextBox11.Text = faculties;
                //TextBox6.Text = courses;
                //TextBox7.Text = courseType;
            }
        }

        private void BindDropDownList()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();

            string query = "SELECT [Batch No], [Coordinator], [Count of Students], [Course Start Date], [Course End Date] FROM [dbo].[batch_tbl]";
            SqlCommand cmd = new SqlCommand(query, con);

            try
            {
                SqlDataReader reader = cmd.ExecuteReader();

                // Clear previous data
                DropDownList1.Items.Clear();

                // Bind DropDownList
                DropDownList1.DataSource = reader;
                DropDownList1.DataTextField = "Batch No";
                DropDownList1.DataValueField = "Batch No";
                DropDownList1.DataBind();
                reader.Close(); // Close the reader after binding

                // Optionally, select the first item if it exists
                if (DropDownList1.Items.Count > 0)
                {
                    DropDownList1.SelectedIndex = 0;
                    UpdateTextBoxes(DropDownList1.SelectedValue);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void UpdateTextBoxes(string selectedBatchNo)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;"))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string detailsQuery = "SELECT [Coordinator], [Count of Students], [Course Start Date], [Course End Date] FROM [dbo].[batch_tbl] WHERE [Batch No] = @BatchNo";

                using (SqlCommand detailsCmd = new SqlCommand(detailsQuery, con))
                {
                    detailsCmd.Parameters.AddWithValue("@BatchNo", selectedBatchNo);

                    try
                    {
                        SqlDataReader detailsReader = detailsCmd.ExecuteReader();

                        if (detailsReader.Read())
                        {
                            // Assuming TextBox4, TextBox6, TextBox7, and TextBox9 are your TextBox controls
                            TextBox4.Text = detailsReader["Coordinator"].ToString();
                            TextBox6.Text = detailsReader["Count of Students"].ToString();
                            TextBox7.Text = DateTime.Parse(detailsReader["Course Start Date"].ToString()).ToString("yyyy-MM-dd");
                            TextBox9.Text = DateTime.Parse(detailsReader["Course End Date"].ToString()).ToString("yyyy-MM-dd");
                        }
                        detailsReader.Close(); // Close the reader after reading
                    }
                    catch (Exception ex)
                    {
                        // Handle the exception (e.g., log it, show a message to the user)
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTextBoxes(DropDownList1.SelectedValue);
        }


        protected void Button2_Click(object sender, EventArgs e)
        {
            string batch_No = DropDownList1.SelectedValue;
            string coordinator = TextBox4.Text.Trim();
            string c_start_Date = TextBox7.Text.Trim();
            string c_end_Date = TextBox9.Text.Trim();
            string user1_Id = TextBox1.Text.Trim();
            string full_Name = TextBox2.Text.Trim();
            string email = TextBox3.Text.Trim();
            string c_Name = TextBox10.Text.Trim();
            string c_status = "Ongoing";
            string c_grade = "Pending";

            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "INSERT INTO userdetail_in_batch_tbl ([User Id],[Full Name],[Email],[Course name],[Batch No],[Coordinator],[Course Start Date],[Course End Date],[Status],[Grade]) VALUES ('" + user1_Id+"','"+full_Name+"','"+email+"','"+c_Name+"','"+batch_No+"','"+coordinator+"','"+c_start_Date+"','"+c_end_Date+ "','"+c_status+ "','"+c_grade+"')";
            cmd.ExecuteNonQuery();
            con.Close();

            /*con.Open();
            SqlCommand cmd2 = con.CreateCommand();
            cmd2.CommandType = System.Data.CommandType.Text;
            cmd2.CommandText = "INSERT user_c_subject_tbl ([User ID],[Subject No],[Subject Name],[Semester],[Course name],[Grade],[Start Date],[End Date]) SELECT " + user1_Id+ ",[Subject No],[Subject Name],[Semester],[Course name],'Pending','2024-01-07','2027-01-07' FROM c_subject_tbl WHERE [Course name] ='"+c_Name+"'";
            cmd2.ExecuteNonQuery();
            con.Close();*/

            con.Open();
            SqlCommand cmd2 = con.CreateCommand();
            cmd2.CommandType = System.Data.CommandType.Text;
            cmd2.CommandText = @"INSERT INTO user_c_subject_tbl ([User ID],[Subject No],[Subject Name],[Semester],[Course name],[Grade],[Start Date],[End Date],[Tutorial File Path],[Assignment File Path],[Exam File Path]) 
                     SELECT @UserId, [Subject No], [Subject Name], [Semester], [Course name], 'Pending', '2024-01-07', '2027-01-07',[Tutorial File Path],[Assignment File Path],[Exam File Path]
                     FROM c_subject_tbl 
                     WHERE [Course name] = @CourseName";

            cmd2.Parameters.AddWithValue("@UserId", user1_Id);
            cmd2.Parameters.AddWithValue("@CourseName", c_Name);

            cmd2.ExecuteNonQuery();
            con.Close(); 

            con.Open();
            SqlCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = System.Data.CommandType.Text;
            cmd1.CommandText = "UPDATE course_reg_req_tbl SET [Is Approved] = 1 WHERE [User ID] = '"+user1_Id+ "' AND [Course Name] = '"+c_Name+"'";
            cmd1.ExecuteNonQuery();
            con.Close();

            string TotalAmount = string.Empty;

            con.Open();
            SqlCommand cmd3 = con.CreateCommand();
            cmd3.CommandType = System.Data.CommandType.Text;
            cmd3.CommandText = "SELECT [Total Amount] FROM [course_amount_tbl] WHERE [Course Name] = @CourseName";
            cmd3.Parameters.AddWithValue("@CourseName", c_Name);

            SqlDataReader dr = cmd3.ExecuteReader();
            if (dr.Read())
            {
                TotalAmount = dr.GetValue(0).ToString().Trim();
            }
            con.Close();

            if (!string.IsNullOrEmpty(TotalAmount))
            {
                con.Open();
                SqlCommand cmd4 = con.CreateCommand();
                cmd4.CommandType = System.Data.CommandType.Text;
                cmd4.CommandText = "INSERT INTO [student_couse_payments] ([Student ID],[Course Name],[Total Amount],[Paid Amount],[Pending Amount]) VALUES(@StudentID, @CourseName, @TotalAmount, @PaidAmount, @PendingAmount)";
                cmd4.Parameters.AddWithValue("@StudentID", user1_Id);
                cmd4.Parameters.AddWithValue("@CourseName", c_Name);
                cmd4.Parameters.AddWithValue("@TotalAmount", TotalAmount);
                cmd4.Parameters.AddWithValue("@PaidAmount", 0);
                cmd4.Parameters.AddWithValue("@PendingAmount", TotalAmount);

                cmd4.ExecuteNonQuery();
                con.Close();
            }


            string imageUrl = "Resources/success.png"; // Update this to the actual path of your image
            string message = $"<img src='{imageUrl}' alt='Success Image' style='width:20px;height:20px;' />  " + full_Name + " is Approved successfully. Batch No "+batch_No+"";

            Session["AlertMessage"] = message;
            Session["AlertType"] = "alert-success"; // Adding the alert type
            Response.Redirect(Request.RawUrl);
        }
        protected void c_pendingApproval_Click(object sender, EventArgs e)
        {
            Response.Redirect("c_pending_approval_page.aspx");
        }
        protected void leaves_Approval_Click(object sender, EventArgs e)
        {
            Response.Redirect("attendance_pending_approval.aspx");
        }
        protected void SelfA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminSelfAttendance.aspx");
        }

        protected void StudentA_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminStudentAttendance.aspx");
        }
    }
}