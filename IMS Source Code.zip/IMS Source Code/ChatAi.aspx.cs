﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IMS_System___MACRO_CAMPUS
{
    public partial class ChatAi : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-KUTNUTJ\SQLEXPRESS;Initial Catalog=macro_campus_db;Integrated Security=True;");
        private string apiKey = "sk-svcacct-DS-Jsg9TpXMUlGI7ut70dbEmhV2XlGU3qYWVaKmu4avr1tLu9rjbhZFzCt7tmOAT3BlbkFJeBVyIbBFvTej2EqRnWq7KF5vps678i4PlLomvxMJdVij22DHVobdnbg3W12BhAA"; // OpenAI API Key
        private string apiUrl = "https://api.openai.com/v1/chat/completions";
        private List<object> messages = new List<object>
        {
            new { role = "system", content = "You are a helpful assistant." }
        };
        protected void Page_Load(object sender, EventArgs e)
        {
            string user_id = string.Empty;
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton15.Visible = true;
                }
                else if (Session["role"].Equals("std_user"))
                {
                    LinkButton15.Text = Session["First_Name"].ToString() + " " + Session["Last_Name"].ToString();
                    user_id = Session["User_ID"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            try
            {
                string status = Session["User_Status"] as string;

                if (!string.IsNullOrEmpty(status))
                {
                    if (status.Contains("Active"))
                    {
                        LinkButton16.Visible = true;
                        LinkButton17.Visible = false;
                    }
                    else if (status.Contains("Inactive"))
                    {
                        LinkButton17.Visible = true;
                        LinkButton16.Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }



            //Course Card

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "loadCourses", "loadCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


            //For the Payment

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT [Course name],[Batch No],[Status] FROM userdetail_in_batch_tbl WHERE [User Id] = '" + user_id + "'";
                cmd.ExecuteNonQuery();

                SqlDataReader reader = cmd.ExecuteReader();

                List<Course> courses = new List<Course>();

                while (reader.Read())
                {
                    courses.Add(new Course
                    {
                        CourseName = reader["Course name"].ToString(),
                        BatchNo = reader["Batch No"].ToString(),
                        Status = reader["Status"].ToString()
                    });
                }
                reader.Close();
                con.Close();

                // Serialize courses to JSON
                var jsonCourses = Newtonsoft.Json.JsonConvert.SerializeObject(courses);

                // Pass JSON to JavaScript
                ClientScript.RegisterStartupScript(this.GetType(), "PaymentCourses", "PaymentCourses(" + jsonCourses + ");", true);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
        protected async void btnSend_Click(object sender, EventArgs e)
        {
            string userMessage = txtUserInput.Text.Trim();

            if (string.IsNullOrEmpty(userMessage)) return;

            // Display the user message
            lstChat.Text ="You: " + userMessage;
            txtUserInput.Text = string.Empty;

            // Add the user message to the conversation history
            messages.Add(new { role = "user", content = userMessage });

            // Prepare the payload for the API request
            var payload = new
            {
                model = "gpt-3.5-turbo",
                messages = messages.ToArray()
            };

            string jsonContent = JsonConvert.SerializeObject(payload);
            StringContent content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            // Initialize HttpClient
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + apiKey);

                // Send the request to the OpenAI API
                HttpResponseMessage response = await client.PostAsync(apiUrl, content);

                if (response.IsSuccessStatusCode)
                {
                    // Parse the response
                    string responseString = await response.Content.ReadAsStringAsync();
                    var responseJson = JsonConvert.DeserializeObject<dynamic>(responseString);

                    // Get the assistant's reply
                    string assistantReply = responseJson.choices[0].message.content;
                    //lstChat.Items.Add("Assistant: " + assistantReply);

                    lstChat.Text = "Assistant: " + assistantReply.Replace("\n", "<br />");

                }
                else
                {
                    //lstChat.Items.Add("Error: " + response.ReasonPhrase);
                }
            }
        }

        public class Course
        {
            public string CourseName { get; set; }
            public string BatchNo { get; set; }
            public string Status { get; set; }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("mycoursepage.aspx");
            /*// Register JavaScript to be executed on the client-side
            string script = "window.location.href = 'mycoursepage.aspx';";
            ClientScript.RegisterStartupScript(this.GetType(), "redirect", script, true);*/
        }
    }
}